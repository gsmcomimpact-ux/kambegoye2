
import { Specialty, Neighborhood, Worker, Product, ProductCategory } from './types';

export const PAYMENT_AMOUNT = 200;

// CONFIGURATION OFFICIELLE I-PAY.MONEY
export const IPAY_CONFIG = {
  PUBLIC_KEY: 'pk_e979c6d9f5524f4c9571c72c4714d5ae', 
  SECRET_KEY: 'sk_adcab0ea514b43d49b2bf9479e5146e6',
  INITIATE_URL: 'https://i-pay.money/api/v1/payments',
  STATUS_URL: 'https://i-pay.money/api/v1/payments/',
  HEADERS: {
    PAYMENT_TYPE: 'mobile',
    ENVIRONMENT: 'sandbox',
    COUNTRY: 'NE',
    CURRENCY: 'XOF'
  },
  SUCCESS_REDIRECT: '/payment/callback',
  CANCEL_REDIRECT: '/payment?error=cancel',
  WEBHOOK_URL: '/api/payment/webhook'
};

export const INITIAL_PRODUCT_CATEGORIES: ProductCategory[] = [
  { id: '1', name: 'Protection' },
  { id: '2', name: 'Outillage' },
  { id: '3', name: 'Équipement' },
  { id: '4', name: 'Chantier' },
];

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'p1',
    name: 'Kit de Sécurité Complet',
    description: 'Casque de chantier, gilet fluorescent, gants renforcés et lunettes de protection.',
    price: 15000,
    category: 'Protection',
    imageUrl: 'https://images.unsplash.com/photo-1581147036324-c17ac41dfa6c?auto=format&fit=crop&q=80&w=400',
    stock: 50
  }
];

export const INITIAL_SPECIALTIES: Specialty[] = [
  { id: '1', name: 'Électricien', icon: 'zap' },
  { id: '2', name: 'Plombier', icon: 'droplet' },
  { id: '3', name: 'Maçon', icon: 'brick-wall' },
  { id: '4', name: 'Menuisier', icon: 'hammer' },
  { id: '5', name: 'Peintre', icon: 'paint-roller' },
  { id: '6', name: 'Soudeur', icon: 'flame' },
  { id: '7', name: 'Frigoriste', icon: 'thermometer-snowflake' },
];

export const INITIAL_NEIGHBORHOODS: Neighborhood[] = [
  // COMMUNE 1
  { id: 'c1_1', name: 'Goudel' },
  { id: 'c1_2', name: 'Koira Tegui' },
  { id: 'c1_3', name: 'Ryad' },
  { id: 'c1_4', name: 'Tondi Gavia' },
  { id: 'c1_5', name: 'Yantala Bas' },
  { id: 'c1_6', name: 'Yantala Haut' },
  // COMMUNE 2
  { id: 'c2_1', name: 'Banifandou' },
  { id: 'c2_2', name: 'Boukoki' },
  { id: 'c2_3', name: 'Dar-Es-Salam' },
  { id: 'c2_4', name: 'Lazaret' },
  { id: 'c2_5', name: 'Maourey' },
  { id: 'c2_6', name: 'Wadata' },
  { id: 'c2_7', name: 'Cité Fayçal' },
  // COMMUNE 3
  { id: 'c3_1', name: 'Plateau' },
  { id: 'c3_2', name: 'Bassora' },
  { id: 'c3_3', name: 'Banizoumbou' },
  { id: 'c3_4', name: 'Zongo' },
  { id: 'c3_5', name: 'Poudrière' },
  { id: 'c3_6', name: 'Deyzeibon' },
  { id: 'c3_7', name: 'Kalley Nord' },
  // COMMUNE 4
  { id: 'c4_1', name: 'Saga' },
  { id: 'c4_2', name: 'Talladjé' },
  { id: 'c4_3', name: 'Gamkallé' },
  { id: 'c4_4', name: 'Pays-Bas' },
  { id: 'c4_5', name: 'Aéroport' },
  { id: 'c4_6', name: 'Sanyey' },
  // COMMUNE 5
  { id: 'c5_1', name: 'Harobanda' },
  { id: 'c5_2', name: 'Lamordé' },
  { id: 'c5_3', name: 'Karadjé' },
  { id: 'c5_4', name: 'Banga-Bana' },
  { id: 'c5_5', name: 'Kirkissoye' },
  { id: 'c5_6', name: 'Nogare' },
  { id: 'c5_7', name: 'Gaweye' },
  // ZONES RÉCENTES
  { id: 'z_1', name: 'Niamey 2000' },
  { id: 'z_2', name: 'Cité Francophonie' },
  { id: 'z_3', name: 'Bobiel' }
];

export const INITIAL_WORKERS: Worker[] = [
  {
    id: '101',
    firstName: 'Moussa',
    lastName: 'Ibrahim',
    specialtyId: '1',
    neighborhoodId: 'c2_4',
    whatsapp: '22790000001',
    phone: '90000001',
    photoUrl: 'https://picsum.photos/id/1012/200/200',
    availability: 'available',
    rating: 4.8,
    reviewCount: 24,
    isVerified: true,
    workImages: [],
    accountStatus: 'active'
  }
];
