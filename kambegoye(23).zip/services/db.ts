
import { Worker, Specialty, Neighborhood, Transaction, Stats, Product, ProductCategory, ProjectRequest, Order, SiteActivity, CartItem, Partner, PartnerRequest, AdminUser, MediaItem, Dispute, Bill, Review, SystemSettings } from '../types';
import { INITIAL_NEIGHBORHOODS } from '../constants';

// Détection dynamique et sécurisée de l'URL de l'API
const getApiUrl = () => {
    if (typeof window !== 'undefined') {
        const { hostname, origin } = window.location;
        
        // Environnement de développement local
        if (hostname === 'localhost' || hostname === '127.0.0.1') {
            return 'http://localhost:3001/api';
        }
        
        // En production sur kambegoye.com
        // On utilise l'origine actuelle pour éviter les problèmes mixtes HTTP/HTTPS
        return `${origin}/api`;
    }
    return '/api';
};

const API_URL = getApiUrl();

const fetchAPI = async (endpoint: string, options: any = {}) => {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 20000); // 20s timeout pour les connexions lentes

        const response = await fetch(`${API_URL}${endpoint}`, {
            ...options,
            headers: { 
                'Content-Type': 'application/json',
                ...options.headers 
            },
            signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            return { error: errorData.error || `Erreur serveur ${response.status}`, status: response.status };
        }
        
        return await response.json();
    } catch (e: any) {
        console.error(`❌ Erreur réseau API sur ${API_URL}${endpoint} :`, e.message);
        return { error: "Serveur KAMBEGOYE injoignable. Vérifiez votre connexion internet.", status: 503 };
    }
};

export const db = {
  init: () => {
    console.log(`🚀 KAMBEGOYE CONNECTÉ À L'API : ${API_URL}`);
  },

  calculateDistance: (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371; 
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
        Math.sin(dLat/2) * Math.sin(dLat/2) +
        Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
        Math.sin(dLon/2) * Math.sin(dLon/2); 
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
    return R * c;
  },

  // --- ADMINISTRATION ---
  verifyAdmin: async (username: string, password?: string) => {
    const res = await fetchAPI('/admin/login', {
        method: 'POST',
        body: JSON.stringify({ username, password })
    });
    
    if (res && res.success && !res.error) {
        localStorage.setItem('kambegoye_current_user', JSON.stringify(res.user));
        localStorage.setItem('kambegoye_admin_token', res.token || 'db_auth_valid');
        return true;
    }
    return false;
  },

  getCurrentAdmin: () => {
    const user = localStorage.getItem('kambegoye_current_user');
    return user ? JSON.parse(user) : null;
  },

  logoutAdmin: () => {
    localStorage.removeItem('kambegoye_current_user');
    localStorage.removeItem('kambegoye_admin_token');
  },

  getAdminUsers: async (): Promise<AdminUser[]> => {
    const data = await fetchAPI('/admin/users');
    return Array.isArray(data) ? data : [];
  },

  saveAdminUser: async (user: AdminUser) => {
    return await fetchAPI('/admin/users', { method: 'POST', body: JSON.stringify(user) });
  },

  deleteAdminUser: async (id: string) => {
    return await fetchAPI(`/admin/users/${id}`, { method: 'DELETE' });
  },

  updateAdminPassword: async (password: string) => {
    return await fetchAPI('/admin/password', { method: 'PATCH', body: JSON.stringify({ password }) });
  },

  // --- OUVRIERS ---
  getWorkers: async (): Promise<Worker[]> => {
    const data = await fetchAPI('/workers');
    return Array.isArray(data) ? data : [];
  },

  getWorkerById: async (id: string): Promise<Worker | null> => {
    const data = await fetchAPI(`/workers/${id}`);
    return data && !data.error ? data : null;
  },

  saveWorker: async (worker: Worker) => {
    const res = await fetchAPI('/workers', { method: 'POST', body: JSON.stringify(worker) });
    return res && !res.error;
  },

  deleteWorker: async (id: string) => {
    const res = await fetchAPI(`/workers/${id}`, { method: 'DELETE' });
    return res && !res.error;
  },

  incrementWorkerView: async (id: string) => {
    return fetchAPI(`/workers/${id}/view`, { method: 'POST' });
  },

  registerWorker: async (workerData: any) => {
    return await fetchAPI('/workers/register', { method: 'POST', body: JSON.stringify(workerData) });
  },

  // --- REVIEWS ---
  getReviewsByWorkerId: async (workerId: string): Promise<Review[]> => {
    const data = await fetchAPI(`/reviews?workerId=${workerId}`);
    return Array.isArray(data) ? data : [];
  },

  saveReview: async (review: Partial<Review>) => {
    return await fetchAPI('/reviews', { method: 'POST', body: JSON.stringify(review) });
  },

  // --- LITIGES ---
  getDisputes: async (): Promise<Dispute[]> => {
    const data = await fetchAPI('/disputes');
    return Array.isArray(data) ? data : [];
  },

  saveDispute: async (dispute: any) => {
    const res = await fetchAPI('/disputes', { method: 'POST', body: JSON.stringify(dispute) });
    return res && !res.error;
  },

  updateDisputeStatus: async (id: string, status: string, resolutionDate?: string) => {
    const res = await fetchAPI(`/disputes/${id}/status`, { 
        method: 'PATCH', 
        body: JSON.stringify({ status, resolutionDate }) 
    });
    return res && !res.error;
  },

  // --- BOUTIQUE ---
  getProducts: async (): Promise<Product[]> => {
    const data = await fetchAPI('/products');
    return Array.isArray(data) ? data : [];
  },

  getProductById: async (id: string): Promise<Product | null> => {
    const data = await fetchAPI(`/products/${id}`);
    return data && !data.error ? data : null;
  },

  saveProduct: async (product: Product) => {
    const res = await fetchAPI('/products', { method: 'POST', body: JSON.stringify(product) });
    return res && !res.error;
  },

  deleteProduct: async (id: string) => {
    return await fetchAPI(`/products/${id}`, { method: 'DELETE' });
  },

  getProductCategories: async (): Promise<ProductCategory[]> => {
    const data = await fetchAPI('/product-categories');
    return Array.isArray(data) ? data : [];
  },

  saveProductCategory: async (category: ProductCategory) => {
    return await fetchAPI('/product-categories', { method: 'POST', body: JSON.stringify(category) });
  },

  deleteProductCategory: async (id: string) => {
    return await fetchAPI(`/product-categories/${id}`, { method: 'DELETE' });
  },

  // --- FACTURES ---
  getBills: async (): Promise<Bill[]> => {
    const data = await fetchAPI('/bills');
    return Array.isArray(data) ? data : [];
  },

  saveBill: async (bill: Bill) => {
    const res = await fetchAPI('/bills', { method: 'POST', body: JSON.stringify(bill) });
    return res && !res.error;
  },

  deleteBill: async (id: string) => {
    return await fetchAPI(`/bills/${id}`, { method: 'DELETE' });
  },

  // --- PANIER & COMMANDES ---
  getCart: () => {
      return JSON.parse(localStorage.getItem('kambegoye_cart') || '[]');
  },
  addToCart: (product: Product) => {
    const cart = db.getCart();
    const index = cart.findIndex((i: any) => i.id === product.id);
    if (index >= 0) cart[index].quantity += 1;
    else cart.push({ ...product, quantity: 1 });
    localStorage.setItem('kambegoye_cart', JSON.stringify(cart));
    window.dispatchEvent(new Event('cart-updated'));
  },
  updateCartQuantity: (id: string, delta: number) => {
    const cart = db.getCart();
    const index = cart.findIndex((i: any) => i.id === id);
    if (index >= 0) {
        cart[index].quantity = Math.max(1, cart[index].quantity + delta);
        localStorage.setItem('kambegoye_cart', JSON.stringify(cart));
        window.dispatchEvent(new Event('cart-updated'));
    }
  },
  removeFromCart: (id: string) => {
    const cart = db.getCart().filter((i: any) => i.id !== id);
    localStorage.setItem('kambegoye_cart', JSON.stringify(cart));
    window.dispatchEvent(new Event('cart-updated'));
  },
  clearCart: () => {
    localStorage.removeItem('kambegoye_cart');
    window.dispatchEvent(new Event('cart-updated'));
  },
  getOrders: async (): Promise<Order[]> => {
    const data = await fetchAPI('/orders');
    return Array.isArray(data) ? data : [];
  },
  saveOrder: async (items: CartItem[], total: number, clientInfo: any) => {
    const order = { 
        id: 'CMD-' + Date.now(), 
        items, 
        total, 
        clientName: clientInfo.name, 
        clientPhone: clientInfo.phone, 
        deliveryLocation: clientInfo.location, 
        status: 'pending', 
        date: new Date().toISOString() 
    };
    return await fetchAPI('/orders', { method: 'POST', body: JSON.stringify(order) });
  },
  updateOrderStatus: async (id: string, status: string) => {
    return await fetchAPI(`/orders/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) });
  },

  // --- PROJETS ---
  getProjectRequests: async (): Promise<ProjectRequest[]> => {
    const data = await fetchAPI('/projects');
    return Array.isArray(data) ? data : [];
  },
  saveProjectRequest: async (p: any) => {
    const project = { ...p, id: Date.now().toString(), status: 'new', date: new Date().toISOString() };
    const res = await fetchAPI('/projects', { method: 'POST', body: JSON.stringify(project) });
    return res && !res.error;
  },
  updateProjectRequestStatus: async (id: string, status: string) => {
    return await fetchAPI(`/projects/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) });
  },

  // --- PARTENAIRES ---
  getPartners: async (): Promise<Partner[]> => {
    const data = await fetchAPI('/partners');
    return Array.isArray(data) ? data : [];
  },
  savePartner: async (partner: Partner) => {
    return await fetchAPI('/partners', { method: 'POST', body: JSON.stringify(partner) });
  },
  deletePartner: async (id: string) => {
    return await fetchAPI(`/partners/${id}`, { method: 'DELETE' });
  },
  getPartnerRequests: async (): Promise<PartnerRequest[]> => {
    const data = await fetchAPI('/partner-requests');
    return Array.isArray(data) ? data : [];
  },
  savePartnerRequest: async (request: any) => {
    return await fetchAPI('/partner-requests', { method: 'POST', body: JSON.stringify(request) });
  },
  updatePartnerRequestStatus: async (id: string, status: string) => {
    const res = await fetchAPI(`/partner-requests/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) });
    return res && !res.error;
  },

  // --- MEDIAS ---
  getMedia: async (): Promise<MediaItem[]> => {
    const data = await fetchAPI('/media');
    return Array.isArray(data) ? data : [];
  },
  saveMedia: async (media: MediaItem) => {
    return await fetchAPI('/media', { method: 'POST', body: JSON.stringify(media) });
  },
  deleteMedia: async (id: string) => {
    return await fetchAPI(`/media/${id}`, { method: 'DELETE' });
  },

  // --- STATS ---
  getStats: async (): Promise<Stats> => {
    const data = await fetchAPI('/stats');
    if (data && !data.error) return data;
    
    return {
        totalWorkers: 0,
        totalTransactions: 0,
        totalRevenue: 0,
        boutiqueRevenue: 0,
        serviceRevenue: 0,
        pendingProjects: 0,
        pendingOrders: 0,
        recentActivities: [],
        topWorkers: [],
        topProducts: [],
        allTransactions: []
    };
  },

  // --- CONFIG ---
  getSpecialties: async (): Promise<Specialty[]> => {
    const data = await fetchAPI('/specialties');
    return Array.isArray(data) ? data : [];
  },
  saveSpecialty: async (specialty: Specialty) => {
    return await fetchAPI('/specialties', { method: 'POST', body: JSON.stringify(specialty) });
  },
  deleteSpecialty: async (id: string) => {
    return await fetchAPI(`/specialties/${id}`, { method: 'DELETE' });
  },
  getNeighborhoods: async () => INITIAL_NEIGHBORHOODS,
  getSettings: async () => {
    const data = await fetchAPI('/settings');
    return data && !data.error ? data : { consultationPrice: 200 };
  },
  updateSettings: async (settings: Partial<SystemSettings>) => {
    return await fetchAPI('/settings', { method: 'PATCH', body: JSON.stringify(settings) });
  },
  hasPaid: () => {
      return localStorage.getItem('kambegoye_paid') === 'true';
  },
  finalizeTransaction: async (ref: string) => {
      const res = await fetchAPI(`/payments/verify?ref=${ref}`);
      if (res && res.success) {
          localStorage.setItem('kambegoye_paid', 'true');
          return true;
      }
      return false;
  },
  initiateTransaction: async (method: string, phone: string) => {
      return await fetchAPI('/payments/initiate', {
          method: 'POST',
          body: JSON.stringify({ method, phone })
      });
  },

  // --- DATA MANAGEMENT ---
  exportData: async () => {
    return await fetchAPI('/admin/export');
  },
  importData: async (data: any) => {
    return await fetchAPI('/admin/import', { method: 'POST', body: JSON.stringify(data) });
  },
  clearTransactions: async () => {
      return await fetchAPI('/admin/clear-transactions', { method: 'POST' });
  },
  resetDatabase: async () => {
      return await fetchAPI('/admin/reset', { method: 'POST' });
  },

  fileToDataURL: (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }
};
