
import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { ShoppingCart, Trash2, Plus, Minus, MessageCircle, ArrowLeft, Download, ShoppingBag, User, Phone, MapPin, AlertCircle } from 'lucide-react';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { db } from '../services/db';
import { CartItem } from '../types';

// Helper to convert numbers to French words
const numberToFrenchWords = (n: number): string => {
  const units = ['', 'un', 'deux', 'trois', 'quatre', 'cinq', 'six', 'sept', 'huit', 'neuf'];
  const tens = ['', 'dix', 'vingt', 'trente', 'quarante', 'cinquante', 'soixante', 'soixante-dix', 'quatre-vingt', 'quatre-vingt-dix'];
  const teens = ['dix', 'onze', 'douze', 'treize', 'quatorze', 'quinze', 'seize', 'dix-sept', 'dix-huit', 'dix-neuf'];

  if (n === 0) return 'zéro';

  const convert = (num: number): string => {
    let word = '';
    if (num >= 100) {
      word += (Math.floor(num / 100) === 1 ? '' : units[Math.floor(num / 100)]) + ' cent ';
      num %= 100;
    }
    if (num >= 20) {
      word += tens[Math.floor(num / 10)];
      if (num % 10 > 0) word += (Math.floor(num / 10) === 7 || Math.floor(num / 10) === 9 ? '-' + teens[num % 10] : '-' + units[num % 10]);
    } else if (num >= 10) {
      word += teens[num - 10];
    } else if (num > 0) {
      word += units[num];
    }
    return word.trim();
  };

  let result = '';
  if (n >= 1000000) {
    result += convert(Math.floor(n / 1000000)) + ' million' + (Math.floor(n / 1000000) > 1 ? 's ' : ' ');
    n %= 1000000;
  }
  if (n >= 1000) {
    result += (Math.floor(n / 1000) === 1 ? '' : convert(Math.floor(n / 1000))) + ' mille ';
    n %= 1000;
  }
  result += convert(n);
  return result.trim().toUpperCase();
};

const formatPrice = (price: number): string => {
  return new Intl.NumberFormat('fr-FR').format(price).replace(/\s/g, '.') + 'FCFA';
};

const Cart = () => {
  const navigate = useNavigate();
  const [cart, setCart] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Client Info State
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [deliveryLocation, setDeliveryLocation] = useState('');
  const [showError, setShowError] = useState(false);

  useEffect(() => {
    const loadCart = () => {
      setCart(db.getCart());
      setLoading(false);
    };
    loadCart();

    window.addEventListener('cart-updated', loadCart);
    return () => window.removeEventListener('cart-updated', loadCart);
  }, []);

  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const isFormValid = clientName.trim() !== '' && clientPhone.trim() !== '' && deliveryLocation.trim() !== '';

  const generatePDF = () => {
    if (cart.length === 0) return;
    if (!isFormValid) {
        setShowError(true);
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return;
    }

    const doc = new jsPDF();
    doc.setFontSize(22);
    doc.setTextColor(22, 197, 94);
    doc.text("KAMBEGOYE", 14, 20);
    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text("BON DE COMMANDE BOUTIQUE", 14, 28);
    doc.text(`Date : ${new Date().toLocaleDateString()}`, 14, 33);
    doc.text(`Réf : CMD-${Date.now().toString().slice(-6)}`, 14, 38);

    doc.setTextColor(0);
    doc.text(`Client : ${clientName}`, 14, 48);
    doc.text(`Tél : ${clientPhone}`, 14, 53);
    doc.text(`Lieu : ${deliveryLocation}`, 14, 58);

    const tableColumn = ["Produit", "Quantité", "Prix Unit.", "Total"];
    const tableRows = cart.map(item => [
      item.name, 
      item.quantity, 
      formatPrice(item.price), 
      formatPrice(item.price * item.quantity)
    ]);

    autoTable(doc, {
      head: [tableColumn], body: tableRows, startY: 65, theme: 'grid',
      headStyles: { fillColor: [22, 197, 94] }
    });

    const finalY = (doc as any).lastAutoTable.finalY + 15;
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text(`TOTAL À PAYER : ${formatPrice(cartTotal)}`, 140, finalY);

    doc.setFontSize(10);
    doc.setFont("helvetica", "italic");
    const totalInWords = numberToFrenchWords(cartTotal);
    const mention = `Arrêtée la présente facture à la somme de : ${totalInWords} (${formatPrice(cartTotal)})`;
    
    const splitMention = doc.splitTextToSize(mention, 180);
    doc.text(splitMention, 14, finalY + 15);

    doc.save(`facture_kambegoye_${Date.now()}.pdf`);
  };

  const handleOrderWhatsApp = async () => {
    if (cart.length === 0) return;
    
    if (!isFormValid) {
        setShowError(true);
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return;
    }

    await db.saveOrder(cart, cartTotal, { name: clientName, phone: clientPhone, location: deliveryLocation });

    let message = "🛒 *NOUVELLE COMMANDE KAMBEGOYE*\n\n";
    message += `👤 *Client :* ${clientName}\n`;
    message += `📱 *WhatsApp :* ${clientPhone}\n`;
    message += `📍 *Livraison :* ${deliveryLocation}\n\n`;
    message += "--- DÉTAILS ---\n";
    
    cart.forEach((item, idx) => {
      const subtotal = item.price * item.quantity;
      message += `${idx + 1}. *${item.name}*\n   Qté : ${item.quantity}\n   Prix : ${formatPrice(subtotal)}\n\n`;
    });
    message += `💰 *TOTAL : ${formatPrice(cartTotal)}*`;
    
    const whatsappUrl = `https://wa.me/22797390569?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
    
    db.clearCart();
    navigate('/boutique');
  };

  if (loading) return <div className="p-10 text-center">Chargement...</div>;

  return (
    <div className="max-w-5xl mx-auto px-4 py-12">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-black text-gray-900 dark:text-white flex items-center gap-3">
          <ShoppingCart className="text-brand-600" size={32} /> Mon Panier
        </h1>
        <Link to="/boutique" className="flex items-center text-brand-600 font-bold hover:underline">
          <ArrowLeft size={18} className="mr-2" /> Boutique
        </Link>
      </div>

      {cart.length === 0 ? (
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-12 text-center border-2 border-dashed border-gray-100 dark:border-gray-700">
          <ShoppingBag size={64} className="mx-auto text-gray-200 mb-6" />
          <h2 className="text-xl font-bold text-gray-500 mb-4">Panier vide</h2>
          <Link to="/boutique" className="inline-block bg-brand-600 text-white px-8 py-3 rounded-xl font-bold">Retour Boutique</Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            {/* Delivery Info Form */}
            <div className="bg-white dark:bg-gray-800 p-6 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700">
                <h2 className="text-lg font-black mb-6 flex items-center gap-2 text-brand-600">
                    <MapPin size={20} /> Coordonnées de Livraison
                </h2>
                
                {showError && !isFormValid && (
                    <div className="mb-6 p-4 bg-red-50 border border-red-100 text-red-600 rounded-2xl flex items-center gap-3 text-sm animate-pulse">
                        <AlertCircle size={20} />
                        Veuillez remplir tous les champs de livraison avant de commander.
                    </div>
                )}

                <div className="space-y-4">
                    <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                            <User size={18} className="text-gray-400" />
                        </div>
                        <input 
                            type="text"
                            placeholder="Votre nom complet"
                            value={clientName}
                            onChange={(e) => setClientName(e.target.value)}
                            className="w-full pl-12 pr-4 py-4 rounded-2xl border bg-gray-50 dark:bg-gray-900 dark:border-gray-700 focus:ring-2 focus:ring-brand-500 outline-none transition-all font-bold"
                        />
                    </div>
                    
                    <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                            <Phone size={18} className="text-gray-400" />
                        </div>
                        <input 
                            type="tel"
                            placeholder="Numéro WhatsApp (Ex: 90000000)"
                            value={clientPhone}
                            onChange={(e) => setClientPhone(e.target.value)}
                            className="w-full pl-12 pr-4 py-4 rounded-2xl border bg-gray-50 dark:bg-gray-900 dark:border-gray-700 focus:ring-2 focus:ring-brand-500 outline-none transition-all font-bold"
                        />
                    </div>

                    <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                            <MapPin size={18} className="text-gray-400" />
                        </div>
                        <input 
                            type="text"
                            placeholder="Lieu de livraison (Quartier, précisions...)"
                            value={deliveryLocation}
                            onChange={(e) => setDeliveryLocation(e.target.value)}
                            className="w-full pl-12 pr-4 py-4 rounded-2xl border bg-gray-50 dark:bg-gray-900 dark:border-gray-700 focus:ring-2 focus:ring-brand-500 outline-none transition-all font-bold"
                        />
                    </div>
                </div>
            </div>

            {/* Cart Items */}
            <div className="space-y-4">
              <h2 className="text-lg font-black px-2">Contenu du panier</h2>
              {cart.map(item => (
                <div key={item.id} className="bg-white dark:bg-gray-800 p-4 rounded-3xl border border-gray-100 dark:border-gray-700 flex gap-4 shadow-sm">
                  <img src={item.imageUrl} alt={item.name} className="w-24 h-24 object-cover rounded-2xl shadow-sm" />
                  <div className="flex-1 flex flex-col justify-center">
                    <div className="flex justify-between items-start">
                      <h3 className="font-bold text-gray-900 dark:text-white">{item.name}</h3>
                      <button onClick={() => db.removeFromCart(item.id)} className="text-red-300 hover:text-red-500 p-1 transition-colors"><Trash2 size={18} /></button>
                    </div>
                    <p className="text-brand-600 font-black">{formatPrice(item.price)}</p>
                    <div className="flex items-center gap-4 mt-3">
                      <div className="flex items-center border rounded-xl bg-gray-50 dark:bg-gray-900 overflow-hidden">
                        <button onClick={() => db.updateCartQuantity(item.id, -1)} className="p-2 hover:bg-gray-200"><Minus size={14} /></button>
                        <span className="px-3 font-black">{item.quantity}</span>
                        <button onClick={() => db.updateCartQuantity(item.id, 1)} className="p-2 hover:bg-gray-200"><Plus size={14} /></button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white dark:bg-gray-800 rounded-3xl shadow-xl p-6 border border-gray-100 dark:border-gray-700 sticky top-24">
              <h2 className="text-xl font-bold mb-6">Récapitulatif</h2>
              <div className="border-t border-b border-gray-50 dark:border-gray-700 py-4 mb-8">
                  <div className="flex justify-between text-gray-500 text-sm mb-2">
                      <span>Nombre d'articles</span>
                      <span className="font-bold">{cart.length}</span>
                  </div>
                  <div className="flex justify-between text-2xl font-black text-brand-600">
                    <span>Total</span>
                    <span>{formatPrice(cartTotal)}</span>
                  </div>
              </div>
              
              <div className="space-y-3">
                <button 
                    onClick={generatePDF} 
                    className="w-full flex items-center justify-center gap-2 bg-gray-50 dark:bg-gray-900 text-gray-600 dark:text-gray-300 py-3 rounded-xl font-bold border border-gray-100 dark:border-gray-700 hover:bg-gray-100 transition-colors"
                >
                  <Download size={20} /> Facture PDF
                </button>
                <button 
                    onClick={handleOrderWhatsApp} 
                    className={`w-full flex items-center justify-center gap-2 py-4 rounded-xl font-black shadow-lg transition-all active:scale-95 ${isFormValid ? 'bg-green-500 hover:bg-green-600 text-white' : 'bg-gray-200 text-gray-400 cursor-not-allowed'}`}
                >
                  <MessageCircle size={24} /> Valider (WhatsApp)
                </button>
              </div>
              
              <p className="text-[10px] text-gray-400 text-center mt-6 uppercase font-black tracking-widest leading-tight">
                  En cliquant sur valider, un message WhatsApp pré-rempli sera ouvert pour finaliser avec notre équipe.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Cart;
