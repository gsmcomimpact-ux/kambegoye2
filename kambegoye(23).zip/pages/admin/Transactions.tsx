
import React, { useEffect, useState } from 'react';
import { Download, Filter, Banknote, Smartphone } from 'lucide-react';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { db } from '../../services/db';
import { Transaction } from '../../types';

const Transactions = () => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterMethod, setFilterMethod] = useState<string>('all');

  useEffect(() => {
    db.getStats().then(stats => {
      setTransactions(stats.allTransactions); 
      setLoading(false);
    });
  }, []);

  const filteredTransactions = transactions.filter(t => 
    filterMethod === 'all' ? true : t.method === filterMethod
  );

  const handleExport = () => {
    const doc = new jsPDF();
    const titleSuffix = filterMethod === 'all' ? 'Global' : filterMethod;
    doc.text(`Historique des Transactions (${titleSuffix}) - KAMBEGOYE`, 14, 20);
    doc.setFontSize(10);
    doc.text(`Date d'export: ${new Date().toLocaleDateString()}`, 14, 28);
    doc.text(`Total: ${filteredTransactions.length} transactions`, 14, 34);

    const tableColumn = ["ID", "Date", "Heure", "Montant", "Méthode", "Statut"];
    const tableRows = filteredTransactions.map(tx => [
      tx.id.substring(0, 8).toUpperCase(),
      new Date(tx.date).toLocaleDateString(),
      new Date(tx.date).toLocaleTimeString(),
      `${tx.amount} FCFA`,
      tx.method,
      tx.status
    ]);

    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: 40,
    });

    doc.save(`transactions_${filterMethod}_${new Date().toISOString().slice(0, 10)}.pdf`);
  };

  if (loading) return <div className="p-8 text-center animate-pulse font-black uppercase text-gray-400">Chargement de la comptabilité...</div>;

  return (
    <div className="animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
            <h2 className="text-2xl font-black text-gray-800 dark:text-white uppercase tracking-tighter">Historique des Flux</h2>
            <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">Contrôle des encaissements KAMBEGOYE</p>
        </div>
        
        <div className="flex gap-3 w-full md:w-auto">
          <div className="relative flex-1 md:flex-none">
             <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Filter className="h-4 w-4 text-gray-400" />
             </div>
             <select
                value={filterMethod}
                onChange={(e) => setFilterMethod(e.target.value)}
                className="pl-9 pr-8 py-2.5 border-0 bg-white dark:bg-gray-800 rounded-xl shadow-sm focus:ring-2 focus:ring-brand-500 text-xs font-black uppercase tracking-widest outline-none w-full"
             >
                <option value="all">Tous les flux</option>
                <option value="Mynita">Mynita</option>
                <option value="Amanata">Amanata</option>
                <option value="Espèces">Espèces / Agence</option>
             </select>
          </div>
          
          <button 
            onClick={handleExport}
            className="bg-brand-600 text-white px-5 py-2.5 rounded-xl flex items-center font-black text-xs uppercase tracking-widest hover:bg-brand-700 transition-all shadow-lg active:scale-95"
          >
            <Download className="w-4 h-4 mr-2" /> Exporter
          </button>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 shadow-sm rounded-[2.5rem] overflow-hidden border border-gray-100 dark:border-gray-700">
        <table className="min-w-full divide-y divide-gray-50 dark:divide-gray-700">
          <thead className="bg-gray-50/50 dark:bg-gray-900/50">
            <tr>
              <th className="px-8 py-4 text-left text-[10px] font-black uppercase tracking-widest text-gray-400">Date & Heure</th>
              <th className="px-8 py-4 text-left text-[10px] font-black uppercase tracking-widest text-gray-400">Montant</th>
              <th className="px-8 py-4 text-left text-[10px] font-black uppercase tracking-widest text-gray-400">Méthode</th>
              <th className="px-8 py-4 text-left text-[10px] font-black uppercase tracking-widest text-gray-400">Référence</th>
              <th className="px-8 py-4 text-left text-[10px] font-black uppercase tracking-widest text-gray-400">Statut</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50 dark:divide-gray-700">
            {filteredTransactions.map((tx) => (
              <tr key={tx.id} className="hover:bg-gray-50/50 dark:hover:bg-gray-900/30 transition-colors group">
                <td className="px-8 py-5 whitespace-nowrap">
                   <div className="text-sm font-bold text-gray-700 dark:text-gray-300">{new Date(tx.date).toLocaleDateString()}</div>
                   <div className="text-[10px] text-gray-400 font-bold uppercase">{new Date(tx.date).toLocaleTimeString()}</div>
                </td>
                <td className="px-8 py-5 whitespace-nowrap">
                  <span className="text-sm font-black text-brand-600">{tx.amount.toLocaleString()} FCFA</span>
                </td>
                <td className="px-8 py-5 whitespace-nowrap">
                  <div className="flex items-center gap-2">
                    {tx.method === 'Espèces' ? (
                        <div className="p-1.5 bg-accent-50 text-accent-600 rounded-lg"><Banknote size={14} /></div>
                    ) : (
                        <div className="p-1.5 bg-brand-50 text-brand-600 rounded-lg"><Smartphone size={14} /></div>
                    )}
                    <span className="text-xs font-black uppercase text-gray-600 dark:text-gray-400">{tx.method}</span>
                  </div>
                </td>
                <td className="px-8 py-5 whitespace-nowrap">
                   <span className="text-[10px] font-mono font-black text-gray-400 group-hover:text-brand-600 transition-colors">#{tx.id.substring(0, 10).toUpperCase()}</span>
                </td>
                <td className="px-8 py-5 whitespace-nowrap">
                  <span className={`px-3 py-1 text-[9px] font-black uppercase rounded-full tracking-widest ${
                    tx.status === 'success' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'
                  }`}>
                    {tx.status === 'success' ? '● Validé' : tx.status}
                  </span>
                </td>
              </tr>
            ))}
            {filteredTransactions.length === 0 && (
                <tr>
                    <td colSpan={5} className="px-8 py-20 text-center text-gray-400 font-black uppercase tracking-widest text-xs italic">Aucun flux financier détecté.</td>
                </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Transactions;
