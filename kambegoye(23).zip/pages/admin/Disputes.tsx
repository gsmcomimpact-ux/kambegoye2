
import React, { useEffect, useState } from 'react';
import { AlertCircle, CheckCircle, Clock, Trash2, Calendar, User, Phone, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { db } from '../../services/db';
import { Dispute, Worker } from '../../types';

const Disputes = () => {
  const [disputes, setDisputes] = useState<Dispute[]>([]);
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    setLoading(true);
    const [d, w] = await Promise.all([db.getDisputes(), db.getWorkers()]);
    setDisputes(d.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    setWorkers(w);
    setLoading(false);
  };

  const handleStatusChange = async (id: string, status: Dispute['status']) => {
      let resolutionDate = '';
      if (status === 'resolved') {
          resolutionDate = new Date().toISOString().slice(0, 10);
          const customDate = window.prompt("Date de résolution (AAAA-MM-JJ) :", resolutionDate);
          if (customDate === null) return; // Annulation
          resolutionDate = customDate || resolutionDate;
      }
      
      await db.updateDisputeStatus(id, status, resolutionDate);
      loadData();
  };

  const getWorkerName = (id: string) => {
      const w = workers.find(item => item.id === id);
      return w ? `${w.firstName} ${w.lastName}` : 'Ouvrier Inconnu';
  };

  if (loading) return <div className="p-12 text-center animate-pulse text-gray-400 font-black uppercase tracking-widest">Analyse des litiges en cours...</div>;

  return (
    <div className="animate-in fade-in duration-500 pb-20">
      <div className="mb-10">
        <h2 className="text-3xl font-black text-gray-800 dark:text-white uppercase tracking-tighter flex items-center gap-3">
            <ShieldAlert className="text-red-500" size={32} /> Gestion des Litiges
        </h2>
        <p className="text-gray-500 text-[10px] font-black uppercase tracking-widest mt-1">Plateforme de résolution Niamey</p>
      </div>

      <div className="space-y-6">
        {disputes.map(dispute => (
          <div key={dispute.id} className={`bg-white dark:bg-gray-800 p-8 rounded-[2.5rem] shadow-sm border-l-8 transition-all hover:shadow-xl ${
            dispute.status === 'resolved' ? 'border-l-green-500' : 
            dispute.status === 'investigating' ? 'border-l-orange-500' : 
            dispute.status === 'closed' ? 'border-l-gray-300 opacity-75' : 'border-l-red-500'
          } border-gray-100 dark:border-gray-700`}>
             <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
                <div>
                   <div className="flex items-center gap-3 mb-1">
                        <span className="text-[10px] font-mono font-black text-gray-400 bg-gray-50 dark:bg-gray-900 px-2 py-1 rounded-lg">#{dispute.id.substring(0, 8).toUpperCase()}</span>
                        <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${
                            dispute.status === 'resolved' ? 'bg-green-100 text-green-700' : 
                            dispute.status === 'investigating' ? 'bg-orange-100 text-orange-700' : 
                            dispute.status === 'closed' ? 'bg-gray-100 text-gray-600' : 'bg-red-100 text-red-700 animate-pulse'
                        }`}>
                            {dispute.status === 'open' ? '● Nouveau' : 
                             dispute.status === 'investigating' ? '○ En cours' : 
                             dispute.status === 'resolved' ? '✓ Résolu' : 'Fermé'}
                        </span>
                   </div>
                   <p className="text-[10px] text-gray-400 font-bold flex items-center gap-1 uppercase">
                       <Clock size={12} /> Déclaré le {new Date(dispute.date).toLocaleString()}
                   </p>
                </div>
                
                <div className="flex flex-col items-end gap-2 w-full md:w-auto">
                    <label className="text-[8px] font-black uppercase text-gray-400 tracking-widest mr-2">Changer l'état</label>
                    <select 
                        className="w-full md:w-48 p-3 bg-gray-50 dark:bg-gray-700 border-0 rounded-2xl text-[10px] font-black uppercase outline-none focus:ring-2 focus:ring-brand-500 cursor-pointer"
                        value={dispute.status}
                        onChange={e => handleStatusChange(dispute.id, e.target.value as any)}
                    >
                        <option value="open">Ouvrir Dossier</option>
                        <option value="investigating">En Investigation</option>
                        <option value="resolved">Marquer comme Résolu</option>
                        <option value="closed">Fermer définitivement</option>
                    </select>
                </div>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <div className="bg-gray-50 dark:bg-gray-900/50 p-6 rounded-[2rem] border border-gray-100 dark:border-gray-700">
                   <p className="text-[9px] font-black uppercase text-brand-600 mb-3 tracking-widest flex items-center gap-1.5"><User size={12}/> Plaignant (Client)</p>
                   <p className="font-black text-gray-900 dark:text-white uppercase text-sm tracking-tight">{dispute.reporterName}</p>
                   <p className="text-xs font-mono font-bold text-gray-500 mt-1 flex items-center gap-2"><Phone size={12}/> {dispute.reporterPhone}</p>
                </div>
                <div className="bg-gray-50 dark:bg-gray-900/50 p-6 rounded-[2rem] border border-gray-100 dark:border-gray-700">
                   <p className="text-[9px] font-black uppercase text-orange-600 mb-3 tracking-widest flex items-center gap-1.5"><CheckCircle size={12}/> Ouvrier concerné</p>
                   <p className="font-black text-gray-900 dark:text-white uppercase text-sm tracking-tight">{getWorkerName(dispute.workerId)}</p>
                   <p className="text-[10px] font-bold text-gray-400 font-mono mt-1">ID: {dispute.workerId}</p>
                </div>
             </div>

             <div className="bg-white dark:bg-gray-800 p-6 rounded-[2rem] border border-gray-100 dark:border-gray-700 shadow-inner mb-8">
                <p className="text-[9px] font-black uppercase text-gray-400 mb-2 tracking-widest">Description du litige</p>
                <p className="text-gray-700 dark:text-gray-300 text-sm leading-relaxed italic whitespace-pre-line">
                    "{dispute.description}"
                </p>
             </div>

             {dispute.status === 'resolved' && (
                 <div className="mt-6 flex items-center gap-3 p-5 bg-green-50 dark:bg-green-900/20 rounded-2xl border border-green-100 dark:border-green-800">
                    <CheckCircle2 className="text-green-600 shrink-0" size={24} />
                    <div>
                        <p className="text-[10px] font-black uppercase text-green-700 tracking-widest">Litige Résolu</p>
                        <p className="text-sm font-bold text-green-900 dark:text-green-300">
                            Le problème a été réglé le : <span className="underline decoration-2">{dispute.resolutionDate || 'Date non spécifiée'}</span>
                        </p>
                    </div>
                 </div>
             )}
          </div>
        ))}
        {disputes.length === 0 && (
            <div className="text-center py-32 bg-white dark:bg-gray-800 rounded-[3rem] border border-dashed border-gray-200 dark:border-gray-700">
                <CheckCircle className="mx-auto text-gray-100 mb-6" size={80} />
                <h2 className="text-2xl font-black text-gray-400 uppercase tracking-tighter">Aucun litige en cours</h2>
                <p className="text-gray-400 mt-2 font-medium uppercase text-[10px] tracking-widest">Tout est sous contrôle à Niamey.</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default Disputes;
