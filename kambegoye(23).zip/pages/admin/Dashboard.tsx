
import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { 
  Users, User, ShoppingCart, Wallet, FileText, Activity, 
  ArrowRight, Package, Clock, UserPlus, ShieldAlert, 
  ChevronRight, CheckCircle, AlertTriangle, Eye, X, FilePlus, MapPin, Phone, Handshake, Check, Loader2
} from 'lucide-react';
import { db } from '../../services/db';
import { Stats, Order, Dispute, Worker, PartnerRequest } from '../../types';

const COLORS = ['#16a34a', '#f97316']; 

const Dashboard = () => {
  const navigate = useNavigate();
  const [stats, setStats] = useState<Stats | null>(null);
  const [recentOrders, setRecentOrders] = useState<Order[]>([]);
  const [pendingWorkers, setPendingWorkers] = useState<Worker[]>([]);
  const [openDisputes, setOpenDisputes] = useState<Dispute[]>([]);
  const [pendingPartners, setPendingPartners] = useState<PartnerRequest[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Order Detail Modal State
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const [s, orders, workers, disputes, partnerReqs] = await Promise.all([
      db.getStats(),
      db.getOrders(),
      db.getWorkers(),
      db.getDisputes(),
      db.getPartnerRequests()
    ]);
    
    setStats(s);
    setRecentOrders(orders);
    setPendingWorkers(workers.filter(w => w.accountStatus === 'pending'));
    setOpenDisputes(disputes.filter(d => d.status === 'open' || d.status === 'investigating'));
    setPendingPartners(partnerReqs.filter(r => r.status === 'pending'));
  };

  const handleUpdateOrderStatus = async (id: string, status: 'completed') => {
      if(!window.confirm("Marquer ce bon de commande comme 'Traité / Livré' ?")) return;
      setIsProcessing(true);
      await db.updateOrderStatus(id, status);
      await fetchData();
      setSelectedOrder(null);
      setIsProcessing(false);
  };

  const handleTransformToBill = (order: Order) => {
    navigate('/admin/facturation', { 
      state: { 
        prefill: {
          clientName: order.clientName || "Client Boutique",
          clientPhone: order.clientPhone || "",
          clientAddress: order.deliveryLocation || "",
          type: 'invoice',
          items: order.items.map(item => ({
            description: item.name,
            quantity: item.quantity,
            unitPrice: item.price
          })),
          total: order.total,
          status: 'pending'
        } 
      } 
    });
  };

  if (!stats) return <div className="p-10 text-center">Chargement du poste de commande...</div>;

  const chartData = [
    { name: 'Services (Consultations)', value: stats.serviceRevenue },
    { name: 'Boutique (Factures Fermées)', value: stats.boutiqueRevenue },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-12">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-black text-gray-800 dark:text-white uppercase tracking-tighter">Tableau de Bord</h2>
          <p className="text-gray-500 dark:text-gray-400 font-medium">Gestion globale KAMBEGOYE - Niamey</p>
        </div>
        <div className="hidden md:flex flex-col items-end">
            <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Dernière mise à jour</span>
            <span className="font-bold text-brand-600">{new Date().toLocaleTimeString()}</span>
        </div>
      </div>

      {/* Main KPIs Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-brand-600 p-6 rounded-[2.5rem] shadow-xl text-white relative overflow-hidden group">
          <Wallet className="absolute -right-4 -bottom-4 h-24 w-24 opacity-10 rotate-12 group-hover:scale-110 transition-transform" />
          <p className="text-[10px] font-black uppercase tracking-widest opacity-80 mb-1">Revenu Global Encaissé</p>
          <p className="text-3xl font-black">{stats.totalRevenue.toLocaleString()} F</p>
          <div className="mt-4 flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-white animate-pulse"></div>
              <span className="text-[10px] font-bold uppercase opacity-70">En direct de la base</span>
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 p-6 rounded-[2.5rem] shadow-sm border border-gray-100 dark:border-gray-700">
          <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Boutique (Factures)</p>
          <div className="flex items-baseline gap-2">
            <p className="text-3xl font-black text-orange-500">{stats.boutiqueRevenue.toLocaleString()}</p>
            <span className="text-[10px] text-gray-400 font-bold uppercase">F C.A.</span>
          </div>
          <div className="mt-4 text-[10px] font-black text-orange-600 bg-orange-50 px-2 py-1 rounded-lg w-fit">Ventes encaissées</div>
        </div>

        <div className="bg-white dark:bg-gray-800 p-6 rounded-[2.5rem] shadow-sm border border-gray-100 dark:border-gray-700">
          <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Services (Direct)</p>
          <div className="flex items-baseline gap-2">
            <p className="text-3xl font-black text-brand-600">{stats.serviceRevenue.toLocaleString()}</p>
            <span className="text-[10px] text-gray-400 font-bold uppercase">F C.A.</span>
          </div>
          <div className="mt-4 text-[10px] font-black text-brand-600 bg-brand-50 px-2 py-1 rounded-lg w-fit">Paiements Mynita/Amanata</div>
        </div>

        <div className="bg-white dark:bg-gray-800 p-6 rounded-[2.5rem] shadow-sm border border-gray-100 dark:border-gray-700">
          <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Commandes boutique</p>
          <div className="flex items-baseline gap-2">
            <p className="text-3xl font-black text-gray-900 dark:text-white">{stats.pendingOrders}</p>
            <span className="text-[10px] text-brand-600 font-bold uppercase">À traiter</span>
          </div>
          <div className="mt-4 text-[10px] font-black text-gray-400 bg-gray-50 px-2 py-1 rounded-lg w-fit uppercase">Flux Boutique</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Purchase Orders Processing */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white dark:bg-gray-800 rounded-[2.5rem] shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
            <div className="px-8 py-6 border-b border-gray-50 dark:border-gray-700 flex justify-between items-center bg-gray-50/30 dark:bg-gray-900/50">
              <h3 className="font-black text-gray-800 dark:text-white flex items-center gap-2 uppercase tracking-tighter">
                <Package size={20} className="text-orange-500" /> Traitement des Bons de Commande
              </h3>
              <Link to="/admin/commandes" className="text-[10px] font-black text-orange-600 hover:underline uppercase tracking-widest">
                Voir toutes les commandes <ChevronRight size={14} className="inline ml-1" />
              </Link>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="text-[10px] font-black text-gray-400 uppercase tracking-wider bg-gray-50 dark:bg-gray-900">
                  <tr>
                    <th className="px-8 py-4">Réf. / Client</th>
                    <th className="px-8 py-4">Date / Lieu</th>
                    <th className="px-8 py-4">Statut</th>
                    <th className="px-8 py-4 text-right">Total</th>
                    <th className="px-8 py-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50 dark:divide-gray-700">
                  {recentOrders.slice(0, 5).map((order) => (
                    <tr key={order.id} className={`hover:bg-gray-50 dark:hover:bg-gray-900 transition-colors group ${order.status === 'completed' ? 'opacity-60 grayscale-[0.5]' : ''}`}>
                      <td className="px-8 py-5">
                        <div className="text-sm font-black text-gray-900 dark:text-white uppercase truncate max-w-[150px]">{order.clientName || 'Anonyme'}</div>
                        <div className="text-[10px] text-gray-400 font-mono font-bold">#{order.id.slice(0,6).toUpperCase()}</div>
                      </td>
                      <td className="px-8 py-5">
                        <div className="text-[10px] font-bold text-gray-600 dark:text-gray-400">{new Date(order.date).toLocaleDateString()}</div>
                        <div className="text-[10px] text-gray-400 uppercase truncate max-w-[120px]">{order.deliveryLocation || '-'}</div>
                      </td>
                      <td className="px-8 py-5">
                         <span className={`px-2 py-1 rounded text-[9px] font-black uppercase ${
                             order.status === 'completed' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700 animate-pulse'
                         }`}>
                             {order.status === 'completed' ? 'Traité / Livré' : 'En attente'}
                         </span>
                      </td>
                      <td className="px-8 py-5 text-right font-black text-gray-900 dark:text-white text-sm">{order.total.toLocaleString()} F</td>
                      <td className="px-8 py-5 text-right">
                        <button 
                          onClick={() => setSelectedOrder(order)}
                          className="p-3 bg-gray-50 text-gray-400 hover:text-brand-600 hover:bg-white rounded-2xl shadow-sm transition-all border border-gray-100"
                          title="Traiter le bon"
                        >
                          <ArrowRight size={18} />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {recentOrders.length === 0 && (
                    <tr><td colSpan={5} className="p-20 text-center text-gray-400 font-bold uppercase tracking-widest text-xs italic">Aucune commande boutique.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Revenue Chart */}
          <div className="bg-white dark:bg-gray-800 p-8 rounded-[2.5rem] shadow-sm border border-gray-100 dark:border-gray-700">
            <div className="flex justify-between items-center mb-8">
                <h3 className="font-black text-gray-800 dark:text-white uppercase tracking-tighter flex items-center gap-2">
                    <Activity size={20} className="text-brand-600" /> Répartition du Chiffre d'Affaires
                </h3>
            </div>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={chartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={70}
                    outerRadius={95}
                    paddingAngle={8}
                    dataKey="value"
                    stroke="none"
                  >
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ borderRadius: '20px', border: 'none', boxShadow: '0 20px 25px -5px rgba(0,0,0,0.1)', padding: '15px' }}
                    itemStyle={{ fontWeight: 'black', textTransform: 'uppercase', fontSize: '10px' }}
                  />
                  <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ fontWeight: 'bold', fontSize: '12px', paddingTop: '20px' }}/>
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Sidebar: Alerts & Notifications */}
        <div className="space-y-8">
          <div className="bg-white dark:bg-gray-800 p-8 rounded-[2.5rem] shadow-sm border border-gray-100 dark:border-gray-700">
            <h3 className="font-black text-gray-800 dark:text-white mb-6 flex items-center gap-2 uppercase tracking-tighter">
              <AlertTriangle size={18} className="text-red-500" /> Urgences & Alertes
            </h3>
            <div className="space-y-4">
              {openDisputes.length > 0 && openDisputes.slice(0, 2).map((d) => (
                  <div key={d.id} className="p-4 bg-red-50 dark:bg-red-900/10 rounded-2xl border border-red-100 dark:border-red-800/30">
                    <p className="text-[10px] font-black uppercase text-red-700 mb-1">Litige Client</p>
                    <p className="text-sm font-bold text-gray-900 dark:text-white line-clamp-1">{d.reporterName}</p>
                    <Link to="/admin/litiges" className="text-[10px] font-black text-red-600 hover:underline mt-2 block uppercase tracking-widest">Traiter maintenant</Link>
                  </div>
              ))}
              
              {pendingPartners.length > 0 && (
                  <div className="p-4 bg-indigo-50 dark:bg-indigo-900/10 rounded-2xl border border-indigo-100 dark:border-indigo-800/30">
                    <p className="text-[10px] font-black uppercase text-indigo-700 mb-1">Partenariat</p>
                    <p className="text-sm font-bold text-gray-900 dark:text-white">{pendingPartners.length} demande(s) en attente</p>
                    <Link to="/admin/partenaires" state={{ tab: 'requests' }} className="text-[10px] font-black text-indigo-600 hover:underline mt-2 block uppercase tracking-widest">Voir les dossiers</Link>
                  </div>
              )}

              {openDisputes.length === 0 && pendingPartners.length === 0 && (
                <div className="text-center py-10">
                  <CheckCircle size={40} className="mx-auto text-green-500 opacity-20 mb-4" />
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Aucune alerte critique</p>
                </div>
              )}
            </div>
          </div>

          <div className="bg-brand-900 p-8 rounded-[2.5rem] shadow-lg text-white">
             <h3 className="font-black mb-6 uppercase tracking-widest text-xs opacity-70">Journal d'activités</h3>
             <div className="space-y-6">
                {stats.recentActivities.slice(0, 5).map(act => (
                    <div key={act.id} className="flex gap-4 items-start border-l-2 border-brand-700 pl-4 py-1">
                        <div className="flex-1">
                            <p className="text-xs font-black uppercase leading-none mb-1">{act.title}</p>
                            <p className="text-[10px] opacity-60 line-clamp-1">{act.description}</p>
                        </div>
                    </div>
                ))}
             </div>
          </div>
        </div>
      </div>

      {/* Order Processing Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white dark:bg-gray-800 w-full max-w-xl rounded-[3rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="px-8 py-6 border-b flex justify-between items-center bg-gray-50 dark:bg-gray-900">
              <div>
                <h3 className="font-black text-xl flex items-center gap-2 uppercase tracking-tighter">
                  <Package className="text-orange-500" size={24} /> Bon de Commande #{selectedOrder.id.slice(0,6).toUpperCase()}
                </h3>
                <p className="text-[10px] font-bold text-gray-400 uppercase">Émis le {new Date(selectedOrder.date).toLocaleString()}</p>
              </div>
              <button onClick={() => setSelectedOrder(null)} className="p-3 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-full transition-colors">
                <X size={24} />
              </button>
            </div>
            <div className="p-8">
              {/* Client Info Summary */}
              <div className="mb-8 p-6 bg-gray-50 dark:bg-gray-900 rounded-[2rem] border border-gray-100 dark:border-gray-700 grid grid-cols-2 gap-6 relative">
                 <div className="flex items-start gap-3">
                    <div className="bg-white p-2 rounded-xl shadow-sm"><User size={16} className="text-orange-500" /></div>
                    <div>
                        <p className="text-[9px] font-black uppercase text-gray-400 tracking-widest">Client</p>
                        <p className="text-sm font-bold uppercase">{selectedOrder.clientName}</p>
                    </div>
                 </div>
                 <div className="flex items-start gap-3">
                    <div className="bg-white p-2 rounded-xl shadow-sm"><Phone size={16} className="text-orange-500" /></div>
                    <div>
                        <p className="text-[9px] font-black uppercase text-gray-400 tracking-widest">WhatsApp</p>
                        <p className="text-sm font-bold font-mono">{selectedOrder.clientPhone}</p>
                    </div>
                 </div>
                 <div className="col-span-2 flex items-start gap-3">
                    <div className="bg-white p-2 rounded-xl shadow-sm"><MapPin size={16} className="text-orange-500" /></div>
                    <div>
                        <p className="text-[9px] font-black uppercase text-gray-400 tracking-widest">Lieu de livraison</p>
                        <p className="text-sm font-bold">{selectedOrder.deliveryLocation}</p>
                    </div>
                 </div>
              </div>

              <div className="space-y-4 mb-8 max-h-48 overflow-y-auto pr-2 custom-scrollbar">
                {selectedOrder.items.map((item, idx) => (
                  <div key={idx} className="flex justify-between items-center bg-white dark:bg-gray-800 p-4 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-orange-50 text-orange-600 rounded-xl border border-orange-100 flex items-center justify-center text-xs font-black">
                        {item.quantity}x
                      </div>
                      <div>
                        <p className="text-sm font-black uppercase">{item.name}</p>
                        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">{item.category}</p>
                      </div>
                    </div>
                    <div className="text-sm font-black text-brand-600">
                      {(item.price * item.quantity).toLocaleString()} F
                    </div>
                  </div>
                ))}
              </div>

              <div className="border-t border-dashed border-gray-200 dark:border-gray-700 pt-6 flex justify-between items-center mb-10">
                <span className="text-gray-400 font-black uppercase text-[10px] tracking-[0.2em]">Total de la commande</span>
                <span className="text-3xl font-black text-brand-600 tracking-tighter">{selectedOrder.total.toLocaleString()} FCFA</span>
              </div>

              <div className="grid grid-cols-2 gap-4">
                  {selectedOrder.status === 'pending' && (
                    <button 
                        onClick={() => handleUpdateOrderStatus(selectedOrder.id, 'completed')}
                        disabled={isProcessing}
                        className="flex items-center justify-center gap-2 bg-white border-2 border-green-500 text-green-600 py-4 rounded-[1.5rem] font-black uppercase tracking-widest text-xs hover:bg-green-50 transition-all active:scale-95 disabled:opacity-50 shadow-md"
                    >
                        {isProcessing ? <Loader2 className="animate-spin" /> : <Check size={18} />} Livré / Traité
                    </button>
                  )}
                  <button 
                    onClick={() => handleTransformToBill(selectedOrder)}
                    className={`flex items-center justify-center gap-2 bg-brand-600 hover:bg-brand-700 text-white py-4 rounded-[1.5rem] font-black uppercase tracking-widest text-xs shadow-lg transition-all active:scale-95 ${selectedOrder.status === 'completed' ? 'col-span-2' : ''}`}
                  >
                    <FilePlus size={18} /> Générer Facture Officielle
                  </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
