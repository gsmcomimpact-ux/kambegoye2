
import React, { useState, useEffect } from 'react';
import { Save, Lock, DollarSign, AlertCircle, CheckCircle, MessageCircle, Send, Globe, Copy } from 'lucide-react';
import { db } from '../../services/db';
import { IPAY_CONFIG } from '../../constants';

const Settings = () => {
  // Price State
  const [price, setPrice] = useState<number>(200);
  const [priceStatus, setPriceStatus] = useState<'idle' | 'success' | 'loading'>('idle');

  // Password State
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordStatus, setPasswordStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [passwordMsg, setPasswordMsg] = useState('');

  useEffect(() => {
    db.getSettings().then(s => setPrice(s.consultationPrice));
  }, []);

  const handlePriceUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setPriceStatus('loading');
    await db.updateSettings({ consultationPrice: price });
    setPriceStatus('success');
    setTimeout(() => setPriceStatus('idle'), 3000);
  };

  const handlePasswordUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      setPasswordStatus('error');
      setPasswordMsg('Les mots de passe ne correspondent pas.');
      return;
    }
    if (password.length < 4) {
      setPasswordStatus('error');
      setPasswordMsg('Le mot de passe est trop court.');
      return;
    }

    await db.updateAdminPassword(password);
    setPasswordStatus('success');
    setPasswordMsg('Mot de passe mis à jour avec succès.');
    setPassword('');
    setConfirmPassword('');
    setTimeout(() => setPasswordStatus('idle'), 3000);
  };

  const copyToClipboard = (text: string) => {
      const fullUrl = window.location.origin + text;
      navigator.clipboard.writeText(fullUrl);
      alert("Lien copié : " + fullUrl);
  };

  const sendTestWhatsApp = () => {
    const phone = '22797390569';
    const message = encodeURIComponent("🔔 TEST SYSTEME KAMBEGOYE\nCeci est un message de vérification des notifications.");
    window.open(`https://wa.me/${phone}?text=${message}`, '_blank');
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8 pb-20">
      <h2 className="text-2xl font-black text-gray-800 dark:text-white uppercase tracking-tighter">Paramètres Plateforme</h2>

      {/* i-pay Configuration Section */}
      <div className="bg-white dark:bg-gray-800 p-8 rounded-[2rem] shadow-sm border border-gray-100 dark:border-gray-700">
        <div className="flex items-center mb-6 border-b border-gray-100 dark:border-gray-700 pb-4">
          <div className="p-2 bg-blue-100 text-blue-600 rounded-xl mr-3">
            <Globe className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-black text-gray-900 dark:text-white uppercase tracking-tighter">Configuration i-pay.money</h3>
            <p className="text-[10px] text-gray-400 font-bold uppercase">Liens pour votre tableau de bord marchand</p>
          </div>
        </div>
        
        <div className="space-y-4">
            <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-700">
                <div className="flex justify-between items-center mb-2">
                    <span className="text-[10px] font-black uppercase text-gray-400 tracking-widest">URL de Succès (Redirection)</span>
                    <button onClick={() => copyToClipboard(IPAY_CONFIG.SUCCESS_REDIRECT)} className="text-brand-600 hover:text-brand-700"><Copy size={14}/></button>
                </div>
                <code className="text-xs font-mono break-all text-brand-700 dark:text-brand-400 font-bold">{window.location.origin}{IPAY_CONFIG.SUCCESS_REDIRECT}</code>
            </div>

            <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-700">
                <div className="flex justify-between items-center mb-2">
                    <span className="text-[10px] font-black uppercase text-gray-400 tracking-widest">URL du Webhook (Notification IPN)</span>
                    <button onClick={() => copyToClipboard(IPAY_CONFIG.WEBHOOK_URL)} className="text-brand-600 hover:text-brand-700"><Copy size={14}/></button>
                </div>
                <code className="text-xs font-mono break-all text-brand-700 dark:text-brand-400 font-bold">{window.location.origin}{IPAY_CONFIG.WEBHOOK_URL}</code>
            </div>

            <p className="text-[10px] text-gray-500 font-medium italic mt-2">
                Note : Pour le Webhook, votre site doit être hébergé sur une URL publique (ex: Vercel, Netlify) pour que i-pay puisse envoyer la notification.
            </p>
        </div>
      </div>

      {/* Pricing Settings */}
      <div className="bg-white dark:bg-gray-800 p-8 rounded-[2rem] shadow-sm border border-gray-100 dark:border-gray-700">
        <div className="flex items-center mb-6 border-b border-gray-100 dark:border-gray-700 pb-4">
          <div className="p-2 bg-green-100 text-green-600 rounded-xl mr-3">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-black text-gray-900 dark:text-white uppercase tracking-tighter">Coût de Consultation</h3>
            <p className="text-[10px] text-gray-400 font-bold uppercase">Prix pour débloquer les contacts</p>
          </div>
        </div>
        
        <form onSubmit={handlePriceUpdate}>
          <div className="mb-6">
            <label className="block text-[10px] font-black uppercase text-gray-400 mb-1 tracking-widest">
              Montant forfaitaire (FCFA)
            </label>
            <input
              type="number"
              value={price}
              onChange={(e) => setPrice(Number(e.target.value))}
              className="block w-full rounded-2xl border-gray-200 shadow-sm focus:border-brand-500 focus:ring-brand-500 p-4 border bg-gray-50 dark:bg-gray-700 dark:border-gray-600 dark:text-white font-black"
            />
          </div>
          <div className="flex items-center justify-between">
            <button
              type="submit"
              disabled={priceStatus === 'loading'}
              className="flex items-center bg-brand-600 text-white px-8 py-3 rounded-xl font-black uppercase tracking-widest text-[10px] hover:bg-brand-700 transition-all shadow-lg active:scale-95 disabled:opacity-50"
            >
              <Save className="w-4 h-4 mr-2" />
              {priceStatus === 'loading' ? 'Enregistrement...' : 'Mettre à jour'}
            </button>
            {priceStatus === 'success' && (
              <span className="text-green-600 text-[10px] font-black uppercase flex items-center">
                <CheckCircle className="w-4 h-4 mr-1" /> Mis à jour !
              </span>
            )}
          </div>
        </form>
      </div>

      {/* Notification Tests */}
      <div className="bg-white dark:bg-gray-800 p-8 rounded-[2rem] shadow-sm border border-gray-100 dark:border-gray-700">
        <div className="flex items-center mb-6 border-b border-gray-100 dark:border-gray-700 pb-4">
          <div className="p-2 bg-brand-100 text-brand-600 rounded-xl mr-3">
            <MessageCircle className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-black text-gray-900 dark:text-white uppercase tracking-tighter">Alertes WhatsApp</h3>
            <p className="text-[10px] text-gray-400 font-bold uppercase">Test de ligne administrative</p>
          </div>
        </div>
        
        <p className="text-[10px] text-gray-500 font-medium uppercase tracking-wider mb-6">
          Vérifiez que le numéro administrateur (+227 97 39 05 69) est prêt à recevoir les notifications.
        </p>

        <button
          onClick={sendTestWhatsApp}
          className="w-full flex items-center justify-center bg-green-500 hover:bg-green-600 text-white py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] transition-all shadow-lg active:scale-95"
        >
          <Send className="w-4 h-4 mr-2" />
          Envoyer test WhatsApp
        </button>
      </div>

      {/* Security Settings */}
      <div className="bg-white dark:bg-gray-800 p-8 rounded-[2rem] shadow-sm border border-gray-100 dark:border-gray-700">
        <div className="flex items-center mb-6 border-b border-gray-100 dark:border-gray-700 pb-4">
          <div className="p-2 bg-red-100 text-red-600 rounded-xl mr-3">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-black text-gray-900 dark:text-white uppercase tracking-tighter">Sécurité</h3>
            <p className="text-[10px] text-gray-400 font-bold uppercase">Changement du mot de passe</p>
          </div>
        </div>

        <form onSubmit={handlePasswordUpdate} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-[10px] font-black uppercase text-gray-400 mb-1 tracking-widest">
                Nouveau mot de passe
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="block w-full rounded-2xl border-gray-200 shadow-sm focus:border-brand-500 focus:ring-brand-500 p-4 border bg-gray-50 dark:bg-gray-700 dark:border-gray-600 dark:text-white font-black"
                placeholder="********"
              />
            </div>
            <div>
              <label className="block text-[10px] font-black uppercase text-gray-400 mb-1 tracking-widest">
                Confirmer
              </label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="block w-full rounded-2xl border-gray-200 shadow-sm focus:border-brand-500 focus:ring-brand-500 p-4 border bg-gray-50 dark:bg-gray-700 dark:border-gray-600 dark:text-white font-black"
                placeholder="********"
              />
            </div>
          </div>

          <div className="flex items-center justify-between">
            <button
              type="submit"
              className="flex items-center bg-gray-900 dark:bg-gray-700 text-white px-8 py-3 rounded-xl font-black uppercase tracking-widest text-[10px] hover:bg-black transition-all shadow-lg active:scale-95"
            >
              <Save className="w-4 h-4 mr-2" />
              Changer
            </button>
            {passwordStatus === 'success' && (
              <span className="text-green-600 text-[10px] font-black uppercase flex items-center">
                <CheckCircle className="w-4 h-4 mr-1" /> {passwordMsg}
              </span>
            )}
            {passwordStatus === 'error' && (
              <span className="text-red-600 text-[10px] font-black uppercase flex items-center">
                <AlertCircle className="w-4 h-4 mr-1" /> {passwordMsg}
              </span>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};

export default Settings;
