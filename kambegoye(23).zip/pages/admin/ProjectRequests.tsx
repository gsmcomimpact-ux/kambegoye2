
import React, { useEffect, useState } from 'react';
import { FileText, Phone, CheckCircle, Clock, XCircle, MessageSquare, Receipt, FilePlus, ExternalLink, Download, User } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { db } from '../../services/db';
import { ProjectRequest, Bill } from '../../types';

const ProjectRequests = () => {
  const [requests, setRequests] = useState<ProjectRequest[]>([]);
  const [bills, setBills] = useState<Bill[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const [r, b] = await Promise.all([db.getProjectRequests(), db.getBills()]);
    setRequests(r);
    setBills(b);
  };

  const handleStatusChange = async (id: string, status: any) => {
      await db.updateProjectRequestStatus(id, status);
      loadData();
  };

  const contactClient = (req: ProjectRequest) => {
      const msg = `Bonjour ${req.clientName}, suite à votre demande de projet "${req.title}" sur KAMBEGOYE, nous souhaitons faire un point.`;
      // Normalize phone: Ensure 227 prefix
      let phone = req.clientPhone.replace(/\s/g, '');
      if (phone.length === 8) phone = '227' + phone;
      
      const url = `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`;
      window.open(url, '_blank');
      handleStatusChange(req.id, 'contacted');
  };

  const handleGenerateBill = (req: ProjectRequest, type: 'quote' | 'invoice') => {
      navigate('/admin/facturation', { 
          state: { 
              prefill: {
                  projectId: req.id,
                  clientName: req.clientName,
                  clientPhone: req.clientPhone,
                  type: type,
                  items: [{ description: `PROJET : ${req.title}`, quantity: 1, unitPrice: 0 }]
              } 
          } 
      });
  };

  return (
    <div className="animate-in fade-in duration-500">
      <h2 className="text-2xl font-black text-gray-800 dark:text-white mb-6 uppercase tracking-tighter">Projets & Devis</h2>

      <div className="grid gap-8">
        {requests.map((req) => {
          const linkedBills = bills.filter(b => b.projectId === req.id);
          
          return (
            <div key={req.id} className="bg-white dark:bg-gray-800 rounded-[2.5rem] shadow-sm overflow-hidden border border-gray-100 dark:border-gray-700">
               <div className="p-6 md:p-8">
                  <div className="flex justify-between items-start mb-6">
                     <div>
                         <span className="inline-block px-3 py-1 text-[10px] font-black uppercase tracking-wider text-accent-600 bg-accent-50 dark:bg-accent-900/20 rounded-full mb-2">
                             {req.category}
                         </span>
                         <h3 className="text-2xl font-black text-gray-900 dark:text-white tracking-tight uppercase">{req.title}</h3>
                         <p className="text-sm text-gray-500 dark:text-gray-400 font-bold flex items-center gap-1 uppercase">
                             <Clock size={14}/> Reçu le {new Date(req.date).toLocaleDateString()}
                         </p>
                     </div>
                     <div className="flex flex-col items-end gap-2">
                         {req.status === 'new' && <span className="bg-blue-600 text-white text-[10px] font-black px-4 py-1.5 rounded-full uppercase shadow-sm">Nouveau</span>}
                         {req.status === 'contacted' && <span className="bg-orange-500 text-white text-[10px] font-black px-4 py-1.5 rounded-full uppercase shadow-sm">Contacté</span>}
                         {req.status === 'completed' && <span className="bg-green-600 text-white text-[10px] font-black px-4 py-1.5 rounded-full uppercase shadow-sm">Terminé</span>}
                     </div>
                  </div>

                  <div className="bg-gray-50 dark:bg-gray-900/50 p-6 rounded-2xl mb-8 border border-gray-100 dark:border-gray-700">
                      <p className="text-gray-700 dark:text-gray-300 whitespace-pre-line text-sm leading-relaxed italic">"{req.description}"</p>
                      <div className="mt-6 flex flex-wrap gap-6 text-xs font-black text-brand-600 uppercase tracking-widest">
                          {req.budget && <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-brand-500"></div> Budget: {req.budget} F</div>}
                          {req.deadline && <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-accent-500"></div> Délai: {req.deadline}</div>}
                      </div>
                  </div>

                  <div className="mb-8 border-t border-gray-100 dark:border-gray-700 pt-6">
                      <h4 className="text-sm font-black text-gray-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                         <Receipt size={16}/> Documents Financiers liés ({linkedBills.length})
                      </h4>
                      
                      {linkedBills.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {linkedBills.map(bill => (
                            <div key={bill.id} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-700 group hover:border-brand-200 transition-colors">
                               <div className="flex items-center gap-3">
                                  <div className={`p-2 rounded-xl ${bill.type === 'quote' ? 'bg-blue-100 text-blue-600' : 'bg-green-100 text-green-600'}`}>
                                     <FileText size={18}/>
                                  </div>
                                  <div>
                                     <p className="text-xs font-black uppercase text-gray-500">{bill.type === 'quote' ? 'Devis' : 'Facture'} - {bill.number}</p>
                                     <p className="text-sm font-black text-brand-600">{bill.total.toLocaleString()} F</p>
                                  </div>
                               </div>
                               <button 
                                 onClick={() => navigate('/admin/facturation', { state: { prefill: bill } })}
                                 className="p-2 text-gray-400 hover:text-brand-600 transition-colors"
                                 title="Ouvrir"
                               >
                                  <ExternalLink size={18} />
                               </button>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xs text-gray-400 italic font-medium uppercase tracking-widest">Aucun document généré</p>
                      )}
                  </div>

                  <div className="flex flex-col md:flex-row justify-between items-center gap-6 pt-6 border-t border-gray-100 dark:border-gray-700">
                      <div className="flex items-center gap-4">
                          <div className="bg-brand-50 dark:bg-gray-700 p-3 rounded-2xl">
                              <User size={20} className="text-brand-600" />
                          </div>
                          <div>
                              <p className="font-black text-gray-900 dark:text-white uppercase text-sm tracking-tight">{req.clientName}</p>
                              <p className="text-xs font-bold text-gray-500 font-mono">{req.clientPhone}</p>
                          </div>
                      </div>

                      <div className="flex flex-wrap gap-3 justify-center">
                          <button 
                              onClick={() => handleGenerateBill(req, 'quote')}
                              className="flex items-center px-4 py-2.5 bg-blue-600 text-white text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-blue-700 transition-all shadow-md active:scale-95"
                          >
                              <FilePlus size={14} className="mr-2" /> Nouveau Devis
                          </button>
                          <button 
                              onClick={() => handleGenerateBill(req, 'invoice')}
                              className="flex items-center px-4 py-2.5 bg-brand-600 text-white text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-brand-700 transition-all shadow-md active:scale-95"
                          >
                              <Receipt size={14} className="mr-2" /> Nouvelle Facture
                          </button>
                          <button 
                              onClick={() => contactClient(req)}
                              className="flex items-center px-4 py-2.5 bg-green-500 text-white text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-green-600 transition-all shadow-md active:scale-95"
                          >
                              <MessageSquare size={14} className="mr-2" /> WhatsApp Client
                          </button>
                      </div>
                  </div>
               </div>
            </div>
          );
        })}
        {requests.length === 0 && <div className="text-center py-20 text-gray-400 font-bold uppercase tracking-widest text-xs italic bg-white rounded-3xl border border-dashed border-gray-200">Aucun projet enregistré.</div>}
      </div>
    </div>
  );
};

export default ProjectRequests;
