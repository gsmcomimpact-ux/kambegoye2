
import React, { useEffect, useState } from 'react';
import { Edit, Trash2, Plus, X, Tag } from 'lucide-react';
import { db } from '../../services/db';
import { Specialty } from '../../types';

const AdminSpecialties = () => {
  const [specialties, setSpecialties] = useState<Specialty[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSpecialty, setEditingSpecialty] = useState<Partial<Specialty>>({});

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    const data = await db.getSpecialties();
    setSpecialties(data);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Voulez-vous supprimer ce métier ? Cela pourrait affecter les ouvriers liés.')) {
      await db.deleteSpecialty(id);
      loadData();
    }
  };

  const handleEdit = (s: Specialty) => {
    setEditingSpecialty(s);
    setIsModalOpen(true);
  };

  const handleCreate = () => {
    setEditingSpecialty({
      id: Math.random().toString(36).substr(2, 9),
      name: '',
      icon: 'hammer'
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingSpecialty.name) {
      await db.saveSpecialty(editingSpecialty as Specialty);
      setIsModalOpen(false);
      loadData();
    }
  };

  return (
    <div className="animate-in fade-in duration-500">
      <div className="flex justify-between items-center mb-8">
        <div>
            <h2 className="text-3xl font-black text-gray-800 dark:text-white uppercase tracking-tighter">Métiers & Spécialités</h2>
            <p className="text-gray-500 text-[10px] font-black uppercase tracking-widest">Liste des métiers disponibles sur KAMBEGOYE</p>
        </div>
        <button 
          onClick={handleCreate}
          className="bg-brand-600 text-white px-6 py-3 rounded-2xl flex items-center font-black uppercase tracking-widest text-[10px] shadow-xl hover:bg-brand-700 transition-all active:scale-95"
        >
          <Plus className="w-4 h-4 mr-2" /> Nouveau Métier
        </button>
      </div>

      <div className="bg-white dark:bg-gray-800 shadow-sm rounded-[2.5rem] overflow-hidden border border-gray-100 dark:border-gray-700 max-w-2xl">
        <table className="min-w-full divide-y divide-gray-100 dark:divide-gray-700">
          <thead className="bg-gray-50/50 dark:bg-gray-900/50">
            <tr>
              <th className="px-8 py-5 text-left text-[10px] font-black uppercase tracking-widest text-gray-400">Icône / ID</th>
              <th className="px-8 py-5 text-left text-[10px] font-black uppercase tracking-widest text-gray-400">Intitulé du métier</th>
              <th className="px-8 py-5 text-right text-[10px] font-black uppercase tracking-widest text-gray-400">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50 dark:divide-gray-800">
            {specialties.map((s) => (
              <tr key={s.id} className="hover:bg-gray-50/50 transition-colors group">
                <td className="px-8 py-5">
                   <div className="flex items-center gap-3">
                      <div className="p-2 bg-brand-50 text-brand-600 rounded-xl group-hover:bg-brand-600 group-hover:text-white transition-all shadow-sm">
                          <Tag size={16} />
                      </div>
                      <span className="text-[10px] font-mono font-bold text-gray-400">#{s.id}</span>
                   </div>
                </td>
                <td className="px-8 py-5">
                  <span className="text-sm font-black text-gray-900 dark:text-white uppercase tracking-tight">{s.name}</span>
                </td>
                <td className="px-8 py-5 text-right">
                  <div className="flex justify-end gap-2">
                    <button onClick={() => handleEdit(s)} className="p-2.5 bg-gray-50 text-gray-400 hover:text-brand-600 hover:bg-white rounded-xl shadow-sm transition-all border border-gray-100">
                      <Edit size={16} />
                    </button>
                    <button onClick={() => handleDelete(s.id)} className="p-2.5 text-red-300 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[100] bg-black/60 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white dark:bg-gray-800 rounded-[2.5rem] max-w-md w-full p-10 shadow-2xl animate-in zoom-in-95 duration-200 border border-white/20">
            <div className="flex justify-between items-center mb-8 border-b border-gray-50 pb-4">
              <h3 className="text-2xl font-black text-gray-900 dark:text-white uppercase tracking-tighter">
                {editingSpecialty.name ? 'Éditer' : 'Nouveau'} Métier
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"><X/></button>
            </div>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-[10px] font-black uppercase text-gray-400 mb-1 tracking-widest">Nom de la spécialité</label>
                <input 
                  type="text" 
                  required
                  placeholder="Ex: Électricien"
                  value={editingSpecialty.name || ''}
                  onChange={e => setEditingSpecialty({...editingSpecialty, name: e.target.value})}
                  className="w-full p-4 bg-gray-50 dark:bg-gray-900 border-0 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-brand-500 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-[10px] font-black uppercase text-gray-400 mb-1 tracking-widest">Slug / Code icône (CSS Lucide)</label>
                <input 
                  type="text" 
                  value={editingSpecialty.icon || ''}
                  onChange={e => setEditingSpecialty({...editingSpecialty, icon: e.target.value})}
                  className="w-full p-4 bg-gray-50 dark:bg-gray-900 border-0 rounded-2xl font-mono font-bold outline-none focus:ring-2 focus:ring-brand-500 dark:text-white text-xs"
                />
              </div>

              <button type="submit" className="w-full bg-brand-600 text-white py-4 rounded-2xl font-black shadow-lg hover:bg-brand-700 transition-all active:scale-95 uppercase tracking-widest text-[10px]">
                Enregistrer la Spécialité
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminSpecialties;
