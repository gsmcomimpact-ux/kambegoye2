
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Package, Search, Filter, Eye, CheckCircle, Clock, Trash2, 
  FilePlus, User, Phone, MapPin, ShoppingBag, X, Loader2,
  Printer, Download, ChevronRight, MessageCircle, FileSpreadsheet
} from 'lucide-react';
import { db } from '../../services/db';
import { Order, Bill } from '../../types';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';

const AdminOrders = () => {
  const navigate = useNavigate();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'completed'>('all');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => { loadOrders(); }, []);

  const loadOrders = async () => {
    setLoading(true);
    const data = await db.getOrders();
    setOrders(data);
    setLoading(false);
  };

  const handleUpdateStatus = async (id: string, status: 'completed') => {
    if (!window.confirm("Marquer cette commande comme 'Traitée / Livrée' ?")) return;
    setIsProcessing(true);
    await db.updateOrderStatus(id, status);
    await loadOrders();
    if (selectedOrder?.id === id) setSelectedOrder(prev => prev ? { ...prev, status } : null);
    setIsProcessing(false);
  };

  const generateOrderPDF = (order: Order, autoPrint = false) => {
    const doc = new jsPDF();
    doc.setFontSize(22);
    doc.setTextColor(22, 197, 94);
    doc.text("KAMBEGOYE", 14, 20);
    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text("BON DE COMMANDE BOUTIQUE", 14, 28);
    doc.text(`Date : ${new Date(order.date).toLocaleDateString()}`, 14, 33);
    doc.text(`Réf : #${order.id.slice(0, 8).toUpperCase()}`, 14, 38);

    doc.setTextColor(0);
    doc.text(`Client : ${order.clientName}`, 14, 48);
    doc.text(`Tél : ${order.clientPhone}`, 14, 53);
    doc.text(`Lieu : ${order.deliveryLocation}`, 14, 58);

    const tableColumn = ["Produit", "Quantité", "Prix Unit.", "Total"];
    const tableRows = order.items.map(item => [item.name, item.quantity, `${item.price.toLocaleString()} F`, `${(item.price * item.quantity).toLocaleString()} F`]);

    autoTable(doc, { head: [tableColumn], body: tableRows, startY: 65, theme: 'grid', headStyles: { fillColor: [22, 197, 94] } });

    const finalY = (doc as any).lastAutoTable.finalY + 15;
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text(`TOTAL : ${order.total.toLocaleString()} FCFA`, 140, finalY);

    if (autoPrint) {
        window.open(doc.output('bloburl'), '_blank');
    } else {
        doc.save(`commande_${order.id.slice(0, 8)}.pdf`);
    }
  };

  const handleExportJournal = () => {
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.setTextColor(22, 197, 94);
    doc.text("KAMBEGOYE - JOURNAL DES VENTES BOUTIQUE", 14, 20);
    doc.setFontSize(10);
    doc.text(`Rapport généré le : ${new Date().toLocaleString()}`, 14, 28);
    doc.text(`Nombre de commandes : ${filteredOrders.length}`, 14, 33);

    const tableColumn = ["Date", "Réf", "Client", "Lieu", "Statut", "Montant"];
    const tableRows = filteredOrders.map(o => [
        new Date(o.date).toLocaleDateString(),
        o.id.slice(0, 8).toUpperCase(),
        o.clientName || 'Inconnu',
        o.deliveryLocation || '-',
        o.status === 'completed' ? 'Livré' : 'Attente',
        `${o.total.toLocaleString()} F`
    ]);

    autoTable(doc, { head: [tableColumn], body: tableRows, startY: 40, theme: 'grid', headStyles: { fillColor: [22, 197, 94] } });

    const totalSales = filteredOrders.reduce((s, o) => s + o.total, 0);
    const finalY = (doc as any).lastAutoTable.finalY + 15;
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text(`CHIFFRE D'AFFAIRES GLOBAL : ${totalSales.toLocaleString()} FCFA`, 100, finalY);

    doc.save(`journal_ventes_${new Date().toISOString().slice(0, 10)}.pdf`);
  };

  const handleSendWhatsAppPDF = (order: Order) => {
    generateOrderPDF(order);
    const message = `Bonjour ${order.clientName},\n\nVotre bon de commande n°*${order.id.slice(0, 8).toUpperCase()}* d'un montant de *${order.total.toLocaleString()} FCFA* a été bien reçu par KAMBEGOYE.\n\nMerci de trouver le récapitulatif en PDF ci-joint.\n\nNous vous contacterons très prochainement pour la livraison.`;
    let phone = (order.clientPhone || '').replace(/\s/g, '');
    if (phone.length === 8) phone = '227' + phone;
    window.open(`https://wa.me/${phone}?text=${encodeURIComponent(message)}`, '_blank');
  };

  const filteredOrders = orders.filter(o => {
    const matchesSearch = (o.clientName || '').toLowerCase().includes(searchTerm.toLowerCase()) || o.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' ? true : o.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-black text-gray-800 dark:text-white uppercase tracking-tighter">Bons de Commande</h2>
          <p className="text-gray-500 dark:text-gray-400 font-medium uppercase text-[10px] tracking-widest mt-1">Ventes Boutique</p>
        </div>
        
        <div className="flex gap-2">
            <button onClick={handleExportJournal} className="bg-white border-2 border-brand-100 text-brand-600 px-6 py-3 rounded-xl font-black uppercase tracking-widest text-[10px] flex items-center gap-2 hover:bg-brand-50 transition-all shadow-sm">
                <FileSpreadsheet size={16} /> Journal Ventes
            </button>
            <div className="flex bg-white dark:bg-gray-800 p-1.5 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700">
                <button onClick={() => setStatusFilter('all')} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${statusFilter === 'all' ? 'bg-brand-600 text-white shadow-lg' : 'text-gray-400'}`}>Tous</button>
                <button onClick={() => setStatusFilter('pending')} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all flex items-center gap-2 ${statusFilter === 'pending' ? 'bg-orange-500 text-white shadow-lg' : 'text-gray-400'}`}>À traiter</button>
                <button onClick={() => setStatusFilter('completed')} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${statusFilter === 'completed' ? 'bg-green-600 text-white shadow-lg' : 'text-gray-400'}`}>Livrées</button>
            </div>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-[2.5rem] shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
        <div className="p-6 border-b flex flex-col md:flex-row justify-between gap-4 items-center bg-gray-50/50 dark:bg-gray-900/50">
            <div className="relative w-full md:w-96">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                <input type="text" placeholder="Référence ou client..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full pl-12 pr-4 py-3 bg-white dark:bg-gray-700 border-0 rounded-2xl text-xs font-bold outline-none focus:ring-2 focus:ring-brand-500" />
            </div>
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">{filteredOrders.length} COMMANDES</p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-gray-50 dark:bg-gray-900">
              <tr>
                <th className="px-8 py-4 text-[10px] font-black uppercase text-gray-400 tracking-wider">Date / Réf</th>
                <th className="px-8 py-4 text-[10px] font-black uppercase text-gray-400 tracking-wider">Client / Lieu</th>
                <th className="px-8 py-4 text-[10px] font-black uppercase text-gray-400 tracking-wider text-right">Total</th>
                <th className="px-8 py-4 text-[10px] font-black uppercase text-gray-400 tracking-wider">Statut</th>
                <th className="px-8 py-4 text-right text-[10px] font-black uppercase text-gray-400 tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50 dark:divide-gray-700">
              {filteredOrders.map(order => (
                <tr key={order.id} className={`hover:bg-gray-50 dark:hover:bg-gray-900/30 transition-colors group ${order.status === 'completed' ? 'opacity-60' : ''}`}>
                  <td className="px-8 py-5">
                    <div className="text-sm font-black font-mono">#{order.id.slice(0, 8).toUpperCase()}</div>
                    <div className="text-[10px] text-gray-400 font-bold">{new Date(order.date).toLocaleDateString()}</div>
                  </td>
                  <td className="px-8 py-5">
                    <div className="text-sm font-black uppercase">{order.clientName || 'Inconnu'}</div>
                    <div className="text-[10px] text-gray-400 font-bold">{order.deliveryLocation || '-'}</div>
                  </td>
                  <td className="px-8 py-5 text-right font-black text-brand-600">{order.total.toLocaleString()} F</td>
                  <td className="px-8 py-5">
                    <span className={`px-2 py-1 rounded text-[9px] font-black uppercase ${order.status === 'completed' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'}`}>{order.status === 'completed' ? 'Livré' : 'En attente'}</span>
                  </td>
                  <td className="px-8 py-5 text-right">
                    <div className="flex justify-end gap-1.5">
                        <button onClick={() => handleSendWhatsAppPDF(order)} className="p-2.5 bg-green-50 text-green-600 hover:bg-green-100 border border-green-100 rounded-xl" title="WhatsApp"><MessageCircle size={16} /></button>
                        <button onClick={() => setSelectedOrder(order)} className="p-2.5 bg-gray-50 dark:bg-gray-700 text-gray-400 hover:text-brand-600 rounded-xl" title="Détails"><Eye size={16} /></button>
                        <button onClick={() => generateOrderPDF(order, true)} className="p-2.5 bg-gray-50 dark:bg-gray-700 text-gray-400 hover:text-brand-600 rounded-xl" title="Imprimer"><Printer size={16} /></button>
                        <button onClick={() => generateOrderPDF(order)} className="p-2.5 bg-gray-50 dark:bg-gray-700 text-gray-400 hover:text-blue-600 rounded-xl" title="Télécharger"><Download size={16} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {selectedOrder && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white dark:bg-gray-800 w-full max-w-xl rounded-[3rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 flex flex-col">
            <div className="px-8 py-6 border-b flex justify-between items-center bg-gray-50 dark:bg-gray-900">
              <h3 className="font-black text-xl flex items-center gap-2 uppercase tracking-tighter"><Package className="text-orange-500" size={24} /> Bon #{selectedOrder.id.slice(0, 8).toUpperCase()}</h3>
              <button onClick={() => setSelectedOrder(null)} className="p-3 hover:bg-gray-200 rounded-full transition-colors"><X size={24} /></button>
            </div>
            <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
              <div className="mb-8 p-6 bg-gray-50 dark:bg-gray-900 rounded-[2rem] border border-gray-100 dark:border-gray-700 grid grid-cols-2 gap-6">
                 <div><p className="text-[9px] font-black uppercase text-gray-400">Client</p><p className="text-sm font-bold uppercase">{selectedOrder.clientName}</p></div>
                 <div><p className="text-[9px] font-black uppercase text-gray-400">Mobile</p><p className="text-sm font-bold font-mono">{selectedOrder.clientPhone}</p></div>
                 <div className="col-span-2"><p className="text-[9px] font-black uppercase text-gray-400">Livraison</p><p className="text-sm font-bold">{selectedOrder.deliveryLocation}</p></div>
              </div>
              <div className="space-y-3 mb-8">
                {selectedOrder.items.map((item, idx) => (
                  <div key={idx} className="flex justify-between items-center bg-white dark:bg-gray-700 p-4 rounded-2xl border border-gray-100 dark:border-gray-600">
                    <div className="flex items-center gap-4"><div className="w-10 h-10 bg-orange-50 text-orange-600 rounded-xl flex items-center justify-center text-xs font-black">{item.quantity}x</div><p className="text-sm font-black uppercase">{item.name}</p></div>
                    <div className="text-sm font-black text-brand-600">{(item.price * item.quantity).toLocaleString()} F</div>
                  </div>
                ))}
              </div>
              <div className="border-t border-dashed pt-6 flex justify-between items-center mb-6">
                <span className="text-gray-400 font-black uppercase text-[10px]">Total Commande</span>
                <span className="text-3xl font-black text-brand-600 tracking-tighter">{selectedOrder.total.toLocaleString()} F</span>
              </div>
            </div>
            <div className="p-8 bg-gray-50 dark:bg-gray-900 border-t grid grid-cols-2 gap-4">
                {selectedOrder.status === 'pending' && <button onClick={() => handleUpdateStatus(selectedOrder.id, 'completed')} className="flex items-center justify-center gap-2 bg-green-600 text-white py-4 rounded-[1.5rem] font-black uppercase tracking-widest text-[10px] shadow-lg">Confirmer Livraison</button>}
                <button onClick={() => navigate('/admin/facturation', { state: { prefill: { clientName: selectedOrder.clientName, clientPhone: selectedOrder.clientPhone, clientAddress: selectedOrder.deliveryLocation, type: 'invoice', items: selectedOrder.items.map(i => ({ description: i.name, quantity: i.quantity, unitPrice: i.price })), total: selectedOrder.total, status: 'pending' } } })} className={`flex items-center justify-center gap-2 bg-brand-600 text-white py-4 rounded-[1.5rem] font-black uppercase tracking-widest text-[10px] shadow-lg ${selectedOrder.status === 'completed' ? 'col-span-2' : ''}`}><FilePlus size={16} /> Créer Facture</button>
            </div>
          </div>
        </div>
      )}

      {loading && <div className="py-24 text-center"><Loader2 className="w-12 h-12 text-brand-600 animate-spin mx-auto mb-4" /><p className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Chargement...</p></div>}
    </div>
  );
};

export default AdminOrders;
