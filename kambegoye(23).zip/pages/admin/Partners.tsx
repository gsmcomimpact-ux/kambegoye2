
import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Plus, Trash2, Eye, EyeOff, Globe, X, Upload, Image as ImageIcon, ShoppingBag, Clock, Check, XCircle, Mail, Phone, User, MessageSquare, AlertCircle, Loader2 } from 'lucide-react';
import { db } from '../../services/db';
import { Partner, PartnerRequest } from '../../types';

const Partners = () => {
  const location = useLocation();
  const [partners, setPartners] = useState<Partner[]>([]);
  const [requests, setRequests] = useState<PartnerRequest[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  
  const [activeTab, setActiveTab] = useState<'active' | 'requests'>(
    location.state?.tab === 'requests' ? 'requests' : 'active'
  );
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPartner, setEditingPartner] = useState<Partial<Partner>>({ isVisible: true });
  const [linkTarget, setLinkTarget] = useState<'external' | 'shop'>('external');

  useEffect(() => { loadData(); }, []);

  useEffect(() => {
    if (location.state?.tab) {
      setActiveTab(location.state.tab as 'active' | 'requests');
      window.history.replaceState({}, document.title);
    }
  }, [location.state]);

  const loadData = async () => {
    const [p, r] = await Promise.all([db.getPartners(), db.getPartnerRequests()]);
    // On trie : d'abord les visibles, puis les brouillons
    const sortedPartners = [...p].sort((a, b) => {
        if (a.isVisible === b.isVisible) return a.name.localeCompare(b.name);
        return a.isVisible ? -1 : 1;
    });
    setPartners(sortedPartners);
    setRequests(r);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Supprimer définitivement ce partenaire ?')) {
      setIsProcessing(true);
      try {
        await db.deletePartner(id);
        await loadData();
      } catch (e) {
        alert("Erreur lors de la suppression.");
      } finally {
        setIsProcessing(false);
      }
    }
  };

  const handleToggleVisibility = async (partner: Partner) => {
      setIsProcessing(true);
      try {
        const newStatus = !partner.isVisible;
        // Mise à jour explicite de l'objet partenaire
        const updatedPartner = { ...partner, isVisible: newStatus };
        await db.savePartner(updatedPartner);
        
        // Rafraîchissement des données pour mettre à jour l'UI
        await loadData();
      } catch (e) {
        console.error("Error toggling partner visibility", e);
        alert("Erreur lors du changement de visibilité.");
      } finally {
        setIsProcessing(false);
      }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      try {
        const dataUrl = await db.fileToDataURL(file);
        setEditingPartner({ ...editingPartner, logoUrl: dataUrl });
      } catch (err) {
        alert("Erreur lors de l'importation de l'image.");
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPartner.logoUrl) {
        alert("Veuillez sélectionner un logo.");
        return;
    }
    
    setIsProcessing(true);
    try {
      const finalPartner = {
          ...editingPartner,
          websiteUrl: linkTarget === 'shop' ? '/boutique' : editingPartner.websiteUrl
      };

      await db.savePartner(finalPartner as Partner);
      setIsModalOpen(false);
      await loadData();
      setActiveTab('active');
    } catch (e) {
      alert("Erreur lors de l'enregistrement du partenaire.");
    } finally {
      setIsProcessing(false);
    }
  };

  const openEdit = (partner?: Partner) => {
      if (partner) {
          setEditingPartner({ ...partner });
          setLinkTarget(partner.websiteUrl === '/boutique' ? 'shop' : 'external');
      } else {
          setEditingPartner({ isVisible: false, name: '', websiteUrl: '', logoUrl: '', comment: '', category: 'Matériel' });
          setLinkTarget('external');
      }
      setIsModalOpen(true);
  };

  const handleRequestStatus = async (id: string, status: 'approved' | 'rejected') => {
      if (status === 'approved') {
          if(!window.confirm("Approuver ce partenaire ? Il sera ajouté à la liste 'Active' en mode BROUILLON.")) return;
      } else {
          if(!window.confirm("Refuser cette candidature ?")) return;
      }

      setIsProcessing(true);
      try {
          const success = await db.updatePartnerRequestStatus(id, status);
          if (success) {
            await loadData();
            if (status === 'approved') {
                setActiveTab('active');
            }
          } else {
              throw new Error("Échec de la mise à jour");
          }
      } catch (e) {
          console.error(e);
          alert("Erreur lors du traitement de la demande.");
      } finally {
          setIsProcessing(false);
      }
  };

  const pendingCount = requests.filter(r => r.status === 'pending').length;

  return (
    <div className="animate-in fade-in duration-500 pb-20 relative">
      {/* Overlay de chargement pour les actions asynchrones */}
      {isProcessing && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/10 backdrop-blur-[1px]">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-3xl shadow-2xl flex flex-col items-center gap-4 border border-brand-100 dark:border-brand-900">
             <Loader2 className="animate-spin text-brand-600 h-10 w-10" />
             <span className="font-black text-xs uppercase tracking-widest text-brand-600">Action en cours...</span>
          </div>
        </div>
      )}

      <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
        <div>
            <h2 className="text-2xl font-black text-gray-800 dark:text-white uppercase tracking-tighter">Gestion Partenaires</h2>
            <p className="text-gray-500 text-sm font-medium uppercase tracking-widest text-[10px]">Administration des entreprises certifiées</p>
        </div>
        
        <div className="flex bg-white dark:bg-gray-800 p-1.5 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700">
            <button 
                onClick={() => setActiveTab('active')} 
                className={`px-6 py-2.5 rounded-xl text-xs font-black uppercase transition-all ${activeTab === 'active' ? 'bg-brand-600 text-white shadow-lg' : 'text-gray-400 hover:text-gray-600'}`}
            >
                Liste Active ({partners.length})
            </button>
            <button 
                onClick={() => setActiveTab('requests')} 
                className={`px-6 py-2.5 rounded-xl text-xs font-black uppercase transition-all flex items-center gap-2 ${activeTab === 'requests' ? 'bg-orange-500 text-white shadow-lg' : 'text-gray-400 hover:text-gray-600'}`}
            >
                Candidatures {pendingCount > 0 && <span className="bg-white text-orange-600 w-5 h-5 flex items-center justify-center rounded-full text-[10px] font-black">{pendingCount}</span>}
            </button>
        </div>

        <button onClick={() => openEdit()} className="bg-brand-600 text-white px-6 py-3 rounded-xl font-black uppercase tracking-widest text-[10px] flex items-center gap-2 shadow-xl hover:bg-brand-700 transition-all active:scale-95">
            <Plus size={16} /> Créer Manuellement
        </button>
      </div>

      {activeTab === 'active' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {partners.map(partner => (
            <div key={partner.id} className={`bg-white dark:bg-gray-800 p-8 rounded-[2.5rem] shadow-sm border transition-all flex flex-col group ${partner.isVisible ? 'border-brand-200 dark:border-brand-900/50 ring-2 ring-brand-50/50' : 'border-dashed border-gray-300 dark:border-gray-600 opacity-80'}`}>
               
               <div className="flex justify-between items-start mb-6">
                  <div className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest flex items-center gap-1.5 ${partner.isVisible ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'}`}>
                    {partner.isVisible ? <><Eye size={12}/> Publié</> : <><EyeOff size={12}/> Brouillon</>}
                  </div>
                  <span className="text-[9px] font-black uppercase px-2 py-0.5 bg-brand-50 dark:bg-brand-900/30 text-brand-600 rounded-full">{partner.category || 'Partenaire'}</span>
               </div>

               <div className="h-40 flex items-center justify-center mb-6 bg-gray-50 dark:bg-gray-900 rounded-3xl p-8 border border-gray-100 dark:border-gray-700 overflow-hidden relative">
                  <img src={partner.logoUrl} alt={partner.name} className={`max-h-full max-w-full object-contain group-hover:scale-110 transition-transform duration-700 ${!partner.isVisible ? 'grayscale' : ''}`} />
               </div>
               
               <h3 className="text-xl font-black text-gray-900 dark:text-white uppercase tracking-tighter mb-2 line-clamp-1">{partner.name}</h3>
               
               <div className="h-10 mb-6 overflow-hidden">
                {partner.comment && (
                    <p className="text-sm text-gray-500 dark:text-gray-400 italic line-clamp-2 leading-relaxed">
                      "{partner.comment}"
                    </p>
                )}
               </div>

               <div className="flex items-center text-[10px] font-black uppercase text-brand-600 mb-6 truncate mt-auto bg-brand-50 dark:bg-brand-900/20 px-3 py-1.5 rounded-xl w-fit border border-brand-100 dark:border-brand-800">
                  {partner.websiteUrl === '/boutique' ? (
                      <><ShoppingBag size={14} className="mr-2" /> Redirection Boutique</>
                  ) : (
                      <><Globe size={14} className="mr-2" /> {partner.websiteUrl || 'Pas de site'}</>
                  )}
               </div>

               <div className="grid grid-cols-2 gap-3 pt-6 border-t border-gray-50 dark:border-gray-700">
                  <button 
                      onClick={() => handleToggleVisibility(partner)} 
                      disabled={isProcessing}
                      className={`flex items-center justify-center gap-2 py-3 rounded-xl text-[10px] font-black uppercase transition-all shadow-md active:scale-95 disabled:opacity-50 ${partner.isVisible ? 'bg-gray-100 text-gray-600 hover:bg-red-50 hover:text-red-600' : 'bg-brand-600 text-white hover:bg-brand-700'}`}
                  >
                      {partner.isVisible ? <><EyeOff size={16}/> Dépublier</> : <><Eye size={16}/> Publier</>}
                  </button>
                  <div className="flex gap-2">
                    <button onClick={() => openEdit(partner)} className="flex-1 text-blue-600 bg-blue-50 dark:bg-blue-900/20 hover:bg-blue-100 py-3 rounded-xl text-[10px] font-black uppercase transition-all">
                      Éditer
                    </button>
                    <button onClick={() => handleDelete(partner.id)} className="p-3 text-red-300 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all">
                      <Trash2 size={18} />
                    </button>
                  </div>
               </div>
            </div>
          ))}
          {partners.length === 0 && <div className="col-span-full text-center py-24 text-gray-400 italic bg-white dark:bg-gray-800 rounded-[3rem] border border-dashed border-gray-100 dark:border-gray-700 uppercase tracking-widest font-black text-xs">Aucun partenaire actif</div>}
        </div>
      ) : (
        <div className="space-y-6">
           <div className="bg-orange-50 dark:bg-orange-900/10 p-6 rounded-[2rem] border border-orange-100 dark:border-orange-800/30 flex items-start gap-4 mb-8">
              <AlertCircle className="text-orange-600 shrink-0 mt-1" size={24} />
              <div>
                <p className="text-xs text-orange-800 dark:text-orange-300 font-black uppercase tracking-wider mb-1">Processus de Validation</p>
                <p className="text-sm text-orange-700 dark:text-orange-400 font-medium leading-relaxed">
                  L'approbation d'une demande crée un profil partenaire en mode <strong>Brouillon</strong>. 
                  Rendez-vous dans <strong>"Liste Active"</strong> et cliquez sur <strong>"Publier"</strong> pour le rendre visible.
                </p>
              </div>
           </div>

           {requests.map(req => (
             <div key={req.id} className="bg-white dark:bg-gray-800 p-6 rounded-[2.5rem] shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col md:flex-row gap-6 items-center group">
                <div className="w-24 h-24 bg-gray-50 dark:bg-gray-900 rounded-3xl p-4 flex-shrink-0 border border-gray-100 dark:border-gray-700 overflow-hidden">
                    <img src={req.logoUrl} className="w-full h-full object-contain" alt={req.name} />
                </div>
                <div className="flex-1">
                   <div className="flex justify-between items-start mb-2">
                      <div>
                        <h3 className="text-xl font-black text-gray-900 dark:text-white uppercase tracking-tighter">{req.name}</h3>
                        <p className="text-xs text-brand-600 font-bold uppercase tracking-widest">{req.category}</p>
                      </div>
                      <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest shadow-sm ${
                        req.status === 'pending' ? 'bg-orange-50 text-orange-600 border border-orange-100' : 
                        req.status === 'approved' ? 'bg-green-50 text-green-600 border border-green-100' : 'bg-red-50 text-red-600 border border-red-100'
                      }`}>
                        {req.status === 'pending' ? 'En attente' : req.status === 'approved' ? 'Approuvé' : 'Refusé'}
                      </span>
                   </div>
                   <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4 text-xs font-bold text-gray-500 uppercase tracking-tight">
                      <div className="flex items-center gap-2"><User size={14} className="text-brand-600"/> {req.contactPerson}</div>
                      <div className="flex items-center gap-2"><Phone size={14} className="text-brand-600"/> {req.contactPhone}</div>
                      <div className="flex items-center gap-2"><Mail size={14} className="text-brand-600"/> {req.contactEmail}</div>
                   </div>
                   <div className="bg-gray-50 dark:bg-gray-900 p-5 rounded-2xl border border-gray-100 dark:border-gray-800 italic text-sm text-gray-600 dark:text-gray-300 leading-relaxed shadow-inner">
                      "{req.message}"
                   </div>
                </div>
                {req.status === 'pending' && (
                  <div className="flex md:flex-col gap-3">
                    <button 
                        onClick={() => handleRequestStatus(req.id, 'approved')} 
                        disabled={isProcessing}
                        className="p-5 bg-green-500 text-white rounded-[1.5rem] shadow-lg hover:bg-green-600 transition-all active:scale-90 disabled:opacity-50 flex flex-col items-center gap-1" 
                        title="Approuver"
                    >
                        <Check size={24}/>
                        <span className="text-[8px] font-black uppercase">Valider</span>
                    </button>
                    <button 
                        onClick={() => handleRequestStatus(req.id, 'rejected')} 
                        disabled={isProcessing}
                        className="p-5 bg-red-100 text-red-600 rounded-[1.5rem] hover:bg-red-200 transition-all active:scale-90 disabled:opacity-50 flex flex-col items-center gap-1" 
                        title="Refuser"
                    >
                        <XCircle size={24}/>
                        <span className="text-[8px] font-black uppercase">Refuser</span>
                    </button>
                  </div>
                )}
             </div>
           ))}
           {requests.length === 0 && <div className="text-center py-24 text-gray-400 italic bg-white dark:bg-gray-800 rounded-[2.5rem] border border-dashed border-gray-200 uppercase tracking-widest font-black text-xs">Aucune candidature en attente</div>}
        </div>
      )}

      {isModalOpen && (
        <div className="fixed inset-0 z-[110] bg-black/60 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
           <div className="bg-white dark:bg-gray-800 p-10 rounded-[2.5rem] max-w-md w-full shadow-2xl animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto border border-white/20">
              <div className="flex justify-between mb-8 items-center border-b border-gray-50 dark:border-gray-700 pb-4">
                <h3 className="font-black text-2xl uppercase tracking-tighter text-gray-900 dark:text-white">
                    {editingPartner.id ? 'Éditer' : 'Nouveau'} Partenaire
                </h3>
                <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"><X/></button>
              </div>
              <form onSubmit={handleSubmit} className="space-y-6">
                 <div>
                   <label className="block text-[10px] font-black uppercase text-gray-400 mb-1 tracking-widest">Nom commercial</label>
                   <input type="text" required value={editingPartner.name || ''} onChange={e => setEditingPartner({...editingPartner, name: e.target.value})} className="w-full p-4 bg-gray-50 dark:bg-gray-900 border-0 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-brand-500 dark:text-white" placeholder="Ex: Niger Matériaux" />
                 </div>

                 <div>
                   <label className="block text-[10px] font-black uppercase text-gray-400 mb-1 tracking-widest">Secteur</label>
                   <select value={editingPartner.category || 'Matériel'} onChange={e => setEditingPartner({...editingPartner, category: e.target.value})} className="w-full p-4 bg-gray-50 dark:bg-gray-900 border-0 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-brand-500 dark:text-white">
                      <option value="Matériel">Vente de Matériel</option>
                      <option value="Logistique">Logistique / Transport</option>
                      <option value="Finance">Services Financiers</option>
                      <option value="Formation">Formation / Conseil</option>
                      <option value="Autre">Autre</option>
                   </select>
                 </div>
                 
                 <div>
                   <label className="block text-[10px] font-black uppercase text-gray-400 mb-2 tracking-widest">Identité Visuelle (Logo)</label>
                   <div className="flex items-center gap-4">
                      <div className="h-24 w-24 bg-gray-50 dark:bg-gray-900 rounded-3xl border border-gray-200 dark:border-gray-700 flex items-center justify-center overflow-hidden p-3 shadow-inner">
                        {editingPartner.logoUrl ? <img src={editingPartner.logoUrl} className="max-h-full max-w-full object-contain" alt="Preview"/> : <ImageIcon className="text-gray-300"/>}
                      </div>
                      <label className="flex-1 flex flex-col items-center px-4 py-4 bg-white dark:bg-gray-900 text-brand-600 rounded-2xl shadow-sm border border-brand-100 dark:border-gray-700 cursor-pointer hover:bg-brand-50 dark:hover:bg-gray-800 transition-colors">
                        <Upload size={20} />
                        <span className="text-[10px] font-black uppercase mt-1">Uploader</span>
                        <input type="file" className="hidden" accept="image/*" onChange={handleFileChange} />
                      </label>
                   </div>
                 </div>

                 <div className="bg-brand-50 dark:bg-brand-900/20 p-6 rounded-[2rem] border border-brand-100 dark:border-gray-700 shadow-inner">
                    <label className="block text-[10px] font-black uppercase text-brand-600 mb-4 text-center tracking-widest">Type de redirection</label>
                    <div className="grid grid-cols-2 gap-3">
                        <button 
                            type="button"
                            onClick={() => setLinkTarget('external')}
                            className={`py-3 px-3 rounded-2xl text-[10px] font-black uppercase transition-all ${linkTarget === 'external' ? 'bg-brand-600 text-white shadow-lg' : 'bg-white dark:bg-gray-800 text-gray-400 border border-brand-100 dark:border-gray-700'}`}
                        >
                            Site Web
                        </button>
                        <button 
                            type="button"
                            onClick={() => setLinkTarget('shop')}
                            className={`py-3 px-3 rounded-2xl text-[10px] font-black uppercase transition-all ${linkTarget === 'shop' ? 'bg-brand-600 text-white shadow-lg' : 'bg-white dark:bg-gray-800 text-gray-400 border border-brand-100 dark:border-gray-700'}`}
                        >
                            Boutique
                        </button>
                    </div>

                    {linkTarget === 'external' ? (
                        <div className="mt-4">
                            <input 
                                type="url" 
                                value={editingPartner.websiteUrl === '/boutique' ? '' : editingPartner.websiteUrl || ''} 
                                onChange={e => setEditingPartner({...editingPartner, websiteUrl: e.target.value})} 
                                className="w-full p-4 bg-white dark:bg-gray-800 border border-brand-100 dark:border-gray-700 rounded-2xl text-xs font-bold outline-none focus:ring-2 focus:ring-brand-500 dark:text-white" 
                                placeholder="https://www.monsite.ne" 
                            />
                        </div>
                    ) : (
                        <div className="mt-4 text-[10px] font-black text-brand-600 text-center uppercase tracking-widest bg-white dark:bg-gray-800 py-4 rounded-2xl border border-brand-100 dark:border-gray-700 shadow-inner">
                           Redirection : /boutique
                        </div>
                    )}
                 </div>

                 <div>
                   <label className="block text-[10px] font-black uppercase text-gray-400 mb-1 tracking-widest">Slogan Public (Accueil)</label>
                   <textarea rows={3} value={editingPartner.comment || ''} onChange={e => setEditingPartner({...editingPartner, comment: e.target.value})} className="w-full p-4 bg-gray-50 dark:bg-gray-900 border-0 rounded-2xl font-medium outline-none focus:ring-2 focus:ring-brand-500 dark:text-white" placeholder="Ex: Notre expertise pour vos fondations..." />
                 </div>

                 <div className="flex items-center gap-3 p-5 bg-brand-50 dark:bg-brand-900/30 rounded-2xl border border-brand-100 dark:border-brand-800 shadow-inner">
                    <input 
                        type="checkbox" 
                        checked={editingPartner.isVisible} 
                        onChange={e => setEditingPartner({...editingPartner, isVisible: e.target.checked})} 
                        id="isVisible" 
                        className="w-6 h-6 text-brand-600 rounded-lg focus:ring-brand-500" 
                    />
                    <div>
                        <label htmlFor="isVisible" className="text-[10px] font-black uppercase text-gray-900 dark:text-brand-300 select-none block">Mettre en ligne</label>
                        <p className="text-[9px] text-brand-600/60 font-bold uppercase">Cochez pour publier immédiatement</p>
                    </div>
                 </div>

                 <button 
                    type="submit" 
                    disabled={isProcessing}
                    className="w-full bg-brand-600 text-white py-5 rounded-2xl font-black shadow-xl hover:bg-brand-700 transition-all active:scale-95 uppercase tracking-widest text-sm disabled:opacity-50"
                >
                   {isProcessing ? 'Enregistrement...' : (editingPartner.id ? 'Sauvegarder' : 'Créer Partenaire')}
                 </button>
              </form>
           </div>
        </div>
      )}
    </div>
  );
};

export default Partners;
