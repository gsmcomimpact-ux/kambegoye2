
import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Lock, AlertCircle, ArrowLeft, ShieldCheck, Loader2 } from 'lucide-react';
import { db } from '../../services/db';

const Login = () => {
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // Sécurité : Si déjà connecté, on redirige
  useEffect(() => {
    if (db.getCurrentAdmin()) {
        navigate('/admin');
    }
  }, [navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const success = await db.verifyAdmin(username, password);
      
      if (success) {
        // Petit délai pour l'expérience utilisateur
        setTimeout(() => {
            navigate('/admin');
        }, 800);
      } else {
        setError('Identifiants incorrects ou serveur indisponible.');
        setLoading(false);
      }
    } catch (e) {
      setError('Erreur critique de connexion.');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 dark:bg-gray-900 px-4">
      <div className="max-w-md w-full space-y-8 bg-white dark:bg-gray-800 p-10 rounded-[2.5rem] shadow-2xl border border-gray-100 dark:border-gray-700 animate-in fade-in duration-500">
        <div className="text-center">
          <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-3xl bg-brand-600 shadow-xl shadow-brand-500/20">
            <Lock className="h-8 w-8 text-white" />
          </div>
          <h2 className="mt-6 text-3xl font-black text-gray-900 dark:text-white uppercase tracking-tighter">Administration</h2>
          <p className="mt-2 text-sm text-gray-500 dark:text-gray-400 font-medium">Espace sécurisé KAMBEGOYE</p>
        </div>

        <form className="mt-10 space-y-6" onSubmit={handleLogin}>
          <div className="space-y-4">
            <div>
              <label className="block text-[10px] font-black uppercase text-gray-400 mb-1 tracking-widest ml-1">Utilisateur</label>
              <input
                type="text"
                required
                autoFocus
                disabled={loading}
                className="block w-full px-5 py-4 border-0 bg-gray-50 dark:bg-gray-700 dark:text-white rounded-2xl font-bold focus:ring-2 focus:ring-brand-500 outline-none transition-all"
                placeholder="Ex: admin"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-[10px] font-black uppercase text-gray-400 mb-1 tracking-widest ml-1">Mot de passe</label>
              <input
                type="password"
                required
                disabled={loading}
                className="block w-full px-5 py-4 border-0 bg-gray-50 dark:bg-gray-700 dark:text-white rounded-2xl font-bold focus:ring-2 focus:ring-brand-500 outline-none transition-all"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </div>

          {error && (
            <div className="text-red-600 text-xs font-bold flex items-center gap-2 bg-red-50 dark:bg-red-900/20 p-4 rounded-2xl border border-red-100 dark:border-red-900/30">
              <AlertCircle className="w-5 h-5 shrink-0" /> {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="group relative w-full flex justify-center py-5 px-4 border border-transparent text-sm font-black rounded-2xl text-white bg-brand-600 hover:bg-brand-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-500 disabled:opacity-50 transition-all shadow-xl active:scale-95 uppercase tracking-widest"
          >
            {loading ? (
                <span className="flex items-center gap-2">
                    <Loader2 className="animate-spin h-5 w-5" />
                    Identification...
                </span>
            ) : (
                <span className="flex items-center gap-2">
                    <ShieldCheck className="h-5 w-5" />
                    Se connecter
                </span>
            )}
          </button>
        </form>

        <div className="mt-8 p-4 bg-brand-50 dark:bg-brand-900/20 rounded-2xl border border-brand-100 dark:border-brand-800">
            <p className="text-[10px] text-brand-700 dark:text-brand-300 font-bold uppercase text-center leading-relaxed italic">
                Utilisez les identifiants de secours fournis dans la documentation technique en cas de perte d'accès.
            </p>
        </div>

        <div className="text-center mt-6">
            <Link to="/" className="inline-flex items-center text-xs font-black uppercase text-gray-400 hover:text-brand-600 transition-colors tracking-widest">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Retour au site public
            </Link>
        </div>
      </div>
    </div>
  );
};

export default Login;
