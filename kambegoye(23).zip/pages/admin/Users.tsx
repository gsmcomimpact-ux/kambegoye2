
import React, { useEffect, useState } from 'react';
import { UserPlus, Trash2, Shield, User, X, BadgeCheck } from 'lucide-react';
import { db } from '../../services/db';
import { AdminUser } from '../../types';

const Users = () => {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<Partial<AdminUser>>({ role: 'staff', firstName: '', lastName: '' });
  const [currentUser, setCurrentUser] = useState<AdminUser | null>(null);

  useEffect(() => { 
      loadData(); 
      setCurrentUser(db.getCurrentAdmin());
  }, []);

  const loadData = async () => setUsers(await db.getAdminUsers());

  const handleDelete = async (id: string) => {
    if (currentUser?.role !== 'superadmin') {
        alert("Action réservée aux SuperAdmin");
        return;
    }
    if (id === currentUser?.id) {
        alert("Vous ne pouvez pas vous supprimer vous-même");
        return;
    }
    if (window.confirm('Supprimer ce compte gestionnaire ?')) {
      await db.deleteAdminUser(id);
      loadData();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (currentUser?.role !== 'superadmin') return;
    // @ts-ignore
    await db.saveAdminUser(editingUser as AdminUser);
    setIsModalOpen(false);
    loadData();
  };

  if (currentUser?.role !== 'superadmin') {
      return (
          <div className="p-12 text-center animate-in fade-in">
             <Shield size={64} className="mx-auto text-red-500 mb-4 opacity-20" />
             <h2 className="text-2xl font-black text-gray-800 dark:text-white">Accès Restreint</h2>
             <p className="text-gray-500">Seul un Super-Administrateur peut gérer les comptes d'accès.</p>
          </div>
      );
  }

  return (
    <div className="animate-in fade-in duration-500">
      <div className="flex justify-between items-center mb-8">
        <div>
            <h2 className="text-2xl font-black text-gray-800 dark:text-white">Équipe de Gestion</h2>
            <p className="text-gray-500 text-sm">Contrôlez les accès au panneau d'administration</p>
        </div>
        <button onClick={() => { setEditingUser({ role: 'staff', firstName: '', lastName: '', username: '' }); setIsModalOpen(true); }} className="bg-brand-600 text-white px-6 py-2 rounded-xl font-bold flex items-center gap-2 shadow-lg hover:bg-brand-700 transition-all">
            <UserPlus size={18} /> Nouveau Gestionnaire
        </button>
      </div>

      <div className="bg-white dark:bg-gray-800 shadow-sm rounded-3xl overflow-hidden border border-gray-100 dark:border-gray-700">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-900">
            <tr>
              <th className="px-6 py-4 text-left text-[10px] font-black uppercase tracking-wider text-gray-400">Identité & Rôle</th>
              <th className="px-6 py-4 text-left text-[10px] font-black uppercase tracking-wider text-gray-400">Pseudonyme</th>
              <th className="px-6 py-4 text-right text-[10px] font-black uppercase tracking-wider text-gray-400">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
            {users.map(user => (
              <tr key={user.id} className="hover:bg-gray-50 dark:hover:bg-gray-900/50 transition-colors">
                <td className="px-6 py-4 whitespace-nowrap">
                   <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-xl ${user.role === 'superadmin' ? 'bg-red-50 text-red-600' : 'bg-brand-50 text-brand-600'}`}>
                         {user.role === 'superadmin' ? <Shield size={20}/> : <User size={20}/>}
                      </div>
                      <div className="flex flex-col">
                        <span className="font-bold text-gray-900 dark:text-white uppercase text-sm">
                            {user.firstName && user.lastName ? `${user.firstName} ${user.lastName}` : "Identité non renseignée"}
                        </span>
                        <span className={`text-[9px] font-black uppercase w-fit px-1.5 rounded ${user.role === 'superadmin' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-600'}`}>
                            {user.role}
                        </span>
                      </div>
                   </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                   <span className="text-sm font-mono text-gray-500 font-bold bg-gray-50 dark:bg-gray-900 px-2 py-1 rounded-lg">@{user.username}</span>
                   {user.id === currentUser?.id && <span className="ml-2 text-[10px] font-black text-brand-600 uppercase">C'est vous</span>}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right">
                  {user.id !== currentUser?.id && (
                    <button onClick={() => handleDelete(user.id)} className="p-2 text-red-300 hover:text-red-600 transition-colors" title="Révoquer l'accès">
                        <Trash2 size={18} />
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[100] bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
           <div className="bg-white dark:bg-gray-800 p-8 rounded-3xl max-w-md w-full shadow-2xl animate-in zoom-in-95 duration-200">
              <div className="flex justify-between items-center mb-8">
                <h3 className="font-black text-2xl flex items-center gap-2">
                    <BadgeCheck className="text-brand-600" /> Accès Personnel
                </h3>
                <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"><X/></button>
              </div>
              <form onSubmit={handleSubmit} className="space-y-5">
                 <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-[10px] font-black uppercase text-gray-400 mb-1">Prénom</label>
                        <input type="text" required value={editingUser.firstName || ''} onChange={e => setEditingUser({...editingUser, firstName: e.target.value})} className="w-full p-3 border rounded-xl dark:bg-gray-700 dark:border-gray-600 font-bold outline-none focus:ring-2 focus:ring-brand-500" placeholder="Ex: Jean" />
                    </div>
                    <div>
                        <label className="block text-[10px] font-black uppercase text-gray-400 mb-1">Nom</label>
                        <input type="text" required value={editingUser.lastName || ''} onChange={e => setEditingUser({...editingUser, lastName: e.target.value})} className="w-full p-3 border rounded-xl dark:bg-gray-700 dark:border-gray-600 font-bold outline-none focus:ring-2 focus:ring-brand-500" placeholder="Ex: Dupont" />
                    </div>
                 </div>

                 <div>
                   <label className="block text-[10px] font-black uppercase text-gray-400 mb-1">Nom d'utilisateur (Pseudonyme)</label>
                   <input type="text" required value={editingUser.username || ''} onChange={e => setEditingUser({...editingUser, username: e.target.value.toLowerCase().replace(/\s/g, '')})} className="w-full p-3 border rounded-xl dark:bg-gray-700 dark:border-gray-600 font-mono font-bold outline-none focus:ring-2 focus:ring-brand-500" placeholder="Ex: jdupont" />
                 </div>
                 <div>
                   <label className="block text-[10px] font-black uppercase text-gray-400 mb-1">Mot de passe provisoire</label>
                   <input type="password" required value={editingUser.password || ''} onChange={e => setEditingUser({...editingUser, password: e.target.value})} className="w-full p-3 border rounded-xl dark:bg-gray-700 dark:border-gray-600 font-bold outline-none focus:ring-2 focus:ring-brand-500" />
                 </div>
                 <div>
                   <label className="block text-[10px] font-black uppercase text-gray-400 mb-1">Privilèges</label>
                   <select value={editingUser.role} onChange={e => setEditingUser({...editingUser, role: e.target.value as any})} className="w-full p-3 border rounded-xl dark:bg-gray-700 dark:border-gray-600 font-bold outline-none focus:ring-2 focus:ring-brand-500">
                       <option value="staff">Gestionnaire (Limité)</option>
                       <option value="superadmin">Super-Administrateur</option>
                   </select>
                 </div>
                 
                 <div className="bg-brand-50 dark:bg-brand-900/20 p-4 rounded-xl text-xs text-brand-700 dark:text-brand-300 italic border border-brand-100 dark:border-brand-800">
                    Les gestionnaires ne peuvent pas supprimer de données sensibles ni gérer les comptes d'autrui.
                 </div>

                 <button type="submit" className="w-full bg-brand-600 text-white py-4 rounded-xl font-black shadow-lg hover:bg-brand-700 transition-all active:scale-95">CRÉER LE COMPTE</button>
              </form>
           </div>
        </div>
      )}
    </div>
  );
};

export default Users;
