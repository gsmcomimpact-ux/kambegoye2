import React, { useEffect, useState } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { LayoutDashboard, Users, Wallet, LogOut, Home, Database, Settings, ShoppingBag, Tags, FileText, Image, Users as UsersIcon, ShieldAlert, Handshake, Package, Briefcase } from 'lucide-react';
import { db } from '../../services/db';
import { AdminUser } from '../../types';

const AdminLayout = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState<AdminUser | null>(null);

  useEffect(() => {
    const user = db.getCurrentAdmin();
    const token = localStorage.getItem('kambegoye_admin_token');
    
    if (!token || !user) {
      navigate('/admin/login');
    } else {
      setCurrentUser(user);
    }
  }, [navigate, location.pathname]);

  const handleLogout = () => {
    db.logoutAdmin();
    navigate('/admin/login');
  };

  const allNavItems = [
    { name: 'Dashboard', path: '/admin', icon: LayoutDashboard, roles: ['superadmin', 'staff'] },
    { name: 'Facturation', path: '/admin/facturation', icon: FileText, roles: ['superadmin', 'staff'] },
    { name: 'Litiges', path: '/admin/litiges', icon: ShieldAlert, roles: ['superadmin', 'staff'] },
    { name: 'Projets / Devis', path: '/admin/projets', icon: FileText, roles: ['superadmin', 'staff'] },
    { name: 'Ouvriers', path: '/admin/ouvriers', icon: Users, roles: ['superadmin', 'staff'] },
    { name: 'Métiers', path: '/admin/specialties', icon: Briefcase, roles: ['superadmin'] },
    { name: 'Boutique (Catalogue)', path: '/admin/produits', icon: ShoppingBag, roles: ['superadmin', 'staff'] },
    { name: 'Bons de Commande', path: '/admin/commandes', icon: Package, roles: ['superadmin', 'staff'] },
    { name: 'Catégories Prod.', path: '/admin/categories-produits', icon: Tags, roles: ['superadmin', 'staff'] },
    { name: 'Partenaires', path: '/admin/partenaires', icon: Handshake, roles: ['superadmin'] },
    { name: 'Utilisateurs', path: '/admin/utilisateurs', icon: UsersIcon, roles: ['superadmin'] },
    { name: 'Paiements', path: '/admin/paiements', icon: Wallet, roles: ['superadmin'] },
    { name: 'Médiathèque', path: '/admin/media', icon: Image, roles: ['superadmin', 'staff'] },
    { name: 'Données', path: '/admin/data', icon: Database, roles: ['superadmin'] },
    { name: 'Paramètres', path: '/admin/settings', icon: Settings, roles: ['superadmin'] },
  ];

  const navItems = allNavItems.filter(item => item.roles.includes(currentUser?.role || ''));

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-900">
      {/* Sidebar */}
      <div className="w-64 bg-white dark:bg-gray-800 shadow-md hidden md:flex flex-col">
        <div className="p-6">
          <Link to="/admin" className="block hover:opacity-80 transition-opacity">
            <h1 className="text-2xl font-black text-brand-600 uppercase tracking-tighter italic">KAMBEGOYE</h1>
          </Link>
          <p className="text-[10px] text-gray-500 mt-1 uppercase font-bold tracking-widest">
              Gestion: <span className="text-brand-700 dark:text-brand-400">{currentUser?.username}</span> 
              <span className="block opacity-60">({currentUser?.role})</span>
          </p>
        </div>
        
        <nav className="flex-1 px-4 space-y-1 overflow-y-auto custom-scrollbar">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center px-4 py-2.5 text-sm font-medium rounded-md transition-colors ${
                location.pathname === item.path
                  ? 'bg-brand-50 text-brand-600 dark:bg-gray-700 dark:text-brand-400'
                  : 'text-gray-600 hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-700'
              }`}
            >
              <item.icon className="h-4 w-4 mr-3" />
              {item.name}
            </Link>
          ))}
        </nav>

        <div className="p-4 border-t border-gray-200 dark:border-gray-700 space-y-2">
          <Link
             to="/"
             className="flex items-center w-full px-4 py-2 text-sm font-bold text-brand-600 hover:bg-brand-50 rounded-md transition-colors"
          >
            <Home className="h-4 w-4 mr-3" />
            Retour au Site
          </Link>
          <button
            onClick={handleLogout}
            className="flex items-center w-full px-4 py-2 text-sm font-bold text-red-600 hover:bg-red-50 rounded-md transition-colors"
          >
            <LogOut className="h-4 w-4 mr-3" />
            Déconnexion
          </button>
        </div>
      </div>

      {/* Mobile Header & Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="md:hidden bg-white dark:bg-gray-800 shadow-sm p-4 flex justify-between items-center">
           <Link to="/admin" className="font-black text-lg text-brand-600 uppercase italic">KAMBEGOYE Admin</Link>
           <div className="flex items-center gap-4">
             <Link to="/"><Home size={20} className="text-gray-600 dark:text-gray-300" /></Link>
             <button onClick={handleLogout} className="text-red-500"><LogOut size={20}/></button>
           </div>
        </header>
        
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 dark:bg-gray-900 p-6">
           <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
