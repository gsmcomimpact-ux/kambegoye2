
import React, { useEffect, useState } from 'react';
import { Edit, Trash2, Plus, X, Check, XCircle, Clock, Upload, User, Link as LinkIcon, CheckCircle2 } from 'lucide-react';
import { db } from '../../services/db';
import { Worker, Specialty, Neighborhood } from '../../types';

const Workers = () => {
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [specialties, setSpecialties] = useState<Specialty[]>([]);
  const [neighborhoods, setNeighborhoods] = useState<Neighborhood[]>([]);
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingWorker, setEditingWorker] = useState<Partial<Worker>>({});
  const [viewFilter, setViewFilter] = useState<'active' | 'pending' | 'rejected'>('active');
  const [copySuccess, setCopySuccess] = useState<string | null>(null);

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    const [w, s, n] = await Promise.all([db.getWorkers(), db.getSpecialties(), db.getNeighborhoods()]);
    setWorkers(w);
    setSpecialties(s);
    setNeighborhoods(n);
  };

  const handleCopyPaymentLink = (workerId: string) => {
      const url = `${window.location.origin}/payment?worker_id=${workerId}`;
      navigator.clipboard.writeText(url);
      setCopySuccess(workerId);
      setTimeout(() => setCopySuccess(null), 2000);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Supprimer cet ouvrier ?')) {
      await db.deleteWorker(id);
      loadData();
    }
  };

  const handleEdit = (worker: Worker) => {
    setEditingWorker(worker);
    setIsModalOpen(true);
  };
  
  const handleStatusChange = async (worker: Worker, newStatus: 'active' | 'rejected') => {
      const updatedWorker = { ...worker, accountStatus: newStatus };
      await db.saveWorker(updatedWorker);
      loadData();
  };

  const handleCreate = () => {
    setEditingWorker({
      id: Math.random().toString(36).substr(2, 9),
      firstName: '',
      lastName: '',
      availability: 'available',
      rating: 5,
      reviewCount: 0,
      isVerified: false,
      workImages: [],
      photoUrl: 'https://picsum.photos/200',
      latitude: 13.51,
      longitude: 2.11,
      accountStatus: 'active'
    });
    setIsModalOpen(true);
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>, field: 'photoUrl' | 'idCardUrl') => {
      if (e.target.files && e.target.files[0]) {
          const file = e.target.files[0];
          try {
              const dataUrl = await db.fileToDataURL(file);
              setEditingWorker(prev => ({ ...prev, [field]: dataUrl }));
          } catch (error) {
              alert("Erreur lecture fichier");
          }
      }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingWorker.firstName && editingWorker.lastName) {
      await db.saveWorker(editingWorker as Worker);
      setIsModalOpen(false);
      loadData();
    }
  };

  const getSpecialtyName = (id: string) => specialties.find(s => s.id === id)?.name || id;

  const filteredWorkers = workers.filter(w => {
      if (viewFilter === 'pending') return w.accountStatus === 'pending';
      if (viewFilter === 'rejected') return w.accountStatus === 'rejected';
      return w.accountStatus === 'active' || w.accountStatus === undefined;
  });

  return (
    <div className="animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
        <div>
            <h2 className="text-3xl font-black text-gray-800 dark:text-white uppercase tracking-tighter">Ouvriers</h2>
            <p className="text-gray-500 text-[10px] font-black uppercase tracking-widest">Base de données des professionnels Niamey</p>
        </div>
        
        <div className="flex gap-2 bg-white dark:bg-gray-800 p-1.5 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm">
            <button onClick={() => setViewFilter('active')} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${viewFilter === 'active' ? 'bg-brand-600 text-white shadow-lg' : 'text-gray-400 hover:text-gray-600'}`}>Actifs</button>
            <button onClick={() => setViewFilter('pending')} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase flex items-center transition-all ${viewFilter === 'pending' ? 'bg-orange-500 text-white shadow-lg' : 'text-gray-400 hover:text-gray-600'}`}>
                <Clock className="w-3.5 h-3.5 mr-2" /> Attente ({workers.filter(w => w.accountStatus === 'pending').length})
            </button>
        </div>
        <button onClick={handleCreate} className="bg-brand-600 text-white px-6 py-3 rounded-xl flex items-center font-black text-[10px] uppercase tracking-widest shadow-xl hover:bg-brand-700 transition-all active:scale-95"><Plus className="w-4 h-4 mr-2" /> Ajouter un expert</button>
      </div>

      <div className="bg-white dark:bg-gray-800 shadow-sm rounded-[2.5rem] overflow-hidden border border-gray-100 dark:border-gray-700">
        <table className="min-w-full divide-y divide-gray-100 dark:divide-gray-700">
          <thead className="bg-gray-50/50 dark:bg-gray-900/50">
            <tr>
              <th className="px-8 py-5 text-left text-[10px] font-black uppercase tracking-wider text-gray-400">Expert / ID</th>
              <th className="px-8 py-5 text-left text-[10px] font-black uppercase tracking-wider text-gray-400">Métier</th>
              <th className="px-8 py-5 text-left text-[10px] font-black uppercase tracking-wider text-gray-400">Statut</th>
              <th className="px-8 py-5 text-right text-[10px] font-black uppercase tracking-wider text-gray-400">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50 dark:divide-gray-800">
            {filteredWorkers.map((worker) => (
              <tr key={worker.id} className="hover:bg-gray-50/50 dark:hover:bg-gray-900/30 transition-colors group">
                <td className="px-8 py-5">
                  <div className="flex items-center gap-4">
                    <img className="h-12 w-12 rounded-2xl object-cover shadow-sm ring-2 ring-brand-50" src={worker.photoUrl} alt="" />
                    <div className="flex flex-col">
                      <div className="text-sm font-black text-gray-900 dark:text-white uppercase tracking-tight">{worker.firstName} {worker.lastName}</div>
                      <div className="text-[10px] font-bold text-gray-400 font-mono tracking-tighter">#{worker.id.toUpperCase()}</div>
                    </div>
                  </div>
                </td>
                <td className="px-8 py-5">
                    <span className="text-[10px] font-black text-brand-600 uppercase bg-brand-50 dark:bg-brand-900/30 px-3 py-1 rounded-full border border-brand-100 dark:border-brand-800">{getSpecialtyName(worker.specialtyId)}</span>
                </td>
                <td className="px-8 py-5">
                   <span className={`px-2 py-1 rounded text-[9px] font-black uppercase ${worker.accountStatus === 'active' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'}`}>
                       {worker.accountStatus === 'active' ? '● En ligne' : worker.accountStatus === 'pending' ? '○ Validation' : 'Rejeté'}
                   </span>
                </td>
                <td className="px-8 py-5 text-right">
                  <div className="flex justify-end gap-2">
                    {worker.accountStatus === 'active' && (
                        <button 
                            onClick={() => handleCopyPaymentLink(worker.id)} 
                            className={`p-2.5 rounded-xl transition-all border flex items-center gap-2 ${copySuccess === worker.id ? 'bg-green-50 text-green-600 border-green-200' : 'bg-gray-50 text-gray-400 hover:text-brand-600 border-gray-100'}`}
                            title="Copier lien de déblocage"
                        >
                            {copySuccess === worker.id ? <CheckCircle2 size={16}/> : <LinkIcon size={16}/>}
                            {copySuccess === worker.id && <span className="text-[8px] font-black uppercase">Copié</span>}
                        </button>
                    )}
                    
                    {worker.accountStatus === 'pending' ? (
                        <>
                          <button onClick={() => handleStatusChange(worker, 'active')} className="p-2.5 text-green-600 bg-green-50 rounded-xl hover:bg-green-100 transition-colors" title="Valider"><Check size={18}/></button>
                          <button onClick={() => handleStatusChange(worker, 'rejected')} className="p-2.5 text-red-600 bg-red-50 rounded-xl hover:bg-red-100 transition-colors" title="Rejeter"><XCircle size={18}/></button>
                        </>
                    ) : (
                        <>
                          <button onClick={() => handleEdit(worker)} className="p-2.5 text-gray-400 hover:text-brand-600 bg-gray-50 rounded-xl transition-all border border-gray-100" title="Éditer"><Edit size={16}/></button>
                          <button onClick={() => handleDelete(worker.id)} className="p-2.5 text-red-300 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all" title="Supprimer"><Trash2 size={16}/></button>
                        </>
                    )}
                  </div>
                </td>
              </tr>
            ))}
             {filteredWorkers.length === 0 && <tr><td colSpan={4} className="px-8 py-20 text-center text-gray-400 italic font-black uppercase text-xs tracking-widest">Aucun expert dans cette catégorie</td></tr>}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[110] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-gray-800 rounded-[3rem] max-w-lg w-full p-10 shadow-2xl animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto border border-white/20">
            <div className="flex justify-between items-center mb-8 border-b border-gray-50 pb-4">
              <h3 className="text-2xl font-black text-gray-900 dark:text-white uppercase tracking-tighter flex items-center gap-3">
                <User className="text-brand-600" /> {editingWorker.id ? 'Édition Profil' : 'Nouvel Ouvrier'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"><X/></button>
            </div>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-black uppercase text-gray-400 mb-1 tracking-widest">Prénom</label>
                  <input type="text" required value={editingWorker.firstName || ''} onChange={e => setEditingWorker({...editingWorker, firstName: e.target.value})} className="w-full p-4 bg-gray-50 dark:bg-gray-700 border-0 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-brand-500" />
                </div>
                <div>
                  <label className="block text-[10px] font-black uppercase text-gray-400 mb-1 tracking-widest">Nom</label>
                  <input type="text" required value={editingWorker.lastName || ''} onChange={e => setEditingWorker({...editingWorker, lastName: e.target.value})} className="w-full p-4 bg-gray-50 dark:bg-gray-700 border-0 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-brand-500" />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-black uppercase text-gray-400 mb-1 tracking-widest">Métier</label>
                <select required value={editingWorker.specialtyId || ''} onChange={e => setEditingWorker({...editingWorker, specialtyId: e.target.value})} className="w-full p-4 bg-gray-50 dark:bg-gray-700 border-0 rounded-2xl font-black uppercase text-xs outline-none focus:ring-2 focus:ring-brand-500">
                  <option value="">Sélectionner...</option>
                  {specialties.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-black uppercase text-gray-400 mb-1 tracking-widest">Quartier</label>
                <select required value={editingWorker.neighborhoodId || ''} onChange={e => setEditingWorker({...editingWorker, neighborhoodId: e.target.value})} className="w-full p-4 bg-gray-50 dark:bg-gray-700 border-0 rounded-2xl font-black uppercase text-xs outline-none focus:ring-2 focus:ring-brand-500">
                  <option value="">Sélectionner...</option>
                  {neighborhoods.map(n => <option key={n.id} value={n.id}>{n.name}</option>)}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-black uppercase text-gray-400 mb-1 tracking-widest">Appel</label>
                  <input type="text" value={editingWorker.phone || ''} onChange={e => setEditingWorker({...editingWorker, phone: e.target.value})} className="w-full p-4 bg-gray-50 dark:bg-gray-700 border-0 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-brand-500" />
                </div>
                <div>
                  <label className="block text-[10px] font-black uppercase text-gray-400 mb-1 tracking-widest">WhatsApp</label>
                  <input type="text" value={editingWorker.whatsapp || ''} onChange={e => setEditingWorker({...editingWorker, whatsapp: e.target.value})} className="w-full p-4 bg-gray-50 dark:bg-gray-700 border-0 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-brand-500" />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-black uppercase text-gray-400 mb-2 tracking-widest">Photo de Profil</label>
                <div className="flex items-center gap-4">
                    <img src={editingWorker.photoUrl} className="h-20 w-20 rounded-[1.5rem] object-cover shadow-sm border border-brand-50" alt="Preview" />
                    <label className="flex-1 cursor-pointer bg-brand-50 dark:bg-brand-900/30 border border-brand-100 dark:border-brand-800 rounded-2xl py-4 px-4 flex items-center justify-center gap-2 text-[10px] font-black uppercase text-brand-600 hover:bg-brand-100 transition-all">
                        <Upload size={18} /> Changer la photo
                        <input type="file" className="hidden" accept="image/*" onChange={(e) => handleFileChange(e, 'photoUrl')} />
                    </label>
                </div>
              </div>

              <div className="flex gap-4 pt-6">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 px-6 py-4 bg-gray-100 dark:bg-gray-700 rounded-2xl font-black uppercase tracking-widest text-[10px] transition-all">Annuler</button>
                <button type="submit" className="flex-1 bg-brand-600 text-white px-6 py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-xl hover:bg-brand-700 transition-all active:scale-95">Enregistrer</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Workers;
