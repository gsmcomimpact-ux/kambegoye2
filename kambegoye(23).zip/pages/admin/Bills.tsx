
import React, { useEffect, useState } from 'react';
import { Plus, Trash2, FileText, Download, Printer, X, Save, FilePlus, Phone, User, Tag, Briefcase, MessageCircle, Send, FileSpreadsheet } from 'lucide-react';
import { useLocation } from 'react-router-dom';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { db } from '../../services/db';
import { Bill, BillItem, ProjectRequest } from '../../types';

// Helper for numbers to French words
const numberToFrenchWords = (n: number): string => {
  const units = ['', 'un', 'deux', 'trois', 'quatre', 'cinq', 'six', 'sept', 'huit', 'neuf'];
  const tens = ['', 'dix', 'vingt', 'trente', 'quarante', 'cinquante', 'soixante', 'soixante-dix', 'quatre-vingt', 'quatre-vingt-dix'];
  const teens = ['dix', 'onze', 'douze', 'treize', 'quatorze', 'quinze', 'seize', 'dix-sept', 'dix-huit', 'dix-neuf'];

  if (n === 0) return 'zéro';
  const convert = (num: number): string => {
    let word = '';
    if (num >= 100) {
      word += (Math.floor(num / 100) === 1 ? '' : units[Math.floor(num / 100)]) + ' cent ';
      num %= 100;
    }
    if (num >= 20) {
      word += tens[Math.floor(num / 10)];
      if (num % 10 > 0) word += (Math.floor(num / 10) === 7 || Math.floor(num / 10) === 9 ? '-' + teens[num % 10] : '-' + units[num % 10]);
    } else if (num >= 10) word += teens[num - 10];
    else if (num > 0) word += units[num];
    return word.trim();
  };

  let result = '';
  if (n >= 1000000) { result += convert(Math.floor(n / 1000000)) + ' million' + (Math.floor(n / 1000000) > 1 ? 's ' : ' '); n %= 1000000; }
  if (n >= 1000) { result += (Math.floor(n / 1000) === 1 ? '' : convert(Math.floor(n / 1000))) + ' mille '; n %= 1000; }
  result += convert(n);
  return result.trim().toUpperCase();
};

const formatPrice = (price: number): string => {
  return new Intl.NumberFormat('fr-FR').format(price).replace(/\s/g, '.') + ' FCFA';
};

const Bills = () => {
  const [bills, setBills] = useState<Bill[]>([]);
  const [projects, setProjects] = useState<ProjectRequest[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const location = useLocation();
  const [editingBill, setEditingBill] = useState<Partial<Bill>>({
      type: 'quote',
      date: new Date().toISOString().slice(0, 10),
      items: [{ description: '', quantity: 1, unitPrice: 0 }],
      status: 'pending',
      clientName: '',
      clientPhone: '',
      projectId: ''
  });

  useEffect(() => { 
    loadData(); 
    if (location.state && (location.state as any).prefill) {
        const prefill = (location.state as any).prefill;
        setEditingBill({
            ...editingBill,
            ...prefill,
            date: new Date().toISOString().slice(0, 10),
            number: (prefill.type === 'quote' ? 'DEV-' : 'FAC-') + Date.now().toString().slice(-6),
            status: prefill.status || 'pending',
            projectId: prefill.projectId || ''
        });
        setIsModalOpen(true);
        window.history.replaceState({}, document.title);
    }
  }, [location]);

  const loadData = async () => {
    const [b, p] = await Promise.all([db.getBills(), db.getProjectRequests()]);
    setBills(b);
    setProjects(p);
  };

  const calculateTotal = (items?: BillItem[]) => {
      return (items || editingBill.items || []).reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);
  };

  const handleAddItem = () => {
      setEditingBill({ ...editingBill, items: [...(editingBill.items || []), { description: '', quantity: 1, unitPrice: 0 }] });
  };

  const handleRemoveItem = (index: number) => {
      setEditingBill({ ...editingBill, items: (editingBill.items || []).filter((_, i) => i !== index) });
  };

  const handleItemChange = (index: number, field: keyof BillItem, value: any) => {
      const items = [...(editingBill.items || [])];
      items[index] = { ...items[index], [field]: value };
      setEditingBill({ ...editingBill, items });
  };

  const handleSubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      const total = calculateTotal();
      // @ts-ignore
      await db.saveBill({ ...editingBill, total } as Bill);
      setIsModalOpen(false);
      loadData();
  };

  const generatePDF = (bill: Bill, autoPrint = false): jsPDF => {
      const doc = new jsPDF();
      doc.setFontSize(22);
      doc.setTextColor(22, 197, 94);
      doc.text("KAMBEGOYE", 14, 20);
      doc.setFontSize(10);
      doc.setTextColor(100);
      doc.text("Niamey, Niger", 14, 26);
      doc.text("contact@kambegoye.com", 14, 31);
      
      doc.setFontSize(16);
      doc.setTextColor(0);
      doc.text(bill.type === 'quote' ? 'DEVIS' : 'FACTURE', 140, 20);
      doc.setFontSize(10);
      doc.text(`N° : ${bill.number}`, 140, 26);
      doc.text(`Date : ${new Date(bill.date).toLocaleDateString()}`, 140, 31);

      doc.setDrawColor(200);
      doc.line(14, 40, 196, 40);

      doc.setFontSize(12);
      doc.text("Client :", 14, 50);
      doc.setFontSize(10);
      doc.text(bill.clientName, 14, 56);
      if (bill.clientPhone) doc.text(`Tél : ${bill.clientPhone}`, 14, 61);
      if (bill.clientAddress) doc.text(`Lieu : ${bill.clientAddress}`, 14, 66);

      const tableColumn = ["Description", "Quantité", "Prix Unit.", "Total"];
      const tableRows = bill.items.map(item => [
          item.description,
          item.quantity,
          formatPrice(item.unitPrice),
          formatPrice(item.quantity * item.unitPrice)
      ]);

      autoTable(doc, {
          head: [tableColumn],
          body: tableRows,
          startY: 75,
          theme: 'grid',
          headStyles: { fillColor: [22, 197, 94] }
      });

      const finalY = (doc as any).lastAutoTable.finalY + 15;
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text(`TOTAL : ${formatPrice(bill.total)}`, 140, finalY);

      doc.setFontSize(10);
      doc.setFont("helvetica", "italic");
      const totalInWords = numberToFrenchWords(bill.total);
      const label = bill.type === 'quote' ? 'présent devis' : 'présente facture';
      const mention = `Arrêtée le ${label} à la somme de : ${totalInWords} (${formatPrice(bill.total)})`;
      
      const splitMention = doc.splitTextToSize(mention, 180);
      doc.text(splitMention, 14, finalY + 15);

      if (autoPrint) {
          window.open(doc.output('bloburl'), '_blank');
      } else {
          doc.save(`${bill.type}_${bill.number}.pdf`);
      }
      return doc;
  };

  const handleExportAll = () => {
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.setTextColor(22, 197, 94);
    doc.text("KAMBEGOYE - RAPPORT DE FACTURATION", 14, 20);
    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text(`Date d'export : ${new Date().toLocaleString()}`, 14, 28);
    doc.text(`Documents affichés : ${filteredBills.length}`, 14, 33);

    const tableColumn = ["Date", "Réf", "Client", "Type", "Statut", "Montant"];
    const tableRows = filteredBills.map(b => [
        new Date(b.date).toLocaleDateString(),
        b.number,
        b.clientName,
        b.type === 'quote' ? 'Devis' : 'Facture',
        b.status === 'closed' ? 'Encaissé' : 'En attente',
        formatPrice(b.total)
    ]);

    autoTable(doc, { head: [tableColumn], body: tableRows, startY: 40, theme: 'grid', headStyles: { fillColor: [22, 197, 94] } });

    const total = filteredBills.reduce((s, b) => s + b.total, 0);
    const finalY = (doc as any).lastAutoTable.finalY + 15;
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text(`TOTAL CUMULÉ : ${formatPrice(total)}`, 140, finalY);

    doc.save(`rapport_facturation_${new Date().toISOString().slice(0, 10)}.pdf`);
  };

  const handleSendWhatsApp = (bill: Bill) => {
    generatePDF(bill, false);
    const typeLabel = bill.type === 'quote' ? 'votre Devis' : 'votre Facture';
    const message = `Bonjour ${bill.clientName},\n\nVoici ${typeLabel} KAMBEGOYE n°*${bill.number}* d'un montant de *${formatPrice(bill.total)}*.\n\nMerci de trouver le fichier PDF ci-joint.\n\nCordialement,\nL'équipe KAMBEGOYE Niamey`;
    let phone = (bill.clientPhone || '').replace(/\s/g, '');
    if (phone.length === 8) phone = '227' + phone;
    window.open(`https://wa.me/${phone}?text=${encodeURIComponent(message)}`, '_blank');
  };

  const filteredBills = bills.filter(b => 
    b.clientName.toLowerCase().includes(searchTerm.toLowerCase()) || 
    b.number.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="animate-in fade-in duration-500 pb-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
            <h2 className="text-3xl font-black text-gray-800 dark:text-white uppercase tracking-tighter">Facturation</h2>
            <p className="text-gray-500 font-medium text-[10px] uppercase tracking-widest">Édition de documents officiels</p>
        </div>
        <div className="flex gap-2">
            <button onClick={handleExportAll} className="bg-white border-2 border-brand-100 text-brand-600 px-5 py-3 rounded-xl font-black uppercase tracking-widest text-[10px] flex items-center gap-2 hover:bg-brand-50 transition-all shadow-sm">
                <FileSpreadsheet size={16} /> Rapport PDF
            </button>
            <button onClick={() => { setEditingBill({ type: 'quote', date: new Date().toISOString().slice(0, 10), items: [{ description: '', quantity: 1, unitPrice: 0 }], status: 'pending', number: 'FAC-' + Date.now().toString().slice(-6), clientName: '', clientPhone: '', projectId: '' }); setIsModalOpen(true); }} className="bg-brand-600 text-white px-6 py-3 rounded-xl font-black uppercase tracking-widest text-[10px] flex items-center gap-2 shadow-xl hover:bg-brand-700 transition-all active:scale-95">
                <Plus size={18} /> Nouveau Document
            </button>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 shadow-sm rounded-[2.5rem] overflow-hidden border border-gray-100 dark:border-gray-700">
        <div className="p-6 border-b border-gray-50 dark:border-gray-700 bg-gray-50/30 dark:bg-gray-900/30">
            <input type="text" placeholder="Rechercher par client ou référence..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full md:w-96 px-6 py-3 rounded-2xl bg-white dark:bg-gray-700 border-0 text-sm font-bold shadow-sm focus:ring-2 focus:ring-brand-500 outline-none" />
        </div>
        <table className="min-w-full divide-y divide-gray-100 dark:divide-gray-700">
          <thead className="bg-gray-50/50 dark:bg-gray-900/50">
            <tr>
              <th className="px-8 py-5 text-left text-[10px] font-black uppercase tracking-wider text-gray-400">Type / Réf</th>
              <th className="px-8 py-5 text-left text-[10px] font-black uppercase tracking-wider text-gray-400">Client</th>
              <th className="px-8 py-5 text-left text-[10px] font-black uppercase tracking-wider text-gray-400">Statut</th>
              <th className="px-8 py-5 text-right text-[10px] font-black uppercase tracking-wider text-gray-400">Total</th>
              <th className="px-8 py-5 text-right text-[10px] font-black uppercase tracking-wider text-gray-400">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50 dark:divide-gray-800">
            {filteredBills.map(bill => (
              <tr key={bill.id} className="hover:bg-gray-50/50 dark:hover:bg-gray-900/30 transition-colors group">
                <td className="px-8 py-5">
                   <div className="flex flex-col">
                      <span className={`w-fit px-2 py-0.5 rounded text-[9px] font-black uppercase mb-1 ${bill.type === 'quote' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'}`}>
                          {bill.type === 'quote' ? 'Devis' : 'Facture'}
                      </span>
                      <span className="text-sm font-black font-mono">#{bill.number}</span>
                   </div>
                </td>
                <td className="px-8 py-5">
                   <div className="flex flex-col">
                      <span className="text-sm font-black text-gray-800 dark:text-white uppercase tracking-tight">{bill.clientName}</span>
                      {bill.clientPhone && <span className="text-[10px] text-gray-400 font-bold font-mono">TEL: {bill.clientPhone}</span>}
                   </div>
                </td>
                <td className="px-8 py-5">
                   <span className={`px-2 py-1 rounded text-[9px] font-black uppercase ${bill.status === 'closed' ? 'bg-gray-100 text-gray-700' : bill.status === 'processed' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'}`}>
                       {bill.status === 'closed' ? 'Fermé' : bill.status === 'processed' ? 'Validé' : 'Brouillon'}
                   </span>
                </td>
                <td className="px-8 py-5 text-right font-black text-brand-600">{formatPrice(bill.total)}</td>
                <td className="px-8 py-5 text-right">
                  <div className="flex justify-end gap-1.5">
                    <button onClick={() => handleSendWhatsApp(bill)} className="p-2.5 bg-green-50 text-green-600 rounded-xl hover:bg-green-100 transition-all border border-green-100" title="Envoyer WhatsApp"><MessageCircle size={16}/></button>
                    <button onClick={() => generatePDF(bill, true)} className="p-2.5 bg-gray-50 dark:bg-gray-700 text-gray-400 hover:text-brand-600 rounded-xl transition-all border border-gray-100" title="Imprimer"><Printer size={16}/></button>
                    <button onClick={() => generatePDF(bill)} className="p-2.5 bg-gray-50 dark:bg-gray-700 text-gray-400 hover:text-blue-600 rounded-xl transition-all border border-gray-100" title="Télécharger PDF"><Download size={16}/></button>
                    <button onClick={() => { setEditingBill(bill); setIsModalOpen(true); }} className="p-2.5 bg-gray-50 dark:bg-gray-700 text-gray-400 hover:text-indigo-600 rounded-xl transition-all" title="Éditer"><FileText size={16}/></button>
                    <button onClick={async () => { if(window.confirm('Supprimer ce document ?')) { await db.deleteBill(bill.id); loadData(); } }} className="p-2.5 text-red-300 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all" title="Supprimer"><Trash2 size={16}/></button>
                  </div>
                </td>
              </tr>
            ))}
            {filteredBills.length === 0 && <tr><td colSpan={5} className="text-center py-20 text-gray-400 font-black uppercase text-xs italic tracking-widest">Aucun document émis.</td></tr>}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[100] bg-black/60 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
           <div className="bg-white dark:bg-gray-800 p-10 rounded-[3rem] max-w-3xl w-full max-h-[95vh] overflow-y-auto shadow-2xl animate-in zoom-in-95 duration-200 border border-white/20">
              <div className="flex justify-between mb-8 items-center border-b border-gray-50 pb-4">
                <h3 className="font-black text-2xl uppercase tracking-tighter flex items-center gap-3">
                    <FilePlus className="text-brand-600" size={28} /> {editingBill.id ? 'Éditer le' : 'Nouveau'} Document
                </h3>
                <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"><X/></button>
              </div>
              
              <form onSubmit={handleSubmit} className="space-y-8">
                 <div className="bg-brand-50 dark:bg-brand-900/20 p-6 rounded-[2rem] border border-brand-100 dark:border-gray-700 flex flex-col md:flex-row gap-4 items-center">
                    <div className="flex-1 w-full">
                        <label className="block text-[10px] font-black uppercase text-brand-600 mb-1 flex items-center gap-1"><Briefcase size={12}/> Projet lié (Optionnel)</label>
                        <select value={editingBill.projectId || ''} onChange={e => setEditingBill({...editingBill, projectId: e.target.value})} className="w-full p-2 bg-transparent font-bold outline-none border-b border-brand-200 dark:border-gray-600 text-sm">
                            <option value="">-- Aucun projet lié --</option>
                            {projects.map(p => <option key={p.id} value={p.id}>{p.title} ({p.clientName})</option>)}
                        </select>
                    </div>
                    <div className="w-full md:w-48">
                        <label className="block text-[10px] font-black uppercase text-brand-600 mb-1">Nature du document</label>
                        <div className="flex bg-white dark:bg-gray-800 rounded-xl p-1 border border-brand-100">
                           <button type="button" onClick={() => setEditingBill({...editingBill, type: 'quote'})} className={`flex-1 py-2 text-[9px] font-black uppercase rounded-lg transition-all ${editingBill.type === 'quote' ? 'bg-blue-600 text-white shadow-lg' : 'text-gray-400'}`}>Devis</button>
                           <button type="button" onClick={() => setEditingBill({...editingBill, type: 'invoice'})} className={`flex-1 py-2 text-[9px] font-black uppercase rounded-lg transition-all ${editingBill.type === 'invoice' ? 'bg-green-600 text-white shadow-lg' : 'text-gray-400'}`}>Facture</button>
                        </div>
                    </div>
                 </div>

                 <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-4">
                        <h4 className="text-[10px] font-black uppercase text-gray-400 tracking-widest border-b pb-1">Client & Lieu</h4>
                        <div className="grid grid-cols-1 gap-4">
                           <input type="text" required value={editingBill.clientName || ''} onChange={e => setEditingBill({...editingBill, clientName: e.target.value})} className="w-full p-4 bg-gray-50 dark:bg-gray-900 border-0 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-brand-500" placeholder="NOM DU CLIENT" />
                           <input type="tel" value={editingBill.clientPhone || ''} onChange={e => setEditingBill({...editingBill, clientPhone: e.target.value})} className="w-full p-4 bg-gray-50 dark:bg-gray-900 border-0 rounded-2xl font-bold font-mono outline-none focus:ring-2 focus:ring-brand-500" placeholder="WHATSAPP" />
                           <input type="text" value={editingBill.clientAddress || ''} onChange={e => setEditingBill({...editingBill, clientAddress: e.target.value})} className="w-full p-4 bg-gray-50 dark:bg-gray-900 border-0 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-brand-500" placeholder="ADRESSE / LIEU" />
                        </div>
                    </div>
                    <div className="space-y-4">
                        <h4 className="text-[10px] font-black uppercase text-gray-400 tracking-widest border-b pb-1">Réglages Administration</h4>
                        <div className="grid grid-cols-1 gap-4">
                           <input type="text" value={editingBill.number} onChange={e => setEditingBill({...editingBill, number: e.target.value})} className="w-full p-4 bg-gray-50 dark:bg-gray-900 border-0 rounded-2xl font-mono font-black uppercase outline-none focus:ring-2 focus:ring-brand-500" placeholder="N° DOCUMENT" />
                           <input type="date" value={editingBill.date} onChange={e => setEditingBill({...editingBill, date: e.target.value})} className="w-full p-4 bg-gray-50 dark:bg-gray-900 border-0 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-brand-500" />
                           <select value={editingBill.status} onChange={e => setEditingBill({...editingBill, status: e.target.value as any})} className="w-full p-4 bg-gray-50 dark:bg-gray-900 border-0 rounded-2xl font-black uppercase text-xs outline-none focus:ring-2 focus:ring-brand-500">
                               <option value="pending">En attente / Brouillon</option>
                               <option value="processed">Envoyé / Validé</option>
                               <option value="closed">Encaissé / Fermé</option>
                           </select>
                        </div>
                    </div>
                 </div>

                 <div className="space-y-4">
                    <div className="flex justify-between items-center mb-4">
                       <h4 className="text-[10px] font-black uppercase text-brand-600 tracking-widest flex items-center gap-2"><Tag size={14}/> Désignations & Montants</h4>
                       <button type="button" onClick={handleAddItem} className="bg-brand-50 text-brand-600 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-1 hover:bg-brand-100 transition-all"><Plus size={14}/> Ajouter ligne</button>
                    </div>
                    <div className="space-y-3">
                        {editingBill.items?.map((item, idx) => (
                        <div key={idx} className="flex flex-col md:flex-row gap-3 items-stretch md:items-end bg-gray-50 dark:bg-gray-900 p-5 rounded-[2rem] border border-gray-100 dark:border-gray-700 relative group">
                            <div className="flex-1">
                                <label className="block text-[8px] font-black text-gray-400 uppercase mb-1">Article / Service</label>
                                <input type="text" placeholder="Ex: Remplacement Robinetterie" value={item.description} onChange={e => handleItemChange(idx, 'description', e.target.value)} className="w-full p-2 bg-transparent font-bold text-sm outline-none border-b border-gray-200" />
                            </div>
                            <div className="w-full md:w-20">
                                <label className="block text-[8px] font-black text-gray-400 uppercase mb-1">Qté</label>
                                <input type="number" value={item.quantity} onChange={e => handleItemChange(idx, 'quantity', Number(e.target.value))} className="w-full p-2 bg-transparent font-black text-sm outline-none border-b border-gray-200 text-center" />
                            </div>
                            <div className="w-full md:w-32">
                                <label className="block text-[8px] font-black text-gray-400 uppercase mb-1">Prix Unit. (F)</label>
                                <input type="number" value={item.unitPrice} onChange={e => handleItemChange(idx, 'unitPrice', Number(e.target.value))} className="w-full p-2 bg-transparent font-black text-sm outline-none border-b border-gray-200 text-right" />
                            </div>
                            <button type="button" onClick={() => handleRemoveItem(idx)} className="absolute -top-2 -right-2 bg-red-100 text-red-600 p-1.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-md"><Trash2 size={14}/></button>
                        </div>
                        ))}
                    </div>
                 </div>

                 <div className="flex flex-col md:flex-row justify-between items-center pt-10 border-t-2 border-dashed border-gray-100 dark:border-gray-700 gap-6">
                    <div className="flex flex-col">
                        <span className="text-[10px] font-black uppercase text-gray-400 tracking-widest mb-1">Total à régler</span>
                        <div className="text-4xl font-black text-brand-600 tracking-tighter">{formatPrice(calculateTotal())}</div>
                    </div>
                    <div className="flex flex-wrap gap-4 w-full md:w-auto">
                        <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 px-8 py-4 border-2 border-gray-100 dark:border-gray-700 rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-gray-50 transition-all">Annuler</button>
                        <button type="submit" className="flex-1 bg-brand-600 text-white px-10 py-4 rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl hover:bg-brand-700 transition-all active:scale-95">Enregistrer</button>
                    </div>
                 </div>
              </form>
           </div>
        </div>
      )}
    </div>
  );
};

export default Bills;
