
import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Smartphone, Lock, AlertCircle, Loader, Info, ExternalLink, Banknote, CheckCircle } from 'lucide-react';
import { db } from '../services/db';

const Payment = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [method, setMethod] = useState<'Mynita' | 'Amanata' | 'Espèces' | null>(null);
  const [phone, setPhone] = useState('');
  const [amount, setAmount] = useState(200);
  
  const [loading, setLoading] = useState(false);
  const [paymentInitiated, setPaymentInitiated] = useState(false);
  const [error, setError] = useState('');
  
  useEffect(() => {
    db.getSettings().then(s => setAmount(s.consultationPrice));
    
    const spec = searchParams.get('return_spec');
    const loc = searchParams.get('return_loc');
    const workerId = searchParams.get('worker_id');
    
    if (spec || loc || workerId) {
        localStorage.setItem('kambegoye_return_context', JSON.stringify({ spec, loc, workerId }));
    }

    if (searchParams.get('error') === 'cancel') {
        setError("Vous avez annulé le paiement.");
    }
  }, [searchParams]);

  const handleInitiatePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!method || !phone) {
      setError("Veuillez choisir une méthode et entrer votre numéro.");
      return;
    }
    
    setLoading(true);
    setError('');

    try {
      const result = await db.initiateTransaction(method, phone);
      
      if (result.success && result.paymentUrl) {
          if (result.paymentUrl.startsWith('/')) {
              // Navigation interne (Cash simulation)
              navigate(result.paymentUrl);
          } else {
              // OUVERTURE DU LIEN I-PAY DANS UN NOUVEL ONGLET
              const paymentWindow = window.open(result.paymentUrl, '_blank');
              
              if (!paymentWindow) {
                  // Si le bloqueur de popup empêche l'ouverture
                  window.location.href = result.paymentUrl;
              } else {
                  setPaymentInitiated(true);
                  setLoading(false);
              }
          }
      } else {
          setError("Impossible d'initialiser le paiement. Veuillez réessayer.");
          setLoading(false);
      }
    } catch (err) {
      setError("Erreur de connexion au service de paiement.");
      setLoading(false);
    }
  };

  if (paymentInitiated) {
      return (
          <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-gray-50 dark:bg-gray-900 py-12 px-4">
              <div className="max-w-md w-full space-y-8 bg-white dark:bg-gray-800 p-10 rounded-[3rem] shadow-2xl text-center border border-brand-100 dark:border-gray-700">
                  <div className="mx-auto flex items-center justify-center h-20 w-20 rounded-3xl bg-brand-50 dark:bg-brand-900/30">
                      <ExternalLink className="h-10 w-10 text-brand-600" />
                  </div>
                  <h2 className="text-2xl font-black text-gray-900 dark:text-white uppercase tracking-tighter">Paiement en cours...</h2>
                  <p className="text-gray-500 font-medium leading-relaxed">
                      La page de paiement sécurisée s'est ouverte dans un <strong>nouvel onglet i-pay.money</strong>.<br/><br/>
                      Une fois votre paiement terminé, vous serez automatiquement redirigé vers notre site ou vous pouvez cliquer ci-dessous.
                  </p>
                  <div className="pt-4 space-y-3">
                      <button 
                        onClick={() => navigate('/payment/callback?ref=DONE')}
                        className="w-full py-4 px-6 bg-brand-600 text-white rounded-2xl font-black uppercase tracking-widest text-xs shadow-lg hover:bg-brand-700 transition-all"
                      >
                          J'ai terminé mon paiement
                      </button>
                      <button 
                        onClick={() => setPaymentInitiated(false)}
                        className="w-full py-3 px-6 text-gray-400 font-bold uppercase text-[10px] hover:text-gray-600"
                      >
                          Retour au formulaire
                      </button>
                  </div>
              </div>
          </div>
      );
  }

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-gray-50 dark:bg-gray-900 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-white dark:bg-gray-800 p-8 rounded-[2.5rem] shadow-xl border border-gray-100 dark:border-gray-700">
        <div className="text-center">
          <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-3xl bg-brand-100 dark:bg-brand-900 shadow-inner">
            <Lock className="h-8 w-8 text-brand-600 dark:text-brand-400" />
          </div>
          <h2 className="mt-6 text-3xl font-black text-gray-900 dark:text-white uppercase tracking-tighter">
            Débloquer les contacts
          </h2>
          <p className="mt-2 text-sm text-gray-500 dark:text-gray-400 font-medium">
            Accès illimité pour <span className="font-black text-accent-600 text-lg">{amount.toLocaleString()} FCFA</span>
          </p>
        </div>

        <form className="mt-8 space-y-6" onSubmit={handleInitiatePayment}>
            <div className="grid grid-cols-3 gap-3">
              <button
                  type="button"
                  disabled={loading}
                  onClick={() => setMethod('Amanata')}
                  className={`p-4 border-2 rounded-2xl flex flex-col items-center justify-center transition-all ${
                  method === 'Amanata' 
                  ? 'border-brand-500 bg-brand-50 text-brand-700 shadow-inner ring-2 ring-brand-500' 
                  : 'border-gray-100 hover:border-brand-200 dark:border-gray-700 dark:text-gray-300'
                  }`}
              >
                  <span className="font-black text-[10px] uppercase tracking-widest">Amanata</span>
              </button>
              <button
                  type="button"
                  disabled={loading}
                  onClick={() => setMethod('Mynita')}
                  className={`p-4 border-2 rounded-2xl flex flex-col items-center justify-center transition-all ${
                  method === 'Mynita' 
                  ? 'border-brand-500 bg-brand-50 text-brand-700 shadow-inner ring-2 ring-brand-500' 
                  : 'border-gray-100 hover:border-brand-200 dark:border-gray-700 dark:text-gray-300'
                  }`}
              >
                  <span className="font-black text-[10px] uppercase tracking-widest">Mynita</span>
              </button>
              <button
                  type="button"
                  disabled={loading}
                  onClick={() => setMethod('Espèces')}
                  className={`p-4 border-2 rounded-2xl flex flex-col items-center justify-center transition-all ${
                  method === 'Espèces' 
                  ? 'border-accent-500 bg-accent-50 text-accent-700 shadow-inner ring-2 ring-accent-500' 
                  : 'border-gray-100 hover:border-accent-200 dark:border-gray-700 dark:text-gray-300'
                  }`}
              >
                  <Banknote className={`mb-1 ${method === 'Espèces' ? 'text-accent-600' : 'text-gray-400'}`} size={20} />
                  <span className="font-black text-[10px] uppercase tracking-widest">Espèces</span>
              </button>
            </div>

            <div>
              <label htmlFor="phone" className="block text-[10px] font-black uppercase text-gray-400 mb-1 tracking-widest">
                Votre numéro de téléphone
              </label>
              <div className="mt-1 relative rounded-2xl shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                      <Smartphone className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                      id="phone"
                      name="phone"
                      type="tel"
                      required
                      disabled={loading}
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="block w-full pl-12 pr-4 py-4 sm:text-sm border-0 bg-gray-50 dark:bg-gray-700 dark:text-white rounded-2xl font-bold focus:ring-2 focus:ring-brand-500 outline-none"
                      placeholder="Ex: 90000000"
                  />
              </div>
            </div>

            {error && (
            <div className="flex items-center text-red-600 text-xs bg-red-50 p-3 rounded-2xl border border-red-100 font-bold">
                <AlertCircle className="w-4 h-4 mr-2" />
                {error}
            </div>
            )}

            <div className="bg-brand-50 dark:bg-brand-900/20 p-4 rounded-2xl flex items-start border border-brand-100 dark:border-brand-800">
                <Info className="w-5 h-5 text-brand-500 mr-3 flex-shrink-0 mt-0.5" />
                <p className="text-[11px] text-brand-700 dark:text-brand-300 font-medium leading-relaxed">
                    {method === 'Espèces' 
                      ? "En choisissant 'Espèces', vous devrez régler le montant directement à l'agence KAMBEGOYE ou via un agent certifié."
                      : "Le lien de paiement officiel s'ouvrira dans un nouvel onglet sécurisé i-pay.money."}
                </p>
            </div>

            <button
            type="submit"
            disabled={loading}
            className="group relative w-full flex justify-center py-5 px-4 border border-transparent rounded-2xl text-lg font-black uppercase tracking-widest text-white bg-brand-600 hover:bg-brand-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-500 disabled:opacity-75 disabled:cursor-not-allowed transition-all shadow-xl active:scale-95"
            >
            {loading ? (
                <span className="flex items-center">
                <Loader className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" />
                Chargement...
                </span>
            ) : (
                <span className="flex items-center">
                Continuer vers i-pay <ExternalLink className="ml-3 w-5 h-5 opacity-50" />
                </span>
            )}
            </button>
        </form>
      </div>
    </div>
  );
};

export default Payment;
