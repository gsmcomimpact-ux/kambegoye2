
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle, Send, CheckCircle } from 'lucide-react';
import { db } from '../services/db';
import { Worker } from '../types';

const DisputeRequestPage = () => {
  const navigate = useNavigate();
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success'>('idle');
  const [formData, setFormData] = useState({
    reporterName: '',
    reporterPhone: '',
    workerId: '',
    description: ''
  });

  useEffect(() => {
    db.getWorkers().then(w => setWorkers(w.filter(item => item.accountStatus === 'active')));
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('submitting');
    
    // Fixed: saveDispute is now properly implemented in db service
    await db.saveDispute(formData);
    setStatus('success');
  };

  if (status === 'success') {
    return (
      <div className="max-w-md mx-auto py-20 px-4 text-center">
        <div className="bg-green-100 p-4 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6 text-green-600">
            <CheckCircle size={40} />
        </div>
        <h1 className="text-2xl font-bold mb-4">Litige enregistré</h1>
        <p className="text-gray-600 mb-8">Nous avons bien reçu votre signalement. Un administrateur va examiner la situation et contacter l'ouvrier concerné.</p>
        <button onClick={() => navigate('/')} className="bg-brand-600 text-white px-6 py-2 rounded-md font-bold">Retour à l'accueil</button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto py-12 px-4">
      <div className="flex items-center gap-4 mb-8">
        <div className="bg-red-100 p-3 rounded-full text-red-600">
            <AlertTriangle size={32} />
        </div>
        <div>
            <h1 className="text-3xl font-bold">Déclarer un Litige</h1>
            <p className="text-gray-500">Un problème avec un ouvrier ? Signalez-le nous.</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="bg-white dark:bg-gray-800 p-8 rounded-xl shadow-lg space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium mb-1">Votre Nom</label>
            <input 
                type="text" required 
                className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
                value={formData.reporterName}
                onChange={e => setFormData({...formData, reporterName: e.target.value})}
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Votre Téléphone</label>
            <input 
                type="tel" required 
                className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
                value={formData.reporterPhone}
                onChange={e => setFormData({...formData, reporterPhone: e.target.value})}
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Ouvrier concerné</label>
          <select 
            required 
            className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
            value={formData.workerId}
            onChange={e => setFormData({...formData, workerId: e.target.value})}
          >
            <option value="">Sélectionner un ouvrier...</option>
            {workers.map(w => <option key={w.id} value={w.id}>{w.firstName} {w.lastName} ({w.phone})</option>)}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Description du problème</label>
          <textarea 
            required rows={6}
            className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
            placeholder="Détaillez le litige (travail non fini, mauvaise qualité, absence...)"
            value={formData.description}
            onChange={e => setFormData({...formData, description: e.target.value})}
          />
        </div>

        <button 
            type="submit" 
            disabled={status === 'submitting'}
            className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2"
        >
            <Send size={20} />
            {status === 'submitting' ? 'Envoi...' : 'Envoyer le signalement'}
        </button>
      </form>
    </div>
  );
};

export default DisputeRequestPage;
