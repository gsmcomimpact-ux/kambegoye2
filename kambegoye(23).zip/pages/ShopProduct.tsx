
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, ShoppingCart, Truck, ShieldCheck, Check, Plus } from 'lucide-react';
import { db } from '../services/db';
import { Product } from '../types';

const ShopProduct = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [added, setAdded] = useState(false);

  useEffect(() => {
    db.getProductById(id || '').then(p => {
      setProduct(p || null);
      setLoading(false);
    });
  }, [id]);

  if (loading) return <div className="p-10 text-center">Chargement...</div>;
  if (!product) return <div className="p-10 text-center">Produit introuvable.</div>;

  const handleAddToCart = () => {
      db.addToCart(product);
      setAdded(true);
      setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <button 
        onClick={() => navigate('/boutique')}
        className="flex items-center text-gray-500 hover:text-brand-600 mb-6 transition-colors"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Retour à la boutique
      </button>

      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg overflow-hidden grid grid-cols-1 md:grid-cols-2">
        <div className="h-64 md:h-auto bg-gray-100">
          <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
        </div>

        <div className="p-8 md:p-12 flex flex-col justify-center">
           <span className="text-brand-600 font-bold uppercase tracking-wider text-sm mb-2">{product.category}</span>
           <h1 className="text-3xl md:text-4xl font-extrabold text-gray-900 dark:text-white mb-4">{product.name}</h1>
           
           <div className="flex items-center mb-6">
              <span className="text-3xl font-bold text-gray-900 dark:text-white mr-4">{product.price.toLocaleString()} FCFA</span>
              {product.stock > 0 ? (
                  <span className="flex items-center text-green-600 text-sm font-medium bg-green-50 dark:bg-green-900/20 px-2 py-1 rounded">
                      <Check className="w-4 h-4 mr-1" /> En Stock
                  </span>
              ) : (
                  <span className="flex items-center text-red-600 text-sm font-medium bg-red-50 dark:bg-red-900/20 px-2 py-1 rounded">
                      Rupture de stock
                  </span>
              )}
           </div>

           <p className="text-gray-600 dark:text-gray-300 mb-8 leading-relaxed">
             {product.description}
           </p>

           <div className="space-y-4">
              {!added ? (
                <button 
                  onClick={handleAddToCart}
                  disabled={product.stock === 0}
                  className="w-full flex items-center justify-center py-4 rounded-xl font-bold text-lg shadow-lg bg-brand-600 text-white hover:bg-brand-700 transition-all active:scale-95 disabled:opacity-50"
                >
                   <Plus className="w-6 h-6 mr-3" /> Ajouter au panier
                </button>
              ) : (
                <Link 
                  to="/panier"
                  className="w-full flex items-center justify-center py-4 rounded-xl font-bold text-lg shadow-lg bg-green-600 text-white hover:bg-green-700 transition-all animate-bounce"
                >
                   <ShoppingCart className="w-6 h-6 mr-3" /> Voir le panier
                </Link>
              )}
              
              <button 
                onClick={() => navigate('/boutique')}
                className="w-full text-center text-brand-600 font-bold py-2 hover:underline"
              >
                  Continuer mes achats
              </button>
           </div>

           <div className="mt-8 grid grid-cols-2 gap-4 border-t border-gray-100 dark:border-gray-700 pt-6">
              <div className="flex items-start">
                 <Truck className="w-5 h-5 text-gray-400 mr-2 mt-0.5" />
                 <div>
                    <h4 className="font-semibold text-gray-900 dark:text-white text-sm">Livraison Niamey</h4>
                    <p className="text-xs text-gray-500">Rapide et sécurisée.</p>
                 </div>
              </div>
              <div className="flex items-start">
                 <ShieldCheck className="w-5 h-5 text-gray-400 mr-2 mt-0.5" />
                 <div>
                    <h4 className="font-semibold text-gray-900 dark:text-white text-sm">Vérifié</h4>
                    <p className="text-xs text-gray-500">Qualité KAMBEGOYE.</p>
                 </div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default ShopProduct;
