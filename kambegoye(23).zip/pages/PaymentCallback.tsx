
import React, { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { CheckCircle, XCircle, Loader } from 'lucide-react';
import { db } from '../services/db';

const PaymentCallback = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [status, setStatus] = useState<'verifying' | 'success' | 'failed'>('verifying');

  useEffect(() => {
    const ref = searchParams.get('ref') || searchParams.get('reference');
    
    if (!ref) {
        setStatus('failed');
        return;
    }

    const verify = async () => {
        const success = await db.finalizeTransaction(ref);
        
        if (success) {
            setStatus('success');
            
            // On récupère l'identifiant de l'ouvrier mémorisé
            const savedContext = localStorage.getItem('kambegoye_return_context');
            let targetUrl = '/search';
            
            if (savedContext) {
                try {
                    const { spec, loc, workerId } = JSON.parse(savedContext);
                    
                    // Priorité absolue : Rediriger vers le profil de l'ouvrier s'il est spécifié
                    if (workerId) {
                        targetUrl = `/ouvrier/${workerId}`;
                    } else if (spec || loc) {
                        const params = new URLSearchParams();
                        if (spec) params.append('specialty', spec);
                        if (loc) params.append('location', loc);
                        targetUrl = `/search?${params.toString()}`;
                    }
                } catch (e) {
                    console.error("Erreur lecture contexte retour", e);
                }
                // Nettoyage pour ne pas polluer les futurs paiements
                localStorage.removeItem('kambegoye_return_context');
            }

            // Redirection automatique après 2 secondes pour laisser le temps de voir le message de succès
            setTimeout(() => navigate(targetUrl, { replace: true }), 2000);
        } else {
            setStatus('failed');
        }
    };

    verify();
  }, [searchParams, navigate]);

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-gray-50 dark:bg-gray-900 px-4">
      <div className="max-w-md w-full bg-white dark:bg-gray-800 p-10 rounded-[2.5rem] shadow-xl text-center border border-gray-100 dark:border-gray-700">
        
        {status === 'verifying' && (
            <div className="space-y-6">
                <div className="mx-auto flex items-center justify-center h-20 w-20 bg-brand-50 dark:bg-brand-900/30 rounded-3xl">
                    <Loader className="w-10 h-10 text-brand-600 animate-spin" />
                </div>
                <div>
                    <h2 className="text-2xl font-black text-gray-900 dark:text-white uppercase tracking-tighter">Vérification...</h2>
                    <p className="text-gray-500 font-medium mt-2">Nous confirmons votre transaction avec i-pay...</p>
                </div>
            </div>
        )}

        {status === 'success' && (
            <div className="space-y-6 animate-in zoom-in duration-300">
                <div className="mx-auto flex items-center justify-center h-20 w-20 rounded-3xl bg-green-100 dark:bg-green-900/30">
                    <CheckCircle className="w-12 h-12 text-green-600" />
                </div>
                <div>
                    <h2 className="text-3xl font-black text-gray-900 dark:text-white uppercase tracking-tighter">Paiement Validé !</h2>
                    <p className="text-gray-600 dark:text-gray-300 font-medium mt-2">
                        Accès activé. Vous allez être redirigé vers l'expert sélectionné...
                    </p>
                </div>
                <div className="w-full bg-gray-100 dark:bg-gray-700 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-brand-600 h-full animate-[progress_2s_ease-in-out]"></div>
                </div>
            </div>
        )}

        {status === 'failed' && (
            <div className="space-y-6 animate-in zoom-in duration-300">
                <div className="mx-auto flex items-center justify-center h-20 w-20 rounded-3xl bg-red-100 dark:bg-red-900/30">
                    <XCircle className="w-12 h-12 text-red-600" />
                </div>
                <div>
                    <h2 className="text-2xl font-black text-gray-900 dark:text-white uppercase tracking-tighter">Échec</h2>
                    <p className="text-gray-600 dark:text-gray-300 font-medium mt-2">
                        La transaction n'a pas pu être confirmée.
                    </p>
                </div>
                <button 
                    onClick={() => navigate('/payment')}
                    className="w-full bg-gray-900 text-white py-4 rounded-2xl font-black uppercase tracking-widest shadow-lg active:scale-95"
                >
                    Réessayer
                </button>
            </div>
        )}

      </div>
    </div>
  );
};

export default PaymentCallback;
