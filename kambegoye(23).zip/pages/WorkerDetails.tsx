
import React, { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Phone, Star, MapPin, BadgeCheck, MessageCircle, Send, User, Calendar, CheckCircle } from 'lucide-react';
import * as L from 'leaflet';
import { db } from '../services/db';
import { Worker, Specialty, Neighborhood, Review } from '../types';

const WorkerDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [worker, setWorker] = useState<Worker | null>(null);
  const [specialties, setSpecialties] = useState<Specialty[]>([]);
  const [neighborhoods, setNeighborhoods] = useState<Neighborhood[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);

  // Review Form States
  const [newReview, setNewReview] = useState({ userName: '', rating: 5, comment: '' });
  const [hoverRating, setHoverRating] = useState(0);
  const [reviewStatus, setReviewStatus] = useState<'idle' | 'submitting' | 'success'>('idle');

  // Map Ref
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);

  useEffect(() => {
    // Paywall Check
    if (!db.hasPaid()) {
      navigate('/payment');
      return;
    }

    const loadData = async () => {
      if (id) {
          // Increment View Count
          db.incrementWorkerView(id);
      }

      const [w, s, n, r] = await Promise.all([
        db.getWorkerById(id || ''),
        db.getSpecialties(),
        db.getNeighborhoods(),
        db.getReviewsByWorkerId(id || '')
      ]);
      
      // Security: Only show active workers
      if (w && w.accountStatus === 'active') {
        setWorker(w);
      } else {
        setWorker(null);
      }

      setSpecialties(s);
      setNeighborhoods(n);
      setReviews(r);
      setLoading(false);
    };
    loadData();
  }, [id, navigate]);

  // Initialize Map when worker data is loaded
  useEffect(() => {
    if (worker && worker.latitude && worker.longitude && mapContainerRef.current && !mapInstanceRef.current) {
      
      const map = L.map(mapContainerRef.current).setView([worker.latitude, worker.longitude], 14);

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      }).addTo(map);

      // Custom icon to ensure it renders correctly from CDN
      const customIcon = L.divIcon({
        className: 'custom-div-icon',
        html: `<div style="background-color: #22c55e; width: 24px; height: 24px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 5px rgba(0,0,0,0.3);"></div>`,
        iconSize: [24, 24],
        iconAnchor: [12, 12]
      });

      L.marker([worker.latitude, worker.longitude], { icon: customIcon })
        .addTo(map)
        .bindPopup(`<b>${worker.firstName} ${worker.lastName}</b><br>Quartier estimé`)
        .openPopup();

      mapInstanceRef.current = map;
    }

    // Cleanup
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, [worker]);

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id) return;
    setReviewStatus('submitting');
    
    await db.saveReview({
      workerId: id,
      userName: newReview.userName || "Client Anonyme",
      rating: newReview.rating,
      comment: newReview.comment
    });

    // Refresh data
    const [updatedReviews, updatedWorker] = await Promise.all([
        db.getReviewsByWorkerId(id),
        db.getWorkerById(id)
    ]);
    
    setReviews(updatedReviews);
    if (updatedWorker) setWorker(updatedWorker);
    setReviewStatus('success');
    setNewReview({ userName: '', rating: 5, comment: '' });
    
    setTimeout(() => setReviewStatus('idle'), 3000);
  };

  if (loading) return <div className="p-8 text-center">Chargement...</div>;
  if (!worker) return <div className="p-8 text-center">Ouvrier introuvable ou profil non validé.</div>;

  const getSpecialtyName = (id: string) => specialties.find(s => s.id === id)?.name;
  const getNeighborhoodName = (id: string) => neighborhoods.find(n => n.id === id)?.name;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 pb-20">
      <div className="bg-white dark:bg-gray-800 rounded-3xl shadow-xl overflow-hidden border border-gray-100 dark:border-gray-700">
        {/* Header */}
        <div className="bg-brand-600 h-32 md:h-48 relative">
           <div className="absolute -bottom-16 left-4 md:left-8">
             <img 
               src={worker.photoUrl} 
               alt={worker.firstName} 
               className="w-32 h-32 rounded-3xl border-4 border-white dark:border-gray-800 object-cover shadow-2xl"
             />
           </div>
        </div>

        <div className="pt-20 px-4 md:px-8 pb-8">
          <div className="flex flex-col md:flex-row md:items-start md:justify-between">
            <div>
              <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                <h1 className="text-3xl font-black text-gray-900 dark:text-white uppercase tracking-tighter">
                  {worker.firstName} {worker.lastName}
                </h1>
                {worker.isVerified && (
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-[10px] font-black uppercase bg-blue-600 text-white shadow-sm w-fit">
                    <BadgeCheck className="w-3 h-3 mr-1" />
                    Ouvrier Vérifié
                  </span>
                )}
              </div>
              <p className="text-xl text-brand-600 font-bold mt-1">{getSpecialtyName(worker.specialtyId)}</p>
              <div className="flex items-center text-gray-500 dark:text-gray-400 mt-2 text-sm font-medium">
                <MapPin className="w-4 h-4 mr-1 text-brand-600" />
                {getNeighborhoodName(worker.neighborhoodId)}
              </div>
            </div>

            <div className="mt-4 md:mt-0 flex flex-col gap-2">
               <div className="flex items-center bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-400 px-4 py-2 rounded-2xl w-fit border border-yellow-200 dark:border-yellow-800 shadow-sm">
                 <Star className="w-5 h-5 fill-current mr-2" />
                 <span className="font-black text-lg">{worker.rating}</span>
                 <span className="text-xs ml-2 font-bold opacity-70">({worker.reviewCount} avis)</span>
               </div>
               <span className={`px-4 py-1.5 rounded-2xl text-xs font-black uppercase w-fit tracking-wider shadow-sm border ${
                 worker.availability === 'available' 
                 ? 'bg-green-100 text-green-800 border-green-200' 
                 : 'bg-red-100 text-red-800 border-red-200'
               }`}>
                 {worker.availability === 'available' ? 'Disponible' : 'Occupé'}
               </span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-4">
             <a 
               href={`https://wa.me/${worker.whatsapp}`} 
               target="_blank" 
               rel="noreferrer"
               className="flex items-center justify-center bg-green-500 hover:bg-green-600 text-white py-4 rounded-2xl font-black shadow-lg transition-all active:scale-95 group"
             >
               <MessageCircle className="w-6 h-6 mr-3 group-hover:rotate-12 transition-transform" />
               CONTACTER WHATSAPP
             </a>
             <a 
               href={`tel:${worker.phone}`}
               className="flex items-center justify-center bg-gray-900 hover:bg-gray-800 dark:bg-gray-700 dark:hover:bg-gray-600 text-white py-4 rounded-2xl font-black shadow-lg transition-all active:scale-95 group"
             >
               <Phone className="w-6 h-6 mr-3 group-hover:animate-bounce" />
               APPELER {worker.phone}
             </a>
          </div>

          {/* Map Section */}
          {worker.latitude && worker.longitude && (
            <div className="mt-12 bg-gray-50 dark:bg-gray-900/50 p-4 rounded-3xl border border-gray-100 dark:border-gray-700">
              <h3 className="text-sm font-black text-gray-400 uppercase tracking-widest mb-4 flex items-center">
                <MapPin className="w-4 h-4 mr-2 text-brand-600" />
                Localisation à Niamey
              </h3>
              <div 
                ref={mapContainerRef} 
                className="w-full h-64 rounded-2xl shadow-inner z-0 border border-white dark:border-gray-800"
              />
              <p className="text-[10px] text-gray-500 mt-3 font-bold uppercase text-center opacity-60">
                La position exacte sera confirmée lors de votre échange téléphonique.
              </p>
            </div>
          )}

          {/* Work Gallery */}
          {worker.workImages && worker.workImages.length > 0 && (
            <div className="mt-12">
              <h3 className="text-xl font-black text-gray-900 dark:text-white mb-6 uppercase tracking-tight">Réalisations récentes</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {worker.workImages.map((img, idx) => (
                  <div key={idx} className="group overflow-hidden rounded-3xl shadow-lg border border-gray-100 dark:border-gray-700 aspect-video">
                    <img 
                      src={img} 
                      alt={`Travail ${idx + 1}`} 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Reviews Section */}
          <div className="mt-16 pt-16 border-t border-gray-100 dark:border-gray-700">
            <h3 className="text-2xl font-black text-gray-900 dark:text-white mb-8 flex items-center gap-2">
              <Star className="text-yellow-400 fill-current" /> Avis des Clients
            </h3>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
               {/* Reviews List */}
               <div className="lg:col-span-2 space-y-6">
                  {reviews.length > 0 ? (
                    reviews.map((rev) => (
                      <div key={rev.id} className="bg-gray-50 dark:bg-gray-900 p-6 rounded-3xl border border-gray-100 dark:border-gray-700 hover:shadow-md transition-shadow">
                        <div className="flex justify-between items-start mb-4">
                           <div className="flex items-center gap-3">
                              <div className="p-2 bg-brand-100 dark:bg-brand-900/30 text-brand-600 rounded-xl">
                                 <User size={20} />
                              </div>
                              <div>
                                 <h4 className="font-black text-gray-900 dark:text-white text-sm uppercase">{rev.userName}</h4>
                                 <p className="text-[10px] text-gray-400 font-bold flex items-center gap-1 uppercase">
                                   <Calendar size={10} /> {new Date(rev.date).toLocaleDateString()}
                                 </p>
                              </div>
                           </div>
                           <div className="flex text-yellow-400">
                              {[...Array(5)].map((_, i) => (
                                <Star key={i} size={14} fill={i < rev.rating ? "currentColor" : "none"} />
                              ))}
                           </div>
                        </div>
                        <p className="text-gray-600 dark:text-gray-300 text-sm italic leading-relaxed">
                          "{rev.comment}"
                        </p>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-12 bg-gray-50 dark:bg-gray-900/50 rounded-3xl border-2 border-dashed border-gray-200 dark:border-gray-700">
                       <Star className="w-12 h-12 mx-auto text-gray-200 mb-4" />
                       <p className="text-gray-400 font-bold">Aucun avis pour le moment. Soyez le premier !</p>
                    </div>
                  )}
               </div>

               {/* Review Form */}
               <div className="lg:col-span-1">
                  <div className="bg-brand-50 dark:bg-gray-900 p-6 rounded-3xl border border-brand-100 dark:border-gray-700 sticky top-24">
                     <h4 className="font-black text-brand-900 dark:text-white mb-6 flex items-center gap-2">
                        <Send size={18} className="text-brand-600" /> Laisser un avis
                     </h4>
                     
                     {reviewStatus === 'success' ? (
                       <div className="text-center py-8 animate-in zoom-in duration-300">
                          <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                          <p className="font-black text-green-600">Merci pour votre avis !</p>
                       </div>
                     ) : (
                       <form onSubmit={handleReviewSubmit} className="space-y-4">
                          <div>
                             <label className="block text-[10px] font-black uppercase text-gray-400 mb-1">Votre Nom</label>
                             <input 
                               type="text" 
                               placeholder="Ex: Abdou S."
                               required
                               value={newReview.userName}
                               onChange={e => setNewReview({...newReview, userName: e.target.value})}
                               className="w-full p-3 bg-white dark:bg-gray-800 border-0 rounded-2xl text-sm font-bold shadow-sm focus:ring-2 focus:ring-brand-500"
                             />
                          </div>
                          
                          <div>
                             <label className="block text-[10px] font-black uppercase text-gray-400 mb-1">Note globale</label>
                             <div className="flex gap-2 p-2 bg-white dark:bg-gray-800 rounded-2xl justify-center">
                                {[1, 2, 3, 4, 5].map((star) => (
                                   <button
                                     key={star}
                                     type="button"
                                     onMouseEnter={() => setHoverRating(star)}
                                     onMouseLeave={() => setHoverRating(0)}
                                     onClick={() => setNewReview({...newReview, rating: star})}
                                     className="transition-transform active:scale-90"
                                   >
                                     <Star 
                                       size={24} 
                                       className={`${(hoverRating || newReview.rating) >= star ? 'text-yellow-400 fill-current' : 'text-gray-200'} transition-colors`}
                                     />
                                   </button>
                                ))}
                             </div>
                          </div>

                          <div>
                             <label className="block text-[10px] font-black uppercase text-gray-400 mb-1">Votre Commentaire</label>
                             <textarea 
                               rows={4}
                               required
                               placeholder="Racontez votre expérience..."
                               value={newReview.comment}
                               onChange={e => setNewReview({...newReview, comment: e.target.value})}
                               className="w-full p-3 bg-white dark:bg-gray-800 border-0 rounded-2xl text-sm font-medium shadow-sm focus:ring-2 focus:ring-brand-500 resize-none"
                             />
                          </div>

                          <button 
                            type="submit"
                            disabled={reviewStatus === 'submitting'}
                            className="w-full bg-brand-600 text-white py-3 rounded-2xl font-black shadow-lg hover:bg-brand-700 transition-all active:scale-95 disabled:opacity-50"
                          >
                             {reviewStatus === 'submitting' ? 'Envoi...' : 'PUBLIER MON AVIS'}
                          </button>
                       </form>
                     )}
                  </div>
               </div>
            </div>
          </div>

           {/* Legal Disclaimer for Client */}
           <div className="mt-16 p-6 bg-yellow-50 dark:bg-yellow-900/20 rounded-3xl text-sm text-yellow-800 dark:text-yellow-200 border border-yellow-100 dark:border-yellow-800 shadow-sm flex items-start gap-4">
             <CheckCircle className="shrink-0 mt-0.5" size={20} />
             <p className="font-medium">
               <strong>Note de sécurité :</strong> KAMBEGOYE facilite la mise en relation mais ne peut être tenu responsable des travaux. Nous vous conseillons de vérifier les références de l'artisan avant de commencer tout chantier important.
             </p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default WorkerDetails;
