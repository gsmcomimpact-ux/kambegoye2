
import React from 'react';

const CGU = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-8 text-gray-900 dark:text-white">Conditions Générales d'Utilisation (CGU)</h1>
      <div className="prose dark:prose-invert max-w-none text-gray-700 dark:text-gray-300 space-y-6">
        <section>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2">1. Objet</h2>
          <p>
            Les présentes CGU ont pour objet de définir les modalités de mise à disposition des services du site KAMBEGOYE, 
            permettant la mise en relation entre des particuliers (Clients) et des professionnels du bâtiment (Ouvriers) à Niamey.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2">2. Responsabilités et Paiement des Travaux</h2>
          <p>
            KAMBEGOYE agit uniquement en tant qu'intermédiaire. Nous ne sommes pas responsables de la qualité des travaux réalisés, 
            des délais, ou des litiges pouvant survenir entre le client et l'ouvrier.
          </p>
          <p className="font-bold bg-yellow-50 dark:bg-yellow-900/20 p-4 border-l-4 border-yellow-500 text-yellow-800 dark:text-yellow-200 mt-4">
             CONSEIL DE SÉCURITÉ : Ne jamais payer la totalité de l'argent avant la fin des travaux. Il est recommandé de verser un acompte pour le matériel et de régler le solde uniquement après réception et validation du chantier.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2">3. Paiement du service KAMBEGOYE</h2>
          <p>
            L'accès aux coordonnées complètes des ouvriers nécessite un paiement forfaitaire (généralement 200 FCFA) via Mobile Money. 
            Ce paiement donne accès aux informations de contact. Ce montant est non remboursable.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2">4. Données Personnelles</h2>
          <p>
            Les données collectées sont utilisées uniquement pour le fonctionnement du service. 
            Conformément à la réglementation, vous disposez d'un droit d'accès et de suppression de vos données.
          </p>
        </section>

         <section>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2">5. Sécurité</h2>
          <p>
            Les pièces d'identité des ouvriers "Vérifiés" sont stockées de manière sécurisée et ne sont jamais partagées publiquement.
          </p>
        </section>
      </div>
    </div>
  );
};

export default CGU;
