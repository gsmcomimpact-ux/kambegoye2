
import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingBag, Search, ShoppingCart, Plus, Minus, MessageCircle, X, Store, FilterX, ChevronRight, Star, Tag } from 'lucide-react';
import { db } from '../services/db';
import { Product, ProductCategory, CartItem, Partner } from '../types';

const ITEMS_PER_PAGE = 12;

const Shop = () => {
  const navigate = useNavigate();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<ProductCategory[]>([]);
  const [partners, setPartners] = useState<Partner[]>([]);
  const [loading, setLoading] = useState(true);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showCart, setShowCart] = useState(false);
  
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [partnerFilter, setPartnerFilter] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  // Suggestions state
  const [suggestions, setSuggestions] = useState<Product[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const loadData = async () => {
        const [prodData, catData, partData] = await Promise.all([
            db.getProducts(),
            db.getProductCategories(),
            db.getPartners()
        ]);
        setProducts(prodData);
        setCategories(catData);
        setPartners(partData.filter(p => p.isVisible));
        setCart(db.getCart());
        setLoading(false);
    };
    loadData();

    const updateCart = () => setCart(db.getCart());
    window.addEventListener('cart-updated', updateCart);
    return () => window.removeEventListener('cart-updated', updateCart);
  }, []);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSearchChange = (val: string) => {
    setSearchTerm(val);
    setCurrentPage(1);
    if (val.length > 1) {
        const q = val.toLowerCase();
        const filtered = products.filter(p => 
            p.name.toLowerCase().includes(q) || 
            p.category.toLowerCase().includes(q) ||
            partners.find(part => part.id === p.partnerId)?.name.toLowerCase().includes(q)
        ).slice(0, 6);
        setSuggestions(filtered);
        setShowSuggestions(true);
    } else {
        setSuggestions([]);
        setShowSuggestions(false);
    }
  };

  const resetFilters = () => {
    setSearchTerm('');
    setCategoryFilter('');
    setPartnerFilter('');
    setCurrentPage(1);
    setSuggestions([]);
    setShowSuggestions(false);
  };

  const filteredProducts = products.filter(p => {
    const partner = partners.find(part => part.id === p.partnerId);
    const partnerName = partner ? partner.name.toLowerCase() : 'kambegoye';
    
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          p.description.toLowerCase().includes(searchTerm.toLowerCase());
                          
    const matchesCategory = categoryFilter ? p.category === categoryFilter : true;
    const matchesPartner = partnerFilter ? p.partnerId === partnerFilter : true;
    const matchesPartnerSearch = partnerName.includes(searchTerm.toLowerCase());
    
    return (matchesSearch || matchesPartnerSearch) && matchesCategory && matchesPartner;
  });

  const totalPages = Math.ceil(filteredProducts.length / ITEMS_PER_PAGE);
  const displayedProducts = filteredProducts.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header Compact */}
      <div className="flex flex-col md:flex-row justify-between items-center mb-10 gap-6">
        <div>
            <h1 className="text-3xl font-black text-gray-900 dark:text-white uppercase tracking-tighter">
            Boutique <span className="text-brand-600">KAMBEGOYE</span>
            </h1>
        </div>
        <button 
            onClick={() => setShowCart(true)}
            className="flex items-center gap-2 bg-brand-600 text-white px-6 py-3 rounded-2xl font-black shadow-lg hover:bg-brand-700 transition-all uppercase text-[10px] tracking-widest"
        >
            <ShoppingCart size={18} />
            Panier ({cart.length})
        </button>
      </div>

      {/* SEARCH BAR - SINGLE LINE */}
      <div className="mb-12 relative" ref={searchRef}>
        <div className="bg-white dark:bg-gray-800 p-2 rounded-[2rem] shadow-2xl flex flex-col lg:flex-row items-stretch border border-gray-100 dark:border-gray-700 overflow-hidden ring-brand-500/0 focus-within:ring-4 ring-brand-500/10 transition-all">
          
          <div className="relative flex-1 group">
            <div className="absolute inset-y-0 left-0 pl-6 flex items-center pointer-events-none">
               <Search className="h-5 w-5 text-brand-600 group-focus-within:text-brand-600 transition-colors" />
            </div>
            <input
              type="text"
              placeholder="Rechercher un produit, un matériau..."
              className="block w-full pl-14 pr-4 py-5 border-0 bg-transparent dark:text-white font-black uppercase text-[11px] tracking-widest focus:ring-0 outline-none placeholder:text-gray-300"
              value={searchTerm}
              onChange={(e) => handleSearchChange(e.target.value)}
              onFocus={() => searchTerm.length > 1 && setShowSuggestions(true)}
            />
          </div>

          <div className="hidden lg:block w-px bg-gray-100 dark:bg-gray-700 my-4"></div>

          <div className="relative lg:w-64">
            <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none text-gray-400">
               <ShoppingBag size={16} />
            </div>
            <select
              value={categoryFilter}
              onChange={(e) => {setCategoryFilter(e.target.value); setCurrentPage(1);}}
              className="w-full pl-10 pr-10 py-5 bg-transparent border-0 font-black uppercase text-[10px] tracking-widest text-gray-600 dark:text-gray-300 outline-none focus:ring-0 cursor-pointer appearance-none"
            >
              <option value="">Toutes Catégories</option>
              {categories.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
            </select>
          </div>

          <div className="hidden lg:block w-px bg-gray-100 dark:bg-gray-700 my-4"></div>

          <div className="relative lg:w-64">
            <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none text-brand-600">
               <Store size={16} />
            </div>
            <select
              value={partnerFilter}
              onChange={(e) => {setPartnerFilter(e.target.value); setCurrentPage(1);}}
              className="w-full pl-10 pr-10 py-5 bg-transparent border-0 font-black uppercase text-[10px] tracking-widest text-brand-600 outline-none focus:ring-0 cursor-pointer appearance-none"
            >
              <option value="">Tous les Partenaires</option>
              {partners.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>

          <div className="p-1 flex gap-1">
             {(searchTerm || categoryFilter || partnerFilter) && (
                <button onClick={resetFilters} className="p-4 text-gray-400 hover:text-red-500 transition-colors" title="Réinitialiser">
                    <FilterX size={20} />
                </button>
             )}
          </div>
        </div>

        {/* Instant Product Suggestions */}
        {showSuggestions && suggestions.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-4 bg-white dark:bg-gray-800 rounded-[2.5rem] shadow-[0_30px_60px_-12px_rgba(0,0,0,0.25)] border border-gray-100 dark:border-gray-700 overflow-hidden z-[60] animate-in fade-in slide-in-from-top-2 duration-300">
                <div className="p-4 border-b border-gray-50 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50">
                    <span className="text-[10px] font-black uppercase text-gray-400 tracking-widest px-4">Résultats instantanés</span>
                </div>
                <div className="max-h-96 overflow-y-auto">
                    {suggestions.map(prod => (
                        <div 
                            key={prod.id} 
                            onClick={() => { navigate(`/boutique/${prod.id}`); setShowSuggestions(false); }}
                            className="flex items-center gap-4 p-4 hover:bg-brand-50 dark:hover:bg-gray-700 cursor-pointer transition-colors group border-b border-gray-50 dark:border-gray-700 last:border-0"
                        >
                            <img src={prod.imageUrl} className="w-14 h-14 rounded-2xl object-cover shadow-sm group-hover:scale-105 transition-transform" />
                            <div className="flex-1">
                                <h4 className="font-black text-gray-900 dark:text-white uppercase text-xs tracking-tight">{prod.name}</h4>
                                <div className="flex items-center gap-2 mt-1">
                                    <span className="text-[9px] font-black text-brand-600 uppercase tracking-widest">{prod.category}</span>
                                    <span className="text-[9px] text-gray-300">•</span>
                                    <span className="text-[9px] font-black text-orange-600 uppercase tracking-widest">
                                        {partners.find(p => p.id === prod.partnerId)?.name || 'KAMBEGOYE'}
                                    </span>
                                </div>
                            </div>
                            <div className="text-right">
                                <p className="text-sm font-black text-brand-600">{prod.price.toLocaleString()} F</p>
                                {prod.stock > 0 ? (
                                    <span className="text-[8px] font-black text-green-500 uppercase">En stock</span>
                                ) : (
                                    <span className="text-[8px] font-black text-red-500 uppercase tracking-tighter">Rupture</span>
                                )}
                            </div>
                            <ChevronRight className="text-gray-300 group-hover:text-brand-600 transition-colors ml-2" size={18} />
                        </div>
                    ))}
                </div>
                <div className="p-4 text-center">
                    <button onClick={() => setShowSuggestions(false)} className="text-[10px] font-black uppercase text-gray-400 hover:text-brand-600 tracking-widest">Voir tous les résultats</button>
                </div>
            </div>
        )}
      </div>

      {/* Grid Produits */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
        {displayedProducts.map((product) => {
          const partner = partners.find(p => p.id === product.partnerId);
          return (
            <div key={product.id} className="group bg-white dark:bg-gray-800 rounded-[2.5rem] shadow-sm overflow-hidden hover:shadow-2xl transition-all border border-gray-100 dark:border-gray-700 flex flex-col h-full ring-brand-500/0 hover:ring-2 ring-offset-4">
              <Link to={`/boutique/${product.id}`} className="relative h-64 block overflow-hidden bg-gray-50">
                <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                
                {partner && (
                   <div className="absolute bottom-4 left-4 flex items-center gap-2 bg-white/90 dark:bg-gray-800/90 backdrop-blur-md px-3 py-1.5 rounded-2xl border border-gray-100 shadow-xl">
                      <img src={partner.logoUrl} className="w-5 h-5 object-contain" alt={partner.name} />
                      <span className="text-[9px] font-black uppercase text-gray-900 dark:text-white">{partner.name}</span>
                   </div>
                )}

                {product.stock === 0 && (
                   <div className="absolute inset-0 bg-white/60 backdrop-blur-[2px] flex items-center justify-center">
                      <span className="bg-red-600 text-white px-4 py-1 rounded-full font-black text-[10px] uppercase tracking-widest shadow-lg">Rupture</span>
                   </div>
                )}
              </Link>
              
              <div className="p-6 flex-grow flex flex-col">
                <p className="text-[9px] text-brand-600 font-black uppercase tracking-[0.2em] mb-2">{product.category}</p>
                <h3 className="font-black text-gray-900 dark:text-white mb-4 line-clamp-2 min-h-[3rem] tracking-tight uppercase leading-tight">{product.name}</h3>
                
                <div className="flex items-center justify-between mt-auto pt-6 border-t border-gray-50 dark:border-gray-700">
                  <span className="text-2xl font-black text-brand-600 tracking-tighter">{product.price.toLocaleString()} F</span>
                  <button 
                    onClick={(e) => { e.preventDefault(); db.addToCart(product); }}
                    disabled={product.stock === 0}
                    className="bg-brand-600 text-white p-3 rounded-2xl hover:bg-brand-700 transition-all shadow-lg active:scale-90 disabled:opacity-20"
                  >
                    <Plus size={24} />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {displayedProducts.length === 0 && !loading && (
          <div className="py-24 text-center bg-white dark:bg-gray-800 rounded-[3rem] border border-dashed border-gray-200 dark:border-gray-700">
              <ShoppingBag size={64} className="mx-auto text-gray-200 mb-6" />
              <h2 className="text-2xl font-black text-gray-400 uppercase tracking-tighter">Aucun produit trouvé</h2>
              <p className="text-gray-500 mt-2 font-medium">Réessayez avec d'autres mots-clés ou filtres.</p>
              <button onClick={resetFilters} className="mt-8 text-brand-600 font-black uppercase tracking-widest text-xs hover:underline">Voir tout le catalogue</button>
          </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
          <div className="mt-16 flex justify-center gap-2">
              {[...Array(totalPages)].map((_, i) => (
                  <button
                      key={i}
                      onClick={() => { setCurrentPage(i+1); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                      className={`w-10 h-10 rounded-xl font-black transition-all ${currentPage === i + 1 ? 'bg-brand-600 text-white shadow-lg' : 'bg-white dark:bg-gray-800 text-gray-400 hover:bg-brand-50'}`}
                  >
                      {i + 1}
                  </button>
              ))}
          </div>
      )}

      {/* Cart Drawer */}
      {showCart && (
          <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex justify-end animate-in fade-in duration-300">
              <div className="w-full max-w-md bg-white dark:bg-gray-800 h-full shadow-2xl animate-in slide-in-from-right duration-500 flex flex-col">
                  <div className="p-8 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center">
                      <h2 className="text-2xl font-black flex items-center gap-3 uppercase tracking-tighter">
                          <ShoppingCart className="text-brand-600" size={28} /> Panier
                      </h2>
                      <button onClick={() => setShowCart(false)} className="p-2 hover:bg-gray-100 rounded-full transition-colors"><X size={24} /></button>
                  </div>
                  <div className="flex-1 overflow-y-auto p-8 space-y-6">
                      {cart.length === 0 ? (
                          <div className="text-center py-20 opacity-20">
                             <ShoppingBag size={80} className="mx-auto mb-4" />
                             <p className="font-black uppercase tracking-widest text-xs">Vide</p>
                          </div>
                      ) : cart.map(item => (
                          <div key={item.id} className="flex gap-4 p-4 bg-gray-50 dark:bg-gray-900 rounded-3xl border border-gray-100">
                              <img src={item.imageUrl} className="w-20 h-20 object-cover rounded-xl" alt={item.name} />
                              <div className="flex-1">
                                  <h4 className="font-black text-[10px] uppercase line-clamp-1">{item.name}</h4>
                                  <p className="text-brand-600 font-black text-sm">{item.price.toLocaleString()} F</p>
                                  <div className="flex items-center gap-3 mt-2">
                                      <div className="flex items-center bg-white dark:bg-gray-800 rounded-lg shadow-sm">
                                          <button onClick={() => db.updateCartQuantity(item.id, -1)} className="p-1 px-2 text-gray-400 hover:text-brand-600"><Minus size={12}/></button>
                                          <span className="text-xs font-black px-1">{item.quantity}</span>
                                          <button onClick={() => db.updateCartQuantity(item.id, 1)} className="p-1 px-2 text-gray-400 hover:text-brand-600"><Plus size={12}/></button>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      ))}
                  </div>
                  {cart.length > 0 && (
                      <div className="p-8 border-t border-gray-100 bg-gray-50 dark:bg-gray-900">
                          <div className="flex justify-between items-end mb-6">
                             <span className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Total</span>
                             <span className="text-3xl font-black text-brand-600 tracking-tighter">{cart.reduce((s,i)=>s+(i.price*i.quantity),0).toLocaleString()} F</span>
                          </div>
                          <Link to="/panier" className="block w-full bg-brand-600 text-white py-4 rounded-2xl font-black text-center uppercase tracking-widest text-[10px] shadow-xl hover:bg-brand-700 transition-all">
                             Finaliser la Commande
                          </Link>
                      </div>
                  )}
              </div>
          </div>
      )}
    </div>
  );
};

export default Shop;
