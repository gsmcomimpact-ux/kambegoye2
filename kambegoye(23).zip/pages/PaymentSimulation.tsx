
import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { ShieldCheck, Lock, Banknote, Info, MapPin, Smartphone, AlertCircle, Loader } from 'lucide-react';
import { IPAY_CONFIG } from '../constants';

const PaymentSimulation = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [pin, setPin] = useState('');
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState('');

  const amount = searchParams.get('amount');
  const method = searchParams.get('method');
  const phone = searchParams.get('phone');
  const ref = searchParams.get('ref');
  const tid = searchParams.get('tid');
  const isCash = searchParams.get('type') === 'cash';

  useEffect(() => {
      if (ref && method) {
          sessionStorage.setItem(`sim_method_${ref}`, method);
      }
  }, [ref, method]);

  const handleConfirm = () => {
      setProcessing(true);
      setError('');

      // Simulation de la logique de test i-pay basée sur le MSISDN (Doc)
      setTimeout(() => {
        let finalStatus = 'succeeded';
        
        // Numéros de test de la doc i-pay
        if (phone === '40410000002' || phone === '40410000003') {
            finalStatus = 'failed';
            setError("Erreur technique (Code i-pay 400).");
        } else if (phone === '40410000004' || phone === '40410000005') {
            finalStatus = 'failed';
            setError("Fonds insuffisants.");
        } else if (phone === '40410000006' || phone === '40410000007') {
            finalStatus = 'failed';
            setError("Transaction déclinée par l'opérateur.");
        }

        if (finalStatus === 'failed') {
            setProcessing(false);
            return;
        }

        sessionStorage.setItem(`sim_status_${ref}`, 'succeeded');
        navigate(`${IPAY_CONFIG.SUCCESS_REDIRECT}?ref=${ref}`);
      }, 2000);
  };

  const handleCancel = () => {
      sessionStorage.setItem(`sim_status_${ref}`, 'failed');
      navigate(IPAY_CONFIG.CANCEL_REDIRECT);
  };

  if (isCash) {
      return (
          <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4 font-sans">
              <div className="bg-white max-w-sm w-full rounded-[2rem] shadow-2xl overflow-hidden border-t-8 border-accent-600">
                  <div className="p-8 text-center border-b border-gray-100">
                      <div className="mx-auto w-16 h-16 bg-accent-100 rounded-2xl flex items-center justify-center mb-4">
                          <Banknote className="text-accent-600" size={32} />
                      </div>
                      <h1 className="text-2xl font-black text-gray-800 uppercase tracking-tighter">KAMBEGOYE AGENCIE</h1>
                      <p className="text-[10px] text-gray-400 mt-1 uppercase font-bold tracking-widest">Paiement en Agence</p>
                  </div>
                  
                  <div className="p-8 space-y-6">
                      <div className="flex justify-between items-center">
                          <span className="text-gray-400 font-black uppercase text-[10px]">Montant à régler</span>
                          <span className="font-black text-2xl text-accent-600">{amount} FCFA</span>
                      </div>

                      <div className="bg-gray-50 p-5 rounded-2xl space-y-4 border border-gray-100 shadow-inner">
                          <div className="flex gap-3">
                              <MapPin size={18} className="text-accent-600 shrink-0" />
                              <p className="text-xs font-medium text-gray-600 leading-relaxed">Siège : <br/><strong>Quartier Poudrière, Niamey</strong></p>
                          </div>
                          <div className="flex gap-3">
                              <Info size={18} className="text-accent-600 shrink-0" />
                              <p className="text-xs font-medium text-gray-600 leading-relaxed">Référence : <strong className="text-brand-600">#{tid?.slice(-8).toUpperCase()}</strong></p>
                          </div>
                      </div>
                  </div>

                  <div className="p-8 bg-gray-50 flex gap-3">
                      <button onClick={handleCancel} className="flex-1 py-4 text-xs font-black uppercase tracking-widest text-gray-400 border border-gray-200 bg-white rounded-xl">ANNULER</button>
                      <button onClick={handleConfirm} disabled={processing} className="flex-1 py-4 text-xs font-black uppercase tracking-widest text-white bg-accent-600 rounded-xl shadow-lg">
                          {processing ? 'VALIDATION...' : 'CONFIRMER'}
                      </button>
                  </div>
              </div>
          </div>
      );
  }

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4 font-sans">
       <div className="bg-white max-w-sm w-full rounded-2xl shadow-2xl overflow-hidden border-t-8 border-blue-600">
          <div className="p-6 text-center border-b border-gray-200 bg-gray-50/50">
             <h1 className="text-2xl font-black text-gray-800 italic">i-pay<span className="text-blue-600">.money</span></h1>
             <div className="mt-1 flex items-center justify-center gap-2">
                 <span className="text-[10px] text-white bg-orange-500 px-2 py-0.5 rounded font-black uppercase tracking-widest">SANDBOX</span>
                 <span className="text-[10px] text-gray-400 uppercase font-bold tracking-widest">Sécurisé SSL</span>
             </div>
          </div>
          
          <div className="p-6 space-y-5">
             <div className="flex justify-between items-center text-sm border-b border-dashed border-gray-100 pb-2">
                 <span className="text-gray-500 font-bold uppercase text-[10px]">Marchand</span>
                 <span className="font-black text-gray-800 uppercase">KAMBEGOYE</span>
             </div>
             
             <div className="bg-blue-50 p-4 rounded-xl flex justify-between items-center">
                 <span className="text-blue-700 font-black uppercase text-xs">Total à payer</span>
                 <span className="font-black text-xl text-blue-700">{amount} F</span>
             </div>

             <div className="space-y-4">
                 <div className="bg-gray-50 p-3 rounded-xl border border-gray-100">
                    <p className="text-[9px] font-black text-gray-400 uppercase mb-1">Compte {method}</p>
                    <div className="flex items-center gap-2">
                        <Smartphone size={16} className="text-blue-600" />
                        <span className="font-mono font-bold text-gray-700">{phone}</span>
                    </div>
                 </div>

                 {error && (
                    <div className="p-3 bg-red-50 text-red-600 rounded-xl text-xs font-bold flex items-center gap-2 animate-shake">
                        <AlertCircle size={16} /> {error}
                    </div>
                 )}

                 <div>
                     <label className="block text-[10px] font-black text-gray-700 uppercase mb-2 tracking-widest">Code PIN de Validation</label>
                     <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input 
                        type="password" 
                        className="w-full pl-10 pr-4 py-3 bg-white border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 font-mono"
                        placeholder="****"
                        maxLength={4}
                        value={pin}
                        onChange={e => setPin(e.target.value)}
                        />
                     </div>
                     <p className="text-[9px] text-gray-400 mt-2 italic">Note doc: Utilisez <strong>40410000000</strong> comme numéro pour un succès garanti.</p>
                 </div>
             </div>
          </div>

          <div className="p-6 bg-gray-50/50 flex gap-3">
             <button onClick={handleCancel} className="flex-1 py-4 text-xs font-black text-gray-400 uppercase bg-white border border-gray-200 rounded-xl hover:bg-gray-100">ANNULER</button>
             <button 
                onClick={handleConfirm}
                disabled={processing || pin.length < 1}
                className="flex-1 py-4 text-xs font-black text-white bg-blue-600 rounded-xl shadow-lg hover:bg-blue-700 active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2"
             >
                 {processing ? <><Loader className="animate-spin" size={14}/> TRAITEMENT...</> : 'VALIDER LE PAIEMENT'}
             </button>
          </div>
          
          <div className="py-3 text-center bg-gray-100 text-[8px] text-gray-400 font-bold uppercase tracking-[0.2em]">
             Powered by i-PayMoney Gateway
          </div>
       </div>
    </div>
  );
};

export default PaymentSimulation;
