
import React, { useState, useEffect, useRef } from 'react';
import { useSearchParams, Link, useNavigate, NavigateFunction } from 'react-router-dom';
import { Star, MapPin, BadgeCheck, Lock, RotateCw, Map, AlertCircle, Search as SearchIcon, Loader, Info, ChevronRight, Navigation, X, User } from 'lucide-react';
import { db } from '../services/db';
import { Worker, Specialty, Neighborhood } from '../types';

interface WorkerCardProps {
  worker: Worker;
  isNearby?: boolean;
  hasPaid: boolean;
  navigate: NavigateFunction;
  specialties: Specialty[];
  neighborhoods: Neighborhood[];
  specialtyFilter: string;
  locationFilter: string;
  userCoords: { lat: number, lng: number } | null;
}

const WorkerCard: React.FC<WorkerCardProps> = ({ worker, isNearby = false, hasPaid, navigate, specialties, neighborhoods, specialtyFilter, locationFilter, userCoords }) => {
  const specialtyName = specialties.find(s => s.id === worker.specialtyId)?.name;
  const neighborhoodName = neighborhoods.find(n => n.id === worker.neighborhoodId)?.name;
  
  const distance = (userCoords && worker.latitude && worker.longitude) 
    ? db.calculateDistance(userCoords.lat, userCoords.lng, worker.latitude, worker.longitude)
    : null;

  const handlePayClick = () => {
      const params = new URLSearchParams();
      if (specialtyFilter) params.append('return_spec', specialtyFilter);
      if (locationFilter) params.append('return_loc', locationFilter);
      params.append('worker_id', worker.id); 
      navigate(`/payment?${params.toString()}`);
  };

  return (
    <div className={`rounded-[2rem] shadow-sm overflow-hidden hover:shadow-xl transition-all border group ${isNearby ? 'border-orange-100 bg-orange-50/30 dark:bg-gray-800/50 dark:border-orange-900/20 ring-1 ring-orange-200 dark:ring-orange-900/40' : 'bg-white dark:bg-gray-800 border-gray-100 dark:border-gray-700'}`}>
      <div className="relative h-56 overflow-hidden">
        <img 
          src={worker.photoUrl} 
          alt={`${worker.firstName} ${worker.lastName}`} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
        
        {worker.isVerified && (
          <div className="absolute top-4 right-4 bg-blue-600 text-white text-[10px] font-black px-3 py-1 rounded-full flex items-center shadow-lg uppercase tracking-widest z-10">
            <BadgeCheck className="w-3 h-3 mr-1" /> Vérifié
          </div>
        )}

        {distance !== null && (
          <div className="absolute top-4 left-4 bg-brand-600 text-white text-[10px] font-black px-3 py-1 rounded-full flex items-center shadow-lg uppercase tracking-widest z-10 border border-white/20 backdrop-blur-sm">
            <Navigation className="w-3 h-3 mr-1" /> à {distance.toFixed(1)} km
          </div>
        )}

        {isNearby && distance === null && (
          <div className="absolute top-4 left-4 bg-orange-500 text-white text-[10px] font-black px-3 py-1 rounded-full flex items-center shadow-lg uppercase tracking-widest z-10">
            <MapPin className="w-3 h-3 mr-1" /> Alternative proche
          </div>
        )}

        <div className={`absolute bottom-4 left-4 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest shadow-md ${
          worker.availability === 'available' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'
        }`}>
          {worker.availability === 'available' ? '● Disponible' : '○ Occupé'}
        </div>
      </div>

      <div className="p-6">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h3 className="text-xl font-black text-gray-900 dark:text-white uppercase tracking-tighter">{worker.firstName} {worker.lastName}</h3>
            <p className="text-brand-600 font-bold text-sm">{specialtyName}</p>
          </div>
          <div className="flex items-center bg-yellow-50 dark:bg-yellow-900/20 text-yellow-700 dark:text-yellow-400 px-2 py-1 rounded-xl border border-yellow-100 dark:border-yellow-800">
            <Star className="w-3.5 h-3.5 fill-current mr-1" />
            <span className="text-xs font-black">{worker.rating}</span>
          </div>
        </div>

        <div className="mt-4 flex items-center text-gray-500 dark:text-gray-400 text-sm font-medium">
          <MapPin className="w-4 h-4 mr-2 text-brand-600" />
          {neighborhoodName}
        </div>

        <div className="mt-6 pt-6 border-t border-gray-50 dark:border-gray-700">
          {hasPaid ? (
            <Link 
              to={`/ouvrier/${worker.id}`}
              className="block w-full text-center bg-brand-600 text-white py-4 rounded-2xl hover:bg-brand-700 transition-all font-black uppercase tracking-widest text-xs shadow-lg active:scale-95 flex items-center justify-center gap-2"
            >
              Voir Profil Complet
              <ChevronRight size={14} />
            </Link>
          ) : (
            <button 
                onClick={handlePayClick}
                className="block w-full text-center bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 py-4 rounded-2xl hover:bg-gray-200 dark:hover:bg-gray-600 transition-all font-black uppercase tracking-widest text-xs flex items-center justify-center gap-2 group/btn"
            >
                <Lock className="w-4 h-4 group-hover/btn:rotate-12 transition-transform" />
                Débloquer Contact
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

const Search = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  
  const [allWorkers, setAllWorkers] = useState<Worker[]>([]);
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [nearbyWorkers, setNearbyWorkers] = useState<Worker[]>([]);
  
  const [specialties, setSpecialties] = useState<Specialty[]>([]);
  const [neighborhoods, setNeighborhoods] = useState<Neighborhood[]>([]);
  const [hasPaid, setHasPaid] = useState(false);
  const [loading, setLoading] = useState(true);
  const [locationLoading, setLocationLoading] = useState(false);
  const [consultationPrice, setConsultationPrice] = useState(200);
  const [userCoords, setUserCoords] = useState<{lat: number, lng: number} | null>(null);

  // Instant Search State
  const [textSearch, setTextSearch] = useState(searchParams.get('q') || '');
  const [suggestions, setSuggestions] = useState<Worker[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  const specialtyFilter = searchParams.get('specialty') || '';
  const locationFilter = searchParams.get('location') || '';

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const shuffleArray = (array: Worker[]) => {
      const newArr = [...array];
      for (let i = newArr.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [newArr[i], newArr[j]] = [newArr[j], newArr[i]];
      }
      return newArr;
  };

  const handleUseLocation = () => {
    setLocationLoading(true);
    if (!navigator.geolocation) {
        alert("La géolocalisation n'est pas supportée par votre navigateur.");
        setLocationLoading(false);
        return;
    }

    navigator.geolocation.getCurrentPosition(
        (position) => {
            const coords = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };
            setUserCoords(coords);
            setLocationLoading(false);
            handleFilterChange('location', '');
        },
        (error) => {
            console.error("Geolocation error:", error);
            alert("Impossible de récupérer votre position. Vérifiez les permissions.");
            setLocationLoading(false);
        },
        { enableHighAccuracy: true }
    );
  };

  useEffect(() => {
    const loadInitialData = async () => {
      const [allW, specs, hoods, settings] = await Promise.all([
        db.getWorkers(),
        db.getSpecialties(),
        db.getNeighborhoods(),
        db.getSettings()
      ]);
      setAllWorkers(allW);
      setSpecialties(specs);
      setNeighborhoods(hoods);
      setConsultationPrice(settings.consultationPrice);
      setHasPaid(db.hasPaid());
      setLoading(false);
    };
    loadInitialData();
  }, []);

  useEffect(() => {
    if (loading) return;
    
    let baseList = allWorkers.filter(w => w.accountStatus === 'active');
    
    // Proximity logic
    if (userCoords) {
        baseList = baseList.map(w => ({
            ...w,
            _dist: (w.latitude && w.longitude) ? db.calculateDistance(userCoords.lat, userCoords.lng, w.latitude, w.longitude) : Infinity
        })).sort((a: any, b: any) => a._dist - b._dist);
    }

    let exactMatches = [...baseList];
    
    // Filter by Specialty
    if (specialtyFilter) {
      exactMatches = exactMatches.filter(w => w.specialtyId === specialtyFilter);
    }
    
    // Filter by Location
    if (locationFilter) {
      exactMatches = exactMatches.filter(w => w.neighborhoodId === locationFilter);
    }

    // Filter by Search Text
    if (textSearch) {
      const q = textSearch.toLowerCase();
      exactMatches = exactMatches.filter(w => 
        w.firstName.toLowerCase().includes(q) || 
        w.lastName.toLowerCase().includes(q) ||
        specialties.find(s => s.id === w.specialtyId)?.name.toLowerCase().includes(q)
      );
    }
    
    const processedMatches = userCoords ? exactMatches : shuffleArray(exactMatches);
    setWorkers(processedMatches.slice(0, userCoords ? 10 : 6));

    // Fallbacks
    if ((locationFilter || textSearch) && processedMatches.length === 0) {
       const nearby = baseList.filter(w => 
           (specialtyFilter ? w.specialtyId === specialtyFilter : true) && 
           (locationFilter ? w.neighborhoodId !== locationFilter : true)
       );
       const processedNearby = userCoords ? nearby : shuffleArray(nearby);
       setNearbyWorkers(processedNearby.slice(0, 3));
    } else {
        setNearbyWorkers([]);
    }
  }, [specialtyFilter, locationFilter, textSearch, userCoords, allWorkers, specialties, loading]);

  const handleTextSearchChange = (val: string) => {
    setTextSearch(val);
    if (val.length > 1) {
      const q = val.toLowerCase();
      const filtered = allWorkers
        .filter(w => w.accountStatus === 'active')
        .filter(w => 
          w.firstName.toLowerCase().includes(q) || 
          w.lastName.toLowerCase().includes(q) ||
          specialties.find(s => s.id === w.specialtyId)?.name.toLowerCase().includes(q)
        ).slice(0, 5);
      setSuggestions(filtered);
      setShowSuggestions(true);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  };

  const handleFilterChange = (key: string, value: string) => {
    const newParams = new URLSearchParams(searchParams);
    if (value) newParams.set(key, value);
    else newParams.delete(key);
    setSearchParams(newParams);
  };

  const selectedNeighborhoodName = neighborhoods.find(n => n.id === locationFilter)?.name;
  const selectedSpecialtyName = specialties.find(s => s.id === specialtyFilter)?.name;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      
      <div className="mb-12 text-center">
          <h1 className="text-4xl font-black text-gray-900 dark:text-white uppercase tracking-tighter mb-4">
              Rechercher un <span className="text-brand-600">Expert</span>
          </h1>
          <p className="text-gray-500 font-medium max-w-xl mx-auto tracking-tight">Le moteur de recherche le plus performant pour trouver vos artisans à Niamey.</p>
      </div>

      {/* Advanced Instant Search Bar */}
      <div className="max-w-4xl mx-auto mb-16 relative" ref={searchRef}>
          <div className="bg-white dark:bg-gray-800 p-2 rounded-[2.5rem] shadow-2xl flex flex-col md:flex-row items-center border border-gray-100 dark:border-gray-700 transition-all focus-within:ring-4 ring-brand-500/10">
              <div className="relative flex-1 w-full">
                  <SearchIcon className="absolute left-6 top-1/2 -translate-y-1/2 text-brand-600" size={24} />
                  <input 
                      type="text" 
                      placeholder="Nom, métier (ex: Électricien)..." 
                      className="w-full pl-16 pr-4 py-6 bg-transparent border-0 font-black uppercase text-sm tracking-widest dark:text-white outline-none placeholder:text-gray-300"
                      value={textSearch}
                      onChange={(e) => handleTextSearchChange(e.target.value)}
                      onFocus={() => textSearch.length > 1 && setShowSuggestions(true)}
                  />
                  {textSearch && (
                      <button onClick={() => { setTextSearch(''); setSuggestions([]); setShowSuggestions(false); }} className="absolute right-4 top-1/2 -translate-y-1/2 p-2 text-gray-400 hover:text-red-500 transition-colors">
                          <X size={20} />
                      </button>
                  )}
              </div>
              <div className="hidden md:block w-px h-10 bg-gray-100 dark:bg-gray-700"></div>
              <div className="w-full md:w-auto p-2 flex gap-2">
                   <select
                    value={locationFilter}
                    onChange={(e) => { handleFilterChange('location', e.target.value); setUserCoords(null); }}
                    className="pl-4 pr-10 py-4 rounded-2xl border-0 bg-gray-50 dark:bg-gray-700 dark:text-white font-black uppercase text-[10px] tracking-widest outline-none focus:ring-2 focus:ring-brand-500 transition-all appearance-none cursor-pointer"
                    >
                        <option value="">Tous les quartiers</option>
                        {neighborhoods.map(n => <option key={n.id} value={n.id}>{n.name}</option>)}
                    </select>
                    <button 
                        onClick={handleUseLocation}
                        disabled={locationLoading}
                        className={`p-4 rounded-2xl transition-all shadow-md active:scale-95 flex items-center justify-center ${userCoords ? 'bg-brand-600 text-white shadow-brand-200' : 'bg-brand-50 text-brand-600 hover:bg-brand-100'}`}
                        title="Utiliser ma position GPS"
                    >
                        {locationLoading ? <Loader className="animate-spin" size={20} /> : <Navigation size={20} className={userCoords ? 'fill-current' : ''} />}
                    </button>
              </div>
          </div>

          {/* Suggestions Dropdown */}
          {showSuggestions && suggestions.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-4 bg-white dark:bg-gray-800 rounded-[2rem] shadow-[0_30px_60px_-12px_rgba(0,0,0,0.25)] border border-gray-100 dark:border-gray-700 overflow-hidden z-[60] animate-in fade-in slide-in-from-top-2 duration-300">
                  <div className="p-4 border-b border-gray-50 dark:border-gray-700 flex justify-between items-center bg-gray-50/50 dark:bg-gray-900/50">
                      <span className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Suggestions instantanées</span>
                      <button onClick={() => setShowSuggestions(false)} className="text-[10px] font-black uppercase text-brand-600 hover:underline">Fermer</button>
                  </div>
                  <div className="max-h-96 overflow-y-auto">
                      {suggestions.map(worker => (
                          <div 
                              key={worker.id} 
                              onClick={() => {
                                  if (hasPaid) navigate(`/ouvrier/${worker.id}`);
                                  else {
                                      setTextSearch(`${worker.firstName} ${worker.lastName}`);
                                      setShowSuggestions(false);
                                  }
                              }}
                              className="flex items-center gap-4 p-4 hover:bg-brand-50 dark:hover:bg-gray-700 cursor-pointer transition-colors group border-b border-gray-50 dark:border-gray-700 last:border-0"
                          >
                              <img src={worker.photoUrl} className="w-12 h-12 rounded-xl object-cover shadow-sm group-hover:scale-105 transition-transform" />
                              <div className="flex-1">
                                  <h4 className="font-black text-gray-900 dark:text-white uppercase text-sm tracking-tight">{worker.firstName} {worker.lastName}</h4>
                                  <p className="text-[10px] font-bold text-brand-600 uppercase tracking-widest">
                                      {specialties.find(s => s.id === worker.specialtyId)?.name} • {neighborhoods.find(n => n.id === worker.neighborhoodId)?.name}
                                  </p>
                              </div>
                              <div className="flex items-center text-yellow-500 gap-1 bg-yellow-50 dark:bg-yellow-900/20 px-2 py-1 rounded-lg">
                                  <Star size={12} fill="currentColor" />
                                  <span className="text-[10px] font-black">{worker.rating}</span>
                              </div>
                              <ChevronRight className="text-gray-300 group-hover:text-brand-600 transition-colors" size={18} />
                          </div>
                      ))}
                  </div>
                  <div className="p-4 text-center bg-gray-50/30 dark:bg-gray-900/30">
                      <button 
                        onClick={() => setShowSuggestions(false)}
                        className="text-[10px] font-black uppercase text-gray-400 hover:text-gray-600 tracking-widest"
                      >
                          Voir tous les {allWorkers.length} ouvriers
                      </button>
                  </div>
              </div>
          )}
      </div>

      {/* Paywall Banner */}
      {!hasPaid && (workers.length > 0 || nearbyWorkers.length > 0) && (
        <div className="bg-brand-900 text-white rounded-[2.5rem] p-8 mb-16 flex flex-col md:flex-row items-center justify-between shadow-2xl relative overflow-hidden group border border-white/10">
          <div className="absolute -right-20 -bottom-20 opacity-10 rotate-12 group-hover:scale-110 transition-transform">
              <Lock size={300} />
          </div>
          <div className="flex items-center mb-6 md:mb-0 relative z-10">
            <div className="bg-accent-600 p-4 rounded-3xl mr-6 shadow-xl">
                <Lock className="h-8 w-8 text-white" />
            </div>
            <div>
              <p className="font-black text-2xl uppercase tracking-tighter">Débloquez l'accès illimité</p>
              <p className="text-gray-300 font-medium">Payez une seule fois <span className="text-accent-500 font-black">{consultationPrice} FCFA</span> pour tous les contacts.</p>
            </div>
          </div>
          <button 
            onClick={() => {
                const params = new URLSearchParams();
                if (specialtyFilter) params.append('return_spec', specialtyFilter);
                if (locationFilter) params.append('return_loc', locationFilter);
                if (textSearch) params.append('q', textSearch);
                navigate(`/payment?${params.toString()}`);
            }}
            className="bg-white text-brand-900 px-10 py-4 rounded-2xl font-black uppercase tracking-widest hover:bg-gray-100 transition-all shadow-xl active:scale-95 relative z-10 text-sm"
          >
            Débloquer Maintenant
          </button>
        </div>
      )}

      {/* Results Section */}
      <div className="space-y-16">
          {workers.length > 0 ? (
              <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
                <div className="flex items-center justify-between mb-8 border-b border-gray-100 dark:border-gray-800 pb-4">
                     <h2 className="text-2xl font-black text-gray-900 dark:text-white uppercase tracking-tighter flex items-center gap-3">
                         <div className="w-2 h-8 bg-brand-600 rounded-full"></div>
                         {userCoords ? "Experts à proximité de vous" : textSearch ? `Résultats pour "${textSearch.toUpperCase()}"` : `Résultats à ${selectedNeighborhoodName || 'Niamey'}`}
                     </h2>
                     <span className="bg-brand-50 dark:bg-brand-900/30 text-brand-600 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest">{workers.length} experts</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
                    {workers.map((worker) => (
                      <WorkerCard 
                        key={worker.id} 
                        worker={worker} 
                        hasPaid={hasPaid} 
                        navigate={navigate} 
                        specialties={specialties} 
                        neighborhoods={neighborhoods}
                        specialtyFilter={specialtyFilter}
                        locationFilter={locationFilter}
                        userCoords={userCoords}
                      />
                    ))}
                </div>
              </div>
          ) : !loading && (locationFilter || textSearch) && (
              <div className="bg-orange-50 dark:bg-orange-900/10 p-10 rounded-[3rem] text-center border border-orange-100 dark:border-orange-800/30 mb-12">
                 <AlertCircle className="mx-auto text-orange-500 mb-4" size={48} />
                 <h2 className="text-2xl font-black text-orange-800 dark:text-orange-400 uppercase tracking-tighter">Aucun expert ne correspond exactement à votre recherche</h2>
                 <p className="text-orange-700 dark:text-orange-300 font-medium mt-2">Nous avons élargi la recherche pour vous proposer des alternatives pertinentes.</p>
              </div>
          )}

          {nearbyWorkers.length > 0 && (
              <div className="animate-in fade-in slide-in-from-bottom-4 duration-1000 delay-200">
                <div className="flex items-center justify-between mb-8 border-b border-gray-100 dark:border-gray-800 pb-4">
                    <h2 className="text-2xl font-black text-gray-900 dark:text-white uppercase tracking-tighter flex items-center gap-3">
                        <div className="w-2 h-8 bg-orange-500 rounded-full"></div>
                        {workers.length === 0 ? "Suggestions d'experts qualifiés" : 'Autres suggestions à Niamey'}
                    </h2>
                    <div className="flex items-center gap-2 bg-orange-50 dark:bg-orange-900/30 px-4 py-1.5 rounded-full">
                        <RotateCw size={14} className="text-orange-600 animate-spin-slow" />
                        <span className="text-orange-600 text-[10px] font-black uppercase tracking-widest">Recherche intelligente active</span>
                    </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
                    {nearbyWorkers.map((worker) => (
                      <WorkerCard 
                        key={worker.id} 
                        worker={worker} 
                        isNearby={true}
                        hasPaid={hasPaid} 
                        navigate={navigate} 
                        specialties={specialties} 
                        neighborhoods={neighborhoods} 
                        specialtyFilter={specialtyFilter}
                        locationFilter={locationFilter}
                        userCoords={userCoords}
                      />
                    ))}
                </div>
              </div>
          )}
      </div>

      {workers.length === 0 && nearbyWorkers.length === 0 && !loading && (
        <div className="text-center py-24 bg-white dark:bg-gray-800 rounded-[3rem] border border-dashed border-gray-200 dark:border-gray-700">
            <SearchIcon size={64} className="mx-auto text-gray-200 mb-6" />
            <h2 className="text-2xl font-black text-gray-400 uppercase tracking-tighter">Aucun résultat trouvé</h2>
            <p className="text-gray-500 mt-2 font-medium">Essayez de modifier vos filtres ou de changer de spécialité.</p>
            <button 
                onClick={() => { handleFilterChange('specialty', ''); handleFilterChange('location', ''); setUserCoords(null); setTextSearch(''); }} 
                className="mt-8 text-brand-600 font-black uppercase tracking-widest text-xs hover:underline"
            >
                Réinitialiser la recherche
            </button>
        </div>
      )}

      {loading && (
          <div className="flex flex-col items-center justify-center py-24">
              <Loader className="w-12 h-12 text-brand-600 animate-spin mb-4" />
              <p className="text-[10px] font-black uppercase text-gray-400 tracking-[0.2em]">Synchronisation avec la base de Niamey...</p>
          </div>
      )}
    </div>
  );
};

export default Search;
