
import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Search, MapPin, CheckCircle, Shield, Quote, ExternalLink, ShoppingBag, UserPlus, Handshake } from 'lucide-react';
import { db } from '../services/db';
import { Specialty, Neighborhood, Partner } from '../types';

const Home = () => {
  const navigate = useNavigate();
  const [specialties, setSpecialties] = useState<Specialty[]>([]);
  const [neighborhoods, setNeighborhoods] = useState<Neighborhood[]>([]);
  const [partners, setPartners] = useState<Partner[]>([]);
  
  const [selectedSpecialty, setSelectedSpecialty] = useState('');
  const [selectedNeighborhood, setSelectedNeighborhood] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      const [s, n, p] = await Promise.all([
        db.getSpecialties(),
        db.getNeighborhoods(),
        db.getPartners()
      ]);
      setSpecialties(s);
      setNeighborhoods(n);
      setPartners(p.filter(item => item.isVisible));
    };
    fetchData();
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (selectedSpecialty) params.append('specialty', selectedSpecialty);
    if (selectedNeighborhood) params.append('location', selectedNeighborhood);
    navigate(`/search?${params.toString()}`);
  };

  const ensureAbsoluteUrl = (url: string) => {
    if (!url) return '';
    if (url.startsWith('http://') || url.startsWith('https://') || url.startsWith('/')) {
        return url;
    }
    return `https://${url}`;
  };

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <div className="relative bg-brand-900 text-white">
        <div className="absolute inset-0 overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1621905251189-08b45d6a269e?q=80&w=2069&auto=format&fit=crop" 
            alt="Ouvrier au travail" 
            className="w-full h-full object-cover opacity-20"
          />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-32">
          <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4 text-center uppercase">
            Trouvez les meilleurs <span className="text-accent-500">ouvriers</span> à Niamey
          </h1>
          <p className="text-xl text-gray-300 text-center mb-10 max-w-2xl mx-auto">
            Électriciens, Plombiers, Maçons... Disponibles dans votre quartier en quelques clics.
          </p>

          <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-2xl p-2 md:p-4 border-4 border-white/20">
            <form onSubmit={handleSearch} className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                   <Search className="h-5 w-5 text-gray-400" />
                </div>
                <select 
                  className="block w-full pl-10 pr-3 py-3 border border-gray-200 rounded-xl leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500 sm:text-sm text-gray-900 font-bold"
                  value={selectedSpecialty}
                  onChange={(e) => setSelectedSpecialty(e.target.value)}
                >
                  <option value="">Quelle spécialité ?</option>
                  {specialties.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>

              <div className="flex-1 relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                   <MapPin className="h-5 w-5 text-gray-400" />
                </div>
                <select 
                  className="block w-full pl-10 pr-3 py-3 border border-gray-200 rounded-xl leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500 sm:text-sm text-gray-900 font-bold"
                  value={selectedNeighborhood}
                  onChange={(e) => setSelectedNeighborhood(e.target.value)}
                >
                  <option value="">Quel quartier ?</option>
                  {neighborhoods.map(n => <option key={n.id} value={n.id}>{n.name}</option>)}
                </select>
              </div>

              <button type="submit" className="bg-brand-600 text-white px-8 py-3 rounded-xl font-black uppercase tracking-wider hover:bg-brand-700 transition-all shadow-lg active:scale-95">
                Rechercher
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="py-20 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="text-center p-8 bg-white dark:bg-gray-700 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-600 transition-transform hover:-translate-y-2">
              <div className="w-16 h-16 bg-brand-100 text-brand-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Search className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-black text-gray-900 dark:text-white mb-3 uppercase tracking-tight">Recherche Facile</h3>
              <p className="text-gray-500 dark:text-gray-300">Filtrez par métier et par quartier pour trouver le professionnel le plus proche.</p>
            </div>
            <div className="text-center p-8 bg-white dark:bg-gray-700 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700 transition-transform hover:-translate-y-2">
              <div className="w-16 h-16 bg-brand-100 text-brand-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Shield className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-black text-gray-900 dark:text-white mb-3 uppercase tracking-tight">Ouvriers Vérifiés</h3>
              <p className="text-gray-500 dark:text-gray-300">Identités contrôlées et avis clients pour garantir votre sérénité totale sur vos chantiers.</p>
            </div>
            <div className="text-center p-8 bg-white dark:bg-gray-700 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700 transition-transform hover:-translate-y-2">
              <div className="w-16 h-16 bg-brand-100 text-brand-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-black text-gray-900 dark:text-white mb-3 uppercase tracking-tight">Qualité Assurée</h3>
              <p className="text-gray-500 dark:text-gray-300">Accédez aux meilleurs profils notés par la communauté de Niamey avec un suivi KAMBEGOYE.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Partners Section */}
      {partners.length > 0 && (
        <div className="py-24 bg-white dark:bg-gray-900 overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
                <h2 className="text-3xl md:text-4xl font-black text-gray-900 dark:text-white mb-4 uppercase tracking-tighter">Nos Partenaires de Confiance</h2>
                <div className="w-24 h-1.5 bg-brand-600 mx-auto rounded-full"></div>
                <p className="mt-6 text-gray-500 dark:text-gray-400 max-w-2xl mx-auto font-medium">
                    Nous collaborons avec les meilleures entreprises locales pour vous garantir un matériel d'exception et un service irréprochable.
                </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              {partners.map(partner => {
                const isInternalShop = partner.websiteUrl === '/boutique';
                
                return (
                  <div key={partner.id} className="group bg-gray-50 dark:bg-gray-800 p-8 rounded-[3rem] border border-gray-100 dark:border-gray-700 transition-all hover:shadow-2xl hover:bg-white dark:hover:bg-gray-750 flex flex-col">
                    <div className="relative mb-8">
                        <div className="h-64 w-full flex items-center justify-center bg-white dark:bg-gray-900 rounded-[2.5rem] overflow-hidden shadow-inner border border-gray-100 dark:border-gray-800">
                            <img 
                                src={partner.logoUrl} 
                                alt={partner.name} 
                                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" 
                            />
                        </div>
                        <div className="absolute -bottom-4 -right-4 p-4 bg-brand-600 text-white rounded-2xl shadow-lg border-4 border-white dark:border-gray-800">
                           <Quote className="h-7 w-7" />
                        </div>
                    </div>

                    <h3 className="text-2xl font-black text-gray-900 dark:text-white mb-4 uppercase tracking-tighter">{partner.name}</h3>
                    
                    <div className="flex-grow">
                        {partner.comment ? (
                            <p className="text-lg md:text-xl text-gray-600 dark:text-gray-300 italic leading-relaxed mb-8 font-medium">
                            "{partner.comment}"
                            </p>
                        ) : (
                            <p className="text-gray-400 italic mb-8 font-medium">Partenaire officiel spécialisé, engagé pour la qualité de vos chantiers avec KAMBEGOYE.</p>
                        )}
                    </div>

                    <div className="mt-auto pt-6 border-t border-gray-200 dark:border-gray-700">
                      {partner.websiteUrl ? (
                          isInternalShop ? (
                            <Link 
                                to="/boutique" 
                                className="flex items-center justify-between w-full bg-brand-600 text-white py-4 px-6 rounded-2xl font-black shadow-lg hover:bg-brand-700 transition-all active:scale-95 group/link"
                            >
                                <span className="flex items-center gap-2 uppercase tracking-wide">
                                    <ShoppingBag size={20} />
                                    Voir dans la Boutique
                                </span>
                                <CheckCircle size={20} className="opacity-50" />
                            </Link>
                          ) : (
                            <a 
                                href={ensureAbsoluteUrl(partner.websiteUrl)} 
                                target="_blank" 
                                rel="noopener noreferrer" 
                                className="flex items-center gap-2 text-brand-600 font-black uppercase tracking-widest text-sm hover:text-brand-700 transition-colors group/link"
                            >
                                <ExternalLink size={18} className="group-hover/link:rotate-12 transition-transform" />
                                Visiter le site web
                                <span className="block h-px flex-1 bg-brand-100 dark:bg-brand-900 ml-2"></span>
                            </a>
                          )
                      ) : (
                          <span className="text-[10px] font-black uppercase text-gray-400 tracking-[0.2em]">Partenaire Certifié KAMBEGOYE</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Unified Dual CTA Section */}
      <div className="py-24 bg-brand-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
           <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12 items-stretch">
              
              {/* Partner CTA Card */}
              <div className="relative bg-white/5 backdrop-blur-md rounded-[3rem] p-10 lg:p-12 border border-white/10 flex flex-col justify-between overflow-hidden group hover:bg-white/10 transition-all h-full">
                  <div className="absolute -top-10 -right-10 opacity-5 group-hover:scale-110 transition-transform">
                      <Handshake size={300} className="text-white" />
                  </div>
                  <div className="relative z-10 flex-grow">
                      <div className="w-20 h-20 bg-accent-600 text-white rounded-3xl flex items-center justify-center mb-10 shadow-2xl">
                          <Handshake size={40} />
                      </div>
                      <h2 className="text-3xl md:text-4xl font-black text-white mb-6 uppercase tracking-tighter leading-none">Votre entreprise ici ?</h2>
                      <p className="text-xl text-gray-300 mb-12 font-medium leading-relaxed max-w-sm">
                          Rejoignez le réseau KAMBEGOYE en tant que partenaire et boostez votre visibilité auprès des clients et artisans de Niamey.
                      </p>
                  </div>
                  <div className="relative z-10 pt-4">
                      <Link 
                        to="/devenir-partenaire" 
                        className="inline-flex bg-white text-brand-900 px-10 py-5 rounded-2xl font-black text-xl shadow-2xl hover:bg-gray-100 transition-all active:scale-95 uppercase tracking-wide items-center justify-center gap-3 w-full sm:w-fit text-center"
                      >
                        <Handshake className="h-6 w-6" />
                        Devenir Partenaire
                      </Link>
                  </div>
              </div>

              {/* Worker CTA Card */}
              <div className="relative bg-brand-600 rounded-[3rem] p-10 lg:p-12 border border-brand-500 flex flex-col justify-between overflow-hidden group hover:bg-brand-500 transition-all shadow-2xl shadow-brand-950/50 h-full">
                  <div className="absolute -top-10 -right-10 opacity-10 group-hover:scale-110 transition-transform">
                      <Shield size={300} className="text-white" />
                  </div>
                  <div className="relative z-10 flex-grow">
                      <div className="w-20 h-20 bg-white text-brand-600 rounded-3xl flex items-center justify-center mb-10 shadow-2xl">
                          <UserPlus size={40} />
                      </div>
                      <h2 className="text-3xl md:text-4xl font-black text-white mb-6 uppercase tracking-tighter leading-none">Prêt à booster votre activité ?</h2>
                      <p className="text-xl text-white/90 mb-12 font-medium leading-relaxed max-w-sm">
                          Rejoignez le réseau leader à Niamey. Une plateforme conçue pour les professionnels qui visent l'excellence et le succès.
                      </p>
                  </div>
                  <div className="relative z-10 pt-4">
                      <Link 
                        to="/inscription"
                        className="inline-flex bg-white text-brand-600 px-10 py-5 rounded-2xl font-black text-xl shadow-2xl hover:bg-gray-50 transition-all active:scale-95 uppercase tracking-wide items-center justify-center gap-3 w-full sm:w-fit text-center"
                      >
                        <UserPlus className="h-6 w-6" />
                        S'inscrire comme Ouvrier
                      </Link>
                  </div>
              </div>

           </div>
        </div>
      </div>

    </div>
  );
};

export default Home;
