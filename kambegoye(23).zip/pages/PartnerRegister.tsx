
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Handshake, Upload, CheckCircle, AlertCircle, Globe, Mail, Phone, User, MessageSquare } from 'lucide-react';
import { db } from '../services/db';

const PartnerRegister = () => {
  const navigate = useNavigate();
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  
  const [formData, setFormData] = useState({
    name: '',
    contactPerson: '',
    contactPhone: '',
    contactEmail: '',
    websiteUrl: '',
    category: 'Matériel',
    comment: '',
    message: '',
    logoUrl: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      try {
        const dataUrl = await db.fileToDataURL(file);
        setFormData({ ...formData, logoUrl: dataUrl });
      } catch (err) {
        alert("Erreur lors de l'importation de l'image.");
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.logoUrl) {
      alert("Veuillez importer le logo de votre entreprise.");
      return;
    }
    
    setStatus('submitting');
    try {
      await db.savePartnerRequest(formData);
      setStatus('success');
    } catch (err) {
      setStatus('error');
    }
  };

  if (status === 'success') {
    return (
      <div className="min-h-[70vh] flex items-center justify-center px-4">
        <div className="bg-white dark:bg-gray-800 p-10 rounded-[2.5rem] shadow-2xl max-w-lg w-full text-center border border-gray-100 dark:border-gray-700">
          <div className="mx-auto flex items-center justify-center h-20 w-20 rounded-3xl bg-green-100 dark:bg-green-900/30 mb-8">
            <CheckCircle className="h-12 w-12 text-green-600" />
          </div>
          <h2 className="text-3xl font-black text-gray-900 dark:text-white mb-4 uppercase tracking-tighter">Demande Envoyée !</h2>
          <p className="text-gray-600 dark:text-gray-400 mb-8 font-medium leading-relaxed">
            Merci de l'intérêt porté à KAMBEGOYE. Notre équipe va examiner votre demande de partenariat et vous recontacter sous 48h.
          </p>
          <button 
            onClick={() => navigate('/')}
            className="w-full bg-brand-600 text-white py-4 rounded-2xl font-black uppercase tracking-widest shadow-lg hover:bg-brand-700 transition-all active:scale-95"
          >
            Retour au site
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-16">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-black text-gray-900 dark:text-white mb-4 uppercase tracking-tighter">Devenir Partenaire</h1>
        <div className="w-20 h-1.5 bg-brand-600 mx-auto rounded-full mb-6"></div>
        <p className="text-xl text-gray-500 dark:text-gray-400 max-w-2xl mx-auto font-medium">
          Rejoignez l'écosystème KAMBEGOYE et offrez vos services à notre communauté grandissante d'artisans et de clients à Niamey.
        </p>
      </div>

      <div className="bg-white dark:bg-gray-800 shadow-2xl rounded-[3rem] overflow-hidden border border-gray-100 dark:border-gray-700">
        <div className="bg-brand-600 px-8 py-6 flex items-center text-white">
          <Handshake className="w-8 h-8 mr-4" />
          <h2 className="text-2xl font-black uppercase tracking-widest">Formulaire de Partenariat</h2>
        </div>
        
        <form onSubmit={handleSubmit} className="p-8 md:p-12 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
             <div className="space-y-6">
                <h3 className="text-sm font-black text-brand-600 uppercase tracking-widest border-b border-brand-100 pb-2">Informations Entreprise</h3>
                
                <div>
                  <label className="block text-[10px] font-black uppercase text-gray-400 mb-1">Nom de l'entreprise</label>
                  <input type="text" name="name" required value={formData.name} onChange={handleChange} className="w-full p-4 bg-gray-50 dark:bg-gray-900 border-0 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-brand-500" placeholder="Ex: Niger Matériaux" />
                </div>

                <div>
                  <label className="block text-[10px] font-black uppercase text-gray-400 mb-1">Catégorie</label>
                  <select name="category" value={formData.category} onChange={handleChange} className="w-full p-4 bg-gray-50 dark:bg-gray-900 border-0 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-brand-500">
                    <option value="Matériel">Vente de Matériel</option>
                    <option value="Logistique">Logistique / Transport</option>
                    <option value="Finance">Services Financiers</option>
                    <option value="Formation">Formation / Conseil</option>
                    <option value="Autre">Autre</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-black uppercase text-gray-400 mb-1">Site Web / Réseaux Sociaux</label>
                  <div className="relative">
                    <Globe className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                    <input type="url" name="websiteUrl" value={formData.websiteUrl} onChange={handleChange} className="w-full pl-12 p-4 bg-gray-50 dark:bg-gray-900 border-0 rounded-2xl font-medium outline-none focus:ring-2 focus:ring-brand-500" placeholder="https://..." />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-black uppercase text-gray-400 mb-2">Logo Officiel</label>
                  <div className="flex items-center gap-4">
                    <div className="h-24 w-24 bg-gray-100 dark:bg-gray-900 rounded-3xl border-2 border-dashed border-gray-200 dark:border-gray-700 flex items-center justify-center overflow-hidden p-2">
                       {formData.logoUrl ? <img src={formData.logoUrl} className="max-h-full max-w-full object-contain" /> : <Upload className="text-gray-300" />}
                    </div>
                    <label className="flex-1 cursor-pointer bg-white dark:bg-gray-900 border border-brand-100 dark:border-gray-700 py-3 px-4 rounded-2xl text-center text-[10px] font-black uppercase text-brand-600 hover:bg-brand-50 transition-colors">
                       Choisir le fichier
                       <input type="file" className="hidden" accept="image/*" onChange={handleFileChange} />
                    </label>
                  </div>
                </div>
             </div>

             <div className="space-y-6">
                <h3 className="text-sm font-black text-accent-600 uppercase tracking-widest border-b border-accent-100 pb-2">Contact Responsable</h3>
                
                <div>
                  <label className="block text-[10px] font-black uppercase text-gray-400 mb-1">Nom complet</label>
                  <div className="relative">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                    <input type="text" name="contactPerson" required value={formData.contactPerson} onChange={handleChange} className="w-full pl-12 p-4 bg-gray-50 dark:bg-gray-900 border-0 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-brand-500" />
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-4">
                  <div>
                    <label className="block text-[10px] font-black uppercase text-gray-400 mb-1">Téléphone Direct</label>
                    <div className="relative">
                        <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                        <input type="tel" name="contactPhone" required value={formData.contactPhone} onChange={handleChange} className="w-full pl-12 p-4 bg-gray-50 dark:bg-gray-900 border-0 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-brand-500" placeholder="Ex: 90000000" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[10px] font-black uppercase text-gray-400 mb-1">Email</label>
                    <div className="relative">
                        <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                        <input type="email" name="contactEmail" required value={formData.contactEmail} onChange={handleChange} className="w-full pl-12 p-4 bg-gray-50 dark:bg-gray-900 border-0 rounded-2xl font-bold outline-none focus:ring-2 focus:ring-brand-500" placeholder="partenaire@domaine.com" />
                    </div>
                  </div>
                </div>

                <div>
                   <label className="block text-[10px] font-black uppercase text-gray-400 mb-1">Slogan / Courte Présentation</label>
                   <input type="text" name="comment" value={formData.comment} onChange={handleChange} className="w-full p-4 bg-gray-50 dark:bg-gray-900 border-0 rounded-2xl font-medium outline-none focus:ring-2 focus:ring-brand-500" placeholder="Affiché publiquement" />
                </div>
             </div>
          </div>

          <div>
             <label className="block text-[10px] font-black uppercase text-gray-400 mb-2">Message à l'équipe KAMBEGOYE</label>
             <div className="relative">
                <MessageSquare className="absolute left-4 top-4 text-gray-400" size={18} />
                <textarea name="message" required rows={4} value={formData.message} onChange={handleChange} className="w-full pl-12 p-4 bg-gray-50 dark:bg-gray-900 border-0 rounded-2xl font-medium outline-none focus:ring-2 focus:ring-brand-500" placeholder="Décrivez votre motivation..." />
             </div>
          </div>

          {status === 'error' && (
            <div className="bg-red-50 text-red-600 p-4 rounded-2xl flex items-center gap-3 text-sm font-bold">
              <AlertCircle size={20} /> Une erreur est survenue lors de l'envoi.
            </div>
          )}

          <button 
            type="submit" 
            disabled={status === 'submitting'}
            className="w-full bg-brand-600 text-white py-5 rounded-2xl font-black uppercase tracking-widest text-lg shadow-xl hover:bg-brand-700 transition-all active:scale-95 disabled:opacity-50"
          >
             {status === 'submitting' ? 'Traitement en cours...' : 'Soumettre ma Candidature'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default PartnerRegister;
