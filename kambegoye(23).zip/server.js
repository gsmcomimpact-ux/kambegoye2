require('dotenv').config();
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();

app.use(cors({
    origin: ['https://kambegoye.com', 'http://kambegoye.com', 'http://localhost:3000', 'http://localhost:5173'],
    credentials: true
}));

app.use(bodyParser.json({ limit: '50mb' })); 

const dbConfig = {
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: parseInt(process.env.DB_PORT) || 3306,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
};

const pool = mysql.createPool(dbConfig).promise();

const initDB = async () => {
    try {
        console.log("🛠 Initialisation de la base de données...");
        
        await pool.query(`CREATE TABLE IF NOT EXISTS admin_users (id VARCHAR(255) PRIMARY KEY, username VARCHAR(255) UNIQUE, password VARCHAR(255), role ENUM('superadmin', 'staff') DEFAULT 'staff', firstName VARCHAR(255), lastName VARCHAR(255))`);
        await pool.query(`CREATE TABLE IF NOT EXISTS specialties (id VARCHAR(255) PRIMARY KEY, name VARCHAR(255), icon VARCHAR(255))`);
        await pool.query(`CREATE TABLE IF NOT EXISTS workers (id VARCHAR(255) PRIMARY KEY, firstName VARCHAR(255), lastName VARCHAR(255), specialtyId VARCHAR(255), neighborhoodId VARCHAR(255), phone VARCHAR(50), whatsapp VARCHAR(50), photoUrl LONGTEXT, availability ENUM('available', 'busy') DEFAULT 'available', rating DECIMAL(3,2) DEFAULT 5.0, reviewCount INT DEFAULT 0, isVerified BOOLEAN DEFAULT FALSE, accountStatus ENUM('pending', 'active', 'rejected') DEFAULT 'pending', workImages JSON, latitude DOUBLE, longitude DOUBLE, views INT DEFAULT 0)`);
        await pool.query(`CREATE TABLE IF NOT EXISTS products (id VARCHAR(255) PRIMARY KEY, name VARCHAR(255), description TEXT, price INT, category VARCHAR(255), imageUrl LONGTEXT, stock INT, partnerId VARCHAR(255))`);
        await pool.query(`CREATE TABLE IF NOT EXISTS product_categories (id VARCHAR(255) PRIMARY KEY, name VARCHAR(255))`);
        await pool.query(`CREATE TABLE IF NOT EXISTS partners (id VARCHAR(255) PRIMARY KEY, name VARCHAR(255), logoUrl LONGTEXT, websiteUrl VARCHAR(255), comment TEXT, isVisible BOOLEAN DEFAULT FALSE, category VARCHAR(255))`);
        await pool.query(`CREATE TABLE IF NOT EXISTS partner_requests (id VARCHAR(255) PRIMARY KEY, name VARCHAR(255), contactPerson VARCHAR(255), contactPhone VARCHAR(50), contactEmail VARCHAR(255), websiteUrl VARCHAR(255), category VARCHAR(255), comment TEXT, message TEXT, logoUrl LONGTEXT, status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending', date DATETIME)`);
        await pool.query(`CREATE TABLE IF NOT EXISTS bills (id VARCHAR(255) PRIMARY KEY, projectId VARCHAR(255), number VARCHAR(255), type ENUM('quote', 'invoice'), date DATETIME, clientName VARCHAR(255), clientPhone VARCHAR(50), clientAddress VARCHAR(255), items JSON, total INT, status ENUM('pending', 'processed', 'closed') DEFAULT 'pending')`);
        await pool.query(`CREATE TABLE IF NOT EXISTS orders (id VARCHAR(255) PRIMARY KEY, clientName VARCHAR(255), clientPhone VARCHAR(50), deliveryLocation VARCHAR(255), total INT, items JSON, status ENUM('pending', 'completed') DEFAULT 'pending', date DATETIME)`);
        await pool.query(`CREATE TABLE IF NOT EXISTS disputes (id VARCHAR(255) PRIMARY KEY, reporterName VARCHAR(255), reporterPhone VARCHAR(50), workerId VARCHAR(255), description TEXT, status ENUM('open', 'investigating', 'resolved', 'closed') DEFAULT 'open', date DATETIME, resolutionDate DATE)`);
        await pool.query(`CREATE TABLE IF NOT EXISTS projects (id VARCHAR(255) PRIMARY KEY, clientName VARCHAR(255), clientPhone VARCHAR(50), title VARCHAR(255), description TEXT, category VARCHAR(255), budget VARCHAR(255), deadline VARCHAR(255), status ENUM('new', 'contacted', 'completed', 'cancelled') DEFAULT 'new', date DATETIME)`);
        await pool.query(`CREATE TABLE IF NOT EXISTS reviews (id VARCHAR(255) PRIMARY KEY, workerId VARCHAR(255), userName VARCHAR(255), rating INT, comment TEXT, date DATETIME)`);
        await pool.query(`CREATE TABLE IF NOT EXISTS settings (id VARCHAR(255) PRIMARY KEY, value JSON)`);
        await pool.query(`CREATE TABLE IF NOT EXISTS media (id VARCHAR(255) PRIMARY KEY, type VARCHAR(50), name VARCHAR(255), data LONGTEXT, date DATETIME)`);
        await pool.query(`CREATE TABLE IF NOT EXISTS transactions (id VARCHAR(255) PRIMARY KEY, amount INT, date DATETIME, status VARCHAR(50), method VARCHAR(50), userId VARCHAR(255))`);

        const [admins] = await pool.query('SELECT COUNT(*) as count FROM admin_users');
        if (admins[0].count === 0) {
            await pool.query('INSERT INTO admin_users (id, username, password, role, firstName, lastName) VALUES (?,?,?,?,?,?)', 
            ['root', 'admin', 'admin', 'superadmin', 'Admin', 'Kambegoye']);
            console.log("🌱 Compte admin/admin créé.");
        }

        const [specs] = await pool.query('SELECT COUNT(*) as count FROM specialties');
        if (specs[0].count === 0) {
            const defaultSpecs = [['1', 'Électricien', 'zap'], ['2', 'Plombier', 'droplet'], ['3', 'Maçon', 'brick-wall'], ['4', 'Menuisier', 'hammer'], ['5', 'Peintre', 'paint-roller'], ['6', 'Soudeur', 'flame'], ['7', 'Frigoriste', 'thermometer-snowflake']];
            for (const s of defaultSpecs) await pool.query('INSERT INTO specialties (id, name, icon) VALUES (?,?,?)', s);
        }

        console.log("✅ Base de données KAMBEGOYE prête.");
    } catch (err) {
        console.error("❌ Erreur DB :", err.message);
    }
};
initDB();

// AUTH
app.post('/api/admin/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        const [rows] = await pool.query('SELECT id, username, role, firstName, lastName FROM admin_users WHERE username = ? AND password = ?', [username, password]);
        if (rows.length > 0) res.json({ success: true, user: rows[0], token: 'kambegoye_auth_' + Date.now() });
        else res.status(401).json({ error: 'Identifiants invalides' });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.patch('/api/admin/password', async (req, res) => {
    const { password } = req.body;
    try {
        await pool.query('UPDATE admin_users SET password = ? WHERE role = "superadmin"', [password]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/admin/users', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT id, username, role, firstName, lastName FROM admin_users');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/admin/users', async (req, res) => {
    const u = req.body;
    try {
        await pool.query('INSERT INTO admin_users (id, username, password, role, firstName, lastName) VALUES (?,?,?,?,?,?) ON DUPLICATE KEY UPDATE role=VALUES(role), firstName=VALUES(firstName), lastName=VALUES(lastName), password=VALUES(password)', [u.id || Date.now().toString(), u.username, u.password, u.role, u.firstName, u.lastName]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/admin/users/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM admin_users WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// STATS
app.get('/api/stats', async (req, res) => {
    try {
        const [workers] = await pool.query('SELECT COUNT(*) as total FROM workers');
        const [trans] = await pool.query('SELECT COUNT(*) as total, SUM(amount) as revenue FROM transactions WHERE status = "success"');
        const [orders] = await pool.query('SELECT COUNT(*) as total FROM orders WHERE status = "pending"');
        const [projs] = await pool.query('SELECT COUNT(*) as total FROM projects WHERE status = "new"');
        const [boutique] = await pool.query('SELECT SUM(total) as revenue FROM bills WHERE type = "invoice" AND status = "closed"');
        const [allTrans] = await pool.query('SELECT * FROM transactions ORDER BY date DESC LIMIT 100');
        res.json({
            totalWorkers: workers[0].total,
            totalTransactions: trans[0].total || 0,
            totalRevenue: (parseInt(trans[0].revenue) || 0) + (parseInt(boutique[0].revenue) || 0),
            boutiqueRevenue: parseInt(boutique[0].revenue) || 0,
            serviceRevenue: parseInt(trans[0].revenue) || 0,
            pendingProjects: projs[0].total,
            pendingOrders: orders[0].total,
            recentActivities: [],
            allTransactions: allTrans
        });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// WORKERS
app.get('/api/workers', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM workers ORDER BY isVerified DESC, rating DESC');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/workers/:id', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM workers WHERE id = ?', [req.params.id]);
        if (rows.length > 0) res.json(rows[0]);
        else res.status(404).json({ error: 'Pas trouvé' });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/workers', async (req, res) => {
    const w = req.body;
    try {
        await pool.query(
            `INSERT INTO workers (id, firstName, lastName, specialtyId, neighborhoodId, phone, whatsapp, photoUrl, availability, rating, reviewCount, isVerified, accountStatus, workImages, latitude, longitude) 
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) 
             ON DUPLICATE KEY UPDATE firstName=VALUES(firstName), lastName=VALUES(lastName), specialtyId=VALUES(specialtyId), neighborhoodId=VALUES(neighborhoodId), phone=VALUES(phone), whatsapp=VALUES(whatsapp), photoUrl=VALUES(photoUrl), availability=VALUES(availability), rating=VALUES(rating), isVerified=VALUES(isVerified), accountStatus=VALUES(accountStatus), workImages=VALUES(workImages)`,
            [w.id, w.firstName, w.lastName, w.specialtyId, w.neighborhoodId, w.phone, w.whatsapp, w.photoUrl, w.availability, w.rating, w.reviewCount, w.isVerified ? 1 : 0, w.accountStatus, JSON.stringify(w.workImages || []), w.latitude, w.longitude]
        );
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/workers/register', async (req, res) => {
    const w = req.body;
    try {
        const id = 'W' + Date.now();
        await pool.query(
            `INSERT INTO workers (id, firstName, lastName, specialtyId, neighborhoodId, phone, whatsapp, photoUrl, availability, rating, reviewCount, isVerified, accountStatus, workImages, latitude, longitude) 
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
            [id, w.firstName, w.lastName, w.specialtyId, w.neighborhoodId, w.phone, w.whatsapp, w.photoUrl, 'available', 5.0, 0, 0, 'pending', JSON.stringify(w.workImages || []), w.latitude, w.longitude]
        );
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/workers/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM workers WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/workers/:id/view', async (req, res) => {
    try {
        await pool.query('UPDATE workers SET views = views + 1 WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// SPECIALTIES
app.get('/api/specialties', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM specialties');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/specialties', async (req, res) => {
    const s = req.body;
    try {
        await pool.query('INSERT INTO specialties (id, name, icon) VALUES (?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name), icon=VALUES(icon)', [s.id, s.name, s.icon]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/specialties/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM specialties WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// BOUTIQUE
app.get('/api/products', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM products');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/products/:id', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM products WHERE id = ?', [req.params.id]);
        if (rows.length > 0) res.json(rows[0]);
        else res.status(404).json({ error: 'Produit non trouvé' });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/products', async (req, res) => {
    const p = req.body;
    try {
        await pool.query('INSERT INTO products (id, name, description, price, category, imageUrl, stock, partnerId) VALUES (?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name), description=VALUES(description), price=VALUES(price), category=VALUES(category), imageUrl=VALUES(imageUrl), stock=VALUES(stock), partnerId=VALUES(partnerId)', [p.id, p.name, p.description, p.price, p.category, p.imageUrl, p.stock, p.partnerId]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/products/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM products WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/product-categories', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM product_categories');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/product-categories', async (req, res) => {
    const c = req.body;
    try {
        await pool.query('INSERT INTO product_categories (id, name) VALUES (?,?) ON DUPLICATE KEY UPDATE name=VALUES(name)', [c.id, c.name]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/product-categories/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM product_categories WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// ORDERS
app.post('/api/orders', async (req, res) => {
    const o = req.body;
    try {
        await pool.query('INSERT INTO orders (id, clientName, clientPhone, deliveryLocation, total, items, status, date) VALUES (?,?,?,?,?,?,?,?)', [o.id, o.clientName, o.clientPhone, o.deliveryLocation, o.total, JSON.stringify(o.items), o.status, o.date]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/orders', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM orders ORDER BY date DESC');
        res.json(rows.map(r => ({ ...r, items: JSON.parse(r.items || '[]') })));
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.patch('/api/orders/:id/status', async (req, res) => {
    try {
        await pool.query('UPDATE orders SET status = ? WHERE id = ?', [req.body.status, req.params.id]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// BILLS
app.get('/api/bills', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM bills ORDER BY date DESC');
        res.json(rows.map(r => ({ ...r, items: JSON.parse(r.items || '[]') })));
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/bills', async (req, res) => {
    const b = req.body;
    try {
        await pool.query('INSERT INTO bills (id, projectId, number, type, date, clientName, clientPhone, clientAddress, items, total, status) VALUES (?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE status=VALUES(status), total=VALUES(total), items=VALUES(items)', [b.id || 'B' + Date.now(), b.projectId, b.number, b.type, b.date, b.clientName, b.clientPhone, b.clientAddress, JSON.stringify(b.items), b.total, b.status]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/bills/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM bills WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// PARTNERS
app.get('/api/partners', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM partners');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/partners', async (req, res) => {
    const p = req.body;
    try {
        await pool.query('INSERT INTO partners (id, name, logoUrl, websiteUrl, comment, isVisible, category) VALUES (?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name), logoUrl=VALUES(logoUrl), websiteUrl=VALUES(websiteUrl), comment=VALUES(comment), isVisible=VALUES(isVisible), category=VALUES(category)', [p.id || 'P' + Date.now(), p.name, p.logoUrl, p.websiteUrl, p.comment, p.isVisible ? 1 : 0, p.category]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/partners/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM partners WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/partner-requests', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM partner_requests ORDER BY date DESC');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/partner-requests', async (req, res) => {
    const r = req.body;
    try {
        await pool.query('INSERT INTO partner_requests (id, name, contactPerson, contactPhone, contactEmail, websiteUrl, category, comment, message, logoUrl, status, date) VALUES (?,?,?,?,?,?,?,?,?,?,?,NOW())', ['PR' + Date.now(), r.name, r.contactPerson, r.contactPhone, r.contactEmail, r.websiteUrl, r.category, r.comment, r.message, r.logoUrl, 'pending']);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.patch('/api/partner-requests/:id/status', async (req, res) => {
    try {
        await pool.query('UPDATE partner_requests SET status = ? WHERE id = ?', [req.body.status, req.params.id]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// PROJECTS
app.get('/api/projects', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM projects ORDER BY date DESC');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/projects', async (req, res) => {
    const p = req.body;
    try {
        await pool.query('INSERT INTO projects (id, clientName, clientPhone, title, description, category, budget, deadline, status, date) VALUES (?,?,?,?,?,?,?,?,?,?)', [p.id || 'PRJ' + Date.now(), p.clientName, p.clientPhone, p.title, p.description, p.category, p.budget, p.deadline, p.status || 'new', p.date || new Date()]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.patch('/api/projects/:id/status', async (req, res) => {
    try {
        await pool.query('UPDATE projects SET status = ? WHERE id = ?', [req.body.status, req.params.id]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// DISPUTES
app.get('/api/disputes', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM disputes ORDER BY date DESC');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/disputes', async (req, res) => {
    const d = req.body;
    try {
        await pool.query('INSERT INTO disputes (id, reporterName, reporterPhone, workerId, description, status, date) VALUES (?,?,?,?,?,?,NOW())', ['DIS' + Date.now(), d.reporterName, d.reporterPhone, d.workerId, d.description, 'open']);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.patch('/api/disputes/:id/status', async (req, res) => {
    const { status, resolutionDate } = req.body;
    try {
        await pool.query('UPDATE disputes SET status = ?, resolutionDate = ? WHERE id = ?', [status, resolutionDate, req.params.id]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// SETTINGS
app.get('/api/settings', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM settings WHERE id = "main"');
        if (rows.length > 0) res.json(JSON.parse(rows[0].value));
        else res.json({ consultationPrice: 200 });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.patch('/api/settings', async (req, res) => {
    try {
        await pool.query('INSERT INTO settings (id, value) VALUES ("main", ?) ON DUPLICATE KEY UPDATE value=VALUES(value)', [JSON.stringify(req.body)]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// MEDIA
app.get('/api/media', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM media ORDER BY date DESC');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/media', async (req, res) => {
    const m = req.body;
    try {
        await pool.query('INSERT INTO media (id, type, name, data, date) VALUES (?,?,?,?,?)', [m.id, m.type, m.name, m.data, m.date]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/media/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM media WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// DATA MANAGEMENT
app.get('/api/admin/export', async (req, res) => {
    try {
        const tables = ['workers', 'specialties', 'partners', 'transactions', 'bills', 'orders', 'projects', 'admin_users', 'media', 'product_categories', 'products'];
        const data = {};
        for (const t of tables) {
            const [rows] = await pool.query(`SELECT * FROM ${t}`);
            data[t] = rows;
        }
        res.json(data);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/admin/clear-transactions', async (req, res) => {
    try {
        await pool.query('DELETE FROM transactions');
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/admin/reset', async (req, res) => {
    try {
        const tables = ['workers', 'partners', 'transactions', 'bills', 'orders', 'projects', 'disputes', 'media', 'partner_requests'];
        for (const t of tables) await pool.query(`DELETE FROM ${t}`);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/admin/import', async (req, res) => {
    const data = req.body;
    try {
        // Logique simplifiée d'import massif (à utiliser avec précaution)
        for (const table in data) {
            const rows = data[table];
            if (Array.isArray(rows)) {
                for (const row of rows) {
                    const keys = Object.keys(row);
                    const values = Object.values(row);
                    const placeholders = keys.map(() => '?').join(',');
                    const updates = keys.map(k => `${k}=VALUES(${k})`).join(',');
                    await pool.query(`INSERT INTO ${table} (${keys.join(',')}) VALUES (${placeholders}) ON DUPLICATE KEY UPDATE ${updates}`, values);
                }
            }
        }
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// PAYMENTS
app.post('/api/payments/initiate', async (req, res) => {
    const { method, phone } = req.body;
    const tid = 'T' + Math.random().toString(36).substr(2, 9).toUpperCase();
    const [settings] = await pool.query('SELECT value FROM settings WHERE id = "main"');
    const amount = JSON.parse(settings[0]?.value || '{"consultationPrice":200}').consultationPrice;
    await pool.query('INSERT INTO transactions (id, amount, date, status, method) VALUES (?,?,NOW(),?,?)', [tid, amount, 'pending', method]);
    res.json({ success: true, paymentUrl: method === 'Espèces' ? `/payment/simulation?amount=${amount}&method=${method}&phone=${phone}&ref=${tid}&type=cash&tid=${tid}` : `/payment/simulation?amount=${amount}&method=${method}&phone=${phone}&ref=${tid}` });
});

app.get('/api/payments/verify', async (req, res) => {
    try {
        await pool.query('UPDATE transactions SET status = "success" WHERE id = ?', [req.query.ref]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 API KAMBEGOYE CONNECTÉE SUR PORT ${PORT}`);
});
