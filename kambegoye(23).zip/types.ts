
export interface Worker {
  id: string;
  firstName: string;
  lastName: string;
  specialtyId: string;
  neighborhoodId: string;
  whatsapp: string;
  phone: string;
  photoUrl: string;
  idCardUrl?: string; // Admin only
  availability: 'available' | 'busy';
  rating: number;
  reviewCount: number;
  isVerified: boolean;
  workImages: string[];
  latitude?: number;
  longitude?: number;
  accountStatus: 'pending' | 'active' | 'rejected';
  views?: number; 
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string; 
  imageUrl: string;
  stock: number;
  partnerId?: string; // Nouveau: Lien vers le partenaire
}

export interface Partner {
  id: string;
  name: string;
  logoUrl: string;
  websiteUrl?: string;
  comment?: string;
  isVisible: boolean;
  category?: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface ProductCategory {
  id: string;
  name: string;
}

export interface Specialty {
  id: string;
  name: string;
  icon: string;
}

export interface Neighborhood {
  id: string;
  name: string;
}

export interface Transaction {
  id: string;
  amount: number;
  date: string;
  status: 'success' | 'failed' | 'pending';
  method: 'Mynita' | 'Amanata' | 'Espèces';
  userId: string; 
}

export interface Order {
  id: string;
  items: CartItem[];
  total: number;
  date: string;
  status: 'pending' | 'completed';
  clientName?: string;
  clientPhone?: string;
  deliveryLocation?: string;
}

export interface SiteActivity {
  id: string;
  type: 'order' | 'project' | 'worker' | 'partner';
  title: string;
  description: string;
  date: string;
  amount?: number;
}

export interface Stats {
  totalWorkers: number;
  totalTransactions: number;
  totalRevenue: number;
  boutiqueRevenue: number;
  serviceRevenue: number;
  pendingProjects: number;
  pendingOrders: number;
  recentActivities: SiteActivity[];
  topWorkers: Worker[];
  topProducts: { name: string; sales: number }[];
  allTransactions: Transaction[];
}

export interface SystemSettings {
  consultationPrice: number;
}

export interface PartnerRequest extends Omit<Partner, 'isVisible'> {
  contactPerson: string;
  contactPhone: string;
  contactEmail: string;
  message: string;
  status: 'pending' | 'approved' | 'rejected';
  date: string;
}

export interface AdminUser {
  id: string;
  username: string;
  firstName?: string;
  lastName?: string;
  password?: string;
  role: 'superadmin' | 'staff';
}

export interface MediaItem {
  id: string;
  type: 'image' | 'document';
  name: string;
  data: string;
  date: string;
}

export interface Dispute {
  id: string;
  reporterName: string;
  reporterPhone: string;
  workerId: string;
  description: string;
  status: 'open' | 'investigating' | 'resolved' | 'closed';
  date: string;
  resolutionDate?: string;
}

export interface ProjectRequest {
  id: string;
  clientName: string;
  clientPhone: string;
  title: string;
  description: string;
  category: string;
  budget?: string;
  deadline?: string;
  status: 'new' | 'contacted' | 'completed' | 'cancelled';
  date: string;
}

export interface BillItem {
  description: string;
  quantity: number;
  unitPrice: number;
}

export interface Bill {
  id: string;
  projectId?: string;
  number: string;
  type: 'quote' | 'invoice';
  date: string;
  clientName: string;
  clientPhone?: string;
  clientAddress?: string;
  items: BillItem[];
  total: number;
  status: 'pending' | 'processed' | 'closed';
}

// Added missing Review interface to resolve export/import errors
export interface Review {
  id: string;
  workerId: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}
